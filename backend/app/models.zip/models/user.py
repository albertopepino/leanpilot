from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Text
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
import enum

from app.models.base import Base, TimestampMixin


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    PLANT_MANAGER = "plant_manager"
    LINE_SUPERVISOR = "line_supervisor"
    OPERATOR = "operator"
    VIEWER = "viewer"


class SubscriptionTier(str, enum.Enum):
    STARTER = "starter"
    PROFESSIONAL = "professional"
    BUSINESS = "business"
    ENTERPRISE = "enterprise"


class User(TimestampMixin, Base):
    __tablename__ = "users"

    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(SAEnum(UserRole), default=UserRole.VIEWER)
    is_active = Column(Boolean, default=True)
    factory_id = Column(Integer, ForeignKey("factories.id"), nullable=True)
    language = Column(String(5), default="en")

    # GDPR Consent fields (Art. 6, 7)
    privacy_policy_accepted_at = Column(DateTime(timezone=True), nullable=True)
    terms_accepted_at = Column(DateTime(timezone=True), nullable=True)
    consent_version = Column(String(20), nullable=True)  # e.g. "1.0", "1.1"
    ai_consent = Column(Boolean, default=False)  # Separate consent for AI data processing
    marketing_consent = Column(Boolean, default=False)

    # Soft delete (Art. 17 — Right to erasure)
    is_deleted = Column(Boolean, default=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    deletion_requested_at = Column(DateTime(timezone=True), nullable=True)

    # Security — account lockout
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime(timezone=True), nullable=True)
    last_login_at = Column(DateTime(timezone=True), nullable=True)
    password_changed_at = Column(DateTime(timezone=True), nullable=True)

    factory = relationship("Factory", back_populates="users")
