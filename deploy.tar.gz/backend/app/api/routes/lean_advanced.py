from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime

from app.db.session import get_db
from app.core.security import get_current_user, require_factory
from app.models.user import User
from app.schemas.lean_advanced import (
    SixSAuditCreate, SixSAuditResponse, VSMCreate, VSMResponse,
    A3ReportCreate, A3ReportResponse,
    GembaWalkCreate, GembaWalkResponse,
    TPMEquipmentCreate, TPMMaintenanceCreate,
    CILTStandardCreate, CILTExecutionCreate,
    AndonEventCreate, AndonResolve, HourlyProductionCreate,
)
from app.services.lean_advanced import (
    SixSService, VSMService, A3Service, GembaService,
    TPMService, CILTService, AndonService, HourlyProductionService,
)

router = APIRouter(prefix="/lean-advanced", tags=["lean-advanced"])


# ---- 6S AUDIT ----

@router.post("/six-s")
async def create_six_s_audit(
    data: SixSAuditCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    audit = await SixSService.create_audit(db, fid, user.id, data.model_dump())
    return {"id": audit.id, "overall_score": audit.overall_score, "maturity_level": audit.maturity_level}


@router.get("/six-s", response_model=list[SixSAuditResponse])
async def list_six_s_audits(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await SixSService.list_audits(db, fid)


@router.get("/six-s/trend")
async def six_s_trend(
    area: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await SixSService.get_trend(db, fid, area)


# ---- VSM ----

@router.post("/vsm")
async def create_vsm(
    data: VSMCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    vsm = await VSMService.create(db, fid, user.id, data.model_dump())
    return {"id": vsm.id, "pce_ratio": vsm.pce_ratio, "total_lead_time_days": vsm.total_lead_time_days}


@router.get("/vsm", response_model=list[VSMResponse])
async def list_vsm(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await VSMService.list_maps(db, fid)


# ---- A3 REPORT ----

@router.post("/a3")
async def create_a3(
    data: A3ReportCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    report = await A3Service.create(db, fid, user.id, data.model_dump())
    return {"id": report.id, "status": str(report.status).lower() if report.status else report.status}


@router.get("/a3", response_model=list[A3ReportResponse])
async def list_a3(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await A3Service.list_reports(db, fid)


@router.patch("/a3/{report_id}/status", response_model=A3ReportResponse)
async def update_a3_status(
    report_id: int,
    status: str,
    results: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await A3Service.update_status(db, report_id, status, results, factory_id=fid)


# ---- GEMBA WALK ----

@router.post("/gemba")
async def create_gemba_walk(
    data: GembaWalkCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    walk = await GembaService.create_walk(db, fid, user.id, data.model_dump())
    return {"id": walk.id}


@router.get("/gemba", response_model=list[GembaWalkResponse])
async def list_gemba_walks(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await GembaService.list_walks(db, fid)


# ---- TPM ----

@router.post("/tpm/equipment")
async def create_tpm_equipment(
    data: TPMEquipmentCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    eq = await TPMService.create_equipment(db, fid, data.model_dump())
    return {"id": eq.id, "name": eq.name}


@router.get("/tpm/equipment")
async def list_tpm_equipment(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await TPMService.list_equipment(db, fid)


@router.post("/tpm/maintenance")
async def log_tpm_maintenance(
    data: TPMMaintenanceCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    record = await TPMService.log_maintenance(db, user.id, data.model_dump(), factory_id=fid)
    return {"id": record.id}


# ---- CILT ----

@router.post("/cilt/standards")
async def create_cilt_standard(
    data: CILTStandardCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    standard = await CILTService.create_standard(db, fid, data.model_dump())
    return {"id": standard.id, "name": standard.name}


@router.get("/cilt/standards")
async def list_cilt_standards(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await CILTService.list_standards(db, fid)


@router.post("/cilt/execute")
async def execute_cilt(
    data: CILTExecutionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    execution = await CILTService.execute_cilt(db, user.id, data.model_dump(), factory_id=fid)
    return {"id": execution.id, "all_ok": execution.all_ok}


@router.get("/cilt/compliance")
async def cilt_compliance(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await CILTService.get_compliance_rate(db, fid)


# ---- ANDON ----

@router.post("/andon")
async def create_andon_event(
    data: AndonEventCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    event = await AndonService.create_event(db, fid, user.id, data.model_dump())
    return {"id": event.id, "status": str(event.status).lower() if event.status else event.status}


@router.post("/andon/{event_id}/resolve")
async def resolve_andon(
    event_id: int,
    data: AndonResolve = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    notes = data.resolution_notes if data else None
    event = await AndonService.resolve_event(db, event_id, resolution_notes=notes, factory_id=fid)
    return {"id": event.id, "resolution_time_min": event.resolution_time_min}


@router.get("/andon/status")
async def andon_current_status(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    return await AndonService.get_current_status(db, fid)


# ---- HOURLY PRODUCTION ----

@router.post("/hourly")
async def log_hourly_production(
    data: HourlyProductionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    record = await HourlyProductionService.log_hour(db, data.model_dump(), factory_id=fid)
    return {"id": record.id, "is_win": record.is_win}


@router.get("/hourly/{line_id}")
async def get_hourly_view(
    line_id: int,
    date: str = Query(..., description="Date in YYYY-MM-DD format"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    dt = datetime.fromisoformat(date)
    return await HourlyProductionService.get_day_view(db, line_id, dt, factory_id=fid)
