from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.core.security import get_current_user, require_factory
from app.models.user import User
from app.models.factory import ProductionLine
from app.schemas.lean import OEEResponse, OEESummary
from app.services.oee_calculator import OEECalculator

router = APIRouter(prefix="/oee", tags=["oee"])


async def _verify_line_ownership(db: AsyncSession, line_id: int, factory_id: int):
    from fastapi import HTTPException
    result = await db.execute(
        select(ProductionLine).where(
            ProductionLine.id == line_id,
            ProductionLine.factory_id == factory_id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Production line not in your factory")


@router.get("/summary/{line_id}")
async def get_oee_summary(
    line_id: int,
    days: int = 30,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    await _verify_line_ownership(db, line_id, fid)
    return await OEECalculator.get_line_summary(db, line_id, days)


@router.get("/trend/{line_id}")
async def get_oee_trend(
    line_id: int,
    days: int = 30,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    fid = require_factory(user)
    await _verify_line_ownership(db, line_id, fid)
    return await OEECalculator.get_trend(db, line_id, days)


@router.post("/calculate", response_model=OEEResponse)
async def calculate_oee_manual(
    planned_time_min: float,
    run_time_min: float,
    total_pieces: int,
    good_pieces: int,
    ideal_cycle_time_sec: float,
    user: User = Depends(get_current_user),
):
    """Quick OEE calculation without storing - useful for what-if scenarios."""
    return OEECalculator.calculate_oee(
        planned_time_min, run_time_min, total_pieces, good_pieces, ideal_cycle_time_sec
    )
