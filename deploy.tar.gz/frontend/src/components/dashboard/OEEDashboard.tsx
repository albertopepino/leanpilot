"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { useI18n } from "@/stores/useI18n";
import { oeeApi, adminApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type OEESummary = {
  avg_oee: number;
  avg_availability: number;
  avg_performance: number;
  avg_quality: number;
  total_downtime_min: number;
  record_count: number;
};

type OEETrendPoint = {
  date: string;
  oee: number;
  availability: number;
  performance: number;
  quality: number;
};

type ProductionLine = {
  id: number;
  name: string;
};

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */

const AUTO_REFRESH_MS = 60_000;

const WORLD_CLASS = {
  availability: 90,
  performance: 95,
  quality: 99.9,
  oee: 85,
} as const;

const PERIOD_OPTIONS = [
  { value: 7, key: "last7" },
  { value: 14, key: "last14" },
  { value: 30, key: "last30" },
  { value: 90, key: "last90" },
] as const;

/* ------------------------------------------------------------------ */
/*  Demo / fallback data                                               */
/* ------------------------------------------------------------------ */

const DEMO_SUMMARY: OEESummary = {
  avg_oee: 68.5,
  avg_availability: 84.2,
  avg_performance: 87.1,
  avg_quality: 93.4,
  total_downtime_min: 2840,
  record_count: 28,
};

const DEMO_TREND: OEETrendPoint[] = [
  { date: "2026-03-08", oee: 72, availability: 88, performance: 85, quality: 96 },
  { date: "2026-03-09", oee: 68, availability: 82, performance: 87, quality: 95 },
  { date: "2026-03-10", oee: 75, availability: 90, performance: 86, quality: 97 },
  { date: "2026-03-11", oee: 71, availability: 85, performance: 88, quality: 95 },
  { date: "2026-03-12", oee: 64, availability: 80, performance: 84, quality: 95 },
  { date: "2026-03-13", oee: 78, availability: 91, performance: 89, quality: 96 },
  { date: "2026-03-14", oee: 69, availability: 83, performance: 86, quality: 97 },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

/** Return a ring/text color class based on OEE threshold. */
function oeeColorClass(value: number): string {
  if (value >= 85) return "text-lean-green";
  if (value >= 70) return "text-lean-yellow";
  return "text-lean-red";
}

/** Return a bg color class for bars. */
function barBgClass(value: number): string {
  if (value >= 85) return "bg-lean-green";
  if (value >= 70) return "bg-lean-yellow";
  return "bg-lean-red";
}

/** Return the SVG stroke color (hex) for gauge rings. */
function gaugeStroke(value: number): string {
  if (value >= 85) return "#22c55e";
  if (value >= 70) return "#eab308";
  return "#ef4444";
}

/** Format a date string to short MM/DD or keep short labels. */
function formatDateLabel(dateStr: string): string {
  if (dateStr.length <= 5) return dateStr;
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return `${(d.getMonth() + 1).toString().padStart(2, "0")}/${d.getDate().toString().padStart(2, "0")}`;
  } catch {
    return dateStr;
  }
}

/** Compute six big losses from OEE summary (derived percentages). */
function computeSixBigLosses(s: OEESummary) {
  const a = s.avg_availability;
  const p = s.avg_performance;
  const q = s.avg_quality;
  const oee = s.avg_oee;

  const availLoss = 100 - a;
  const perfLoss = a - (a * p) / 100;
  const qualLoss = (a * p) / 100 - oee;

  return [
    { key: "plannedStops",    pct: +(availLoss * 0.6).toFixed(1),  color: "bg-red-500",    family: "availability" },
    { key: "unplannedStops",  pct: +(availLoss * 0.4).toFixed(1),  color: "bg-red-400",    family: "availability" },
    { key: "smallStops",      pct: +(perfLoss * 0.45).toFixed(1),  color: "bg-yellow-500", family: "performance" },
    { key: "slowCycles",      pct: +(perfLoss * 0.55).toFixed(1),  color: "bg-yellow-400", family: "performance" },
    { key: "defects",         pct: +(qualLoss * 0.65).toFixed(1),  color: "bg-orange-500", family: "quality" },
    { key: "startupRejects",  pct: +(qualLoss * 0.35).toFixed(1),  color: "bg-orange-400", family: "quality" },
  ];
}

/* ------------------------------------------------------------------ */
/*  Custom hook: useProductionLines                                    */
/* ------------------------------------------------------------------ */

function useProductionLines() {
  const [lines, setLines] = useState<ProductionLine[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await adminApi.getFactory();
        const factory = res.data;
        // The factory response may have a `lines` array or similar structure
        const lineList: ProductionLine[] =
          factory?.lines ??
          factory?.production_lines ??
          (Array.isArray(factory) ? factory : []);
        if (!cancelled) setLines(lineList);
      } catch {
        // Fallback: leave empty, component will handle it
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return { lines, loading };
}

/* ------------------------------------------------------------------ */
/*  Custom hook: useOEEData                                            */
/* ------------------------------------------------------------------ */

function useOEEData(lineId: number, days: number) {
  const [summary, setSummary] = useState<OEESummary>(DEMO_SUMMARY);
  const [trend, setTrend] = useState<OEETrendPoint[]>(DEMO_TREND);
  const [loading, setLoading] = useState(true);
  const [usingFallback, setUsingFallback] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchData = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      setError(null);

      try {
        const [summaryRes, trendRes] = await Promise.all([
          oeeApi.getSummary(lineId, days),
          oeeApi.getTrend(lineId, days),
        ]);

        setSummary(summaryRes.data);
        if (Array.isArray(trendRes.data) && trendRes.data.length > 0) {
          setTrend(trendRes.data);
        } else {
          // No trend data — keep DEMO_TREND as visual placeholder
          // but do NOT flag usingFallback since the API itself worked
          setTrend(DEMO_TREND);
        }
        setUsingFallback(false);
      } catch (err: any) {
        const msg =
          err?.response?.data?.detail ??
          err?.message ??
          "Failed to load OEE data";
        setError(msg);
        setSummary(DEMO_SUMMARY);
        setTrend(DEMO_TREND);
        setUsingFallback(true);
      } finally {
        setLoading(false);
      }
    },
    [lineId, days],
  );

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    intervalRef.current = setInterval(() => fetchData(true), AUTO_REFRESH_MS);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [fetchData]);

  return { summary, trend, loading, error, usingFallback, retry: () => fetchData() };
}

/* ------------------------------------------------------------------ */
/*  Main Component                                                     */
/* ------------------------------------------------------------------ */

export default function OEEDashboard({ onNavigate }: { onNavigate?: (view: string) => void }) {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();
  const { lines, loading: linesLoading } = useProductionLines();
  const [selectedLine, setSelectedLine] = useState<number>(0);
  const [days, setDays] = useState(30);

  // Auto-select the first line once loaded
  useEffect(() => {
    if (lines.length > 0 && selectedLine === 0) {
      setSelectedLine(lines[0].id);
    }
  }, [lines, selectedLine]);

  const effectiveLineId = selectedLine || 1;
  const { summary, trend, loading, error, usingFallback, retry } =
    useOEEData(effectiveLineId, days);

  const sixLosses = computeSixBigLosses(summary);
  const totalLossPct = sixLosses.reduce((s, l) => s + l.pct, 0);

  return (
    <div className="space-y-6" data-print-area="true" role="region" aria-label="OEE Dashboard">
      {/* -------- Header Controls -------- */}
      <div className="flex flex-wrap gap-3 items-center">
        {/* Line selector */}
        <select
          value={selectedLine}
          onChange={(e) => setSelectedLine(Number(e.target.value))}
          aria-label="Production line"
          className="px-3 py-2 border border-th-border rounded-lg bg-th-bg-2 text-th-text text-sm focus:ring-2 focus:ring-brand-500/40 focus:outline-none"
        >
          {linesLoading ? (
            <option>{t("dashboard.loadingLines")}</option>
          ) : lines.length === 0 ? (
            <option value={1}>{t("dashboard.noLinesAvailable")}</option>
          ) : (
            lines.map((line) => (
              <option key={line.id} value={line.id}>
                {line.name}
              </option>
            ))
          )}
        </select>

        {/* Period selector */}
        <div className="flex rounded-lg border border-th-border overflow-hidden" role="group" aria-label="Time period">
          {PERIOD_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setDays(opt.value)}
              aria-pressed={days === opt.value}
              className={`px-3 py-2 text-sm font-medium transition-colors ${
                days === opt.value
                  ? "bg-brand-500 text-white"
                  : "bg-th-bg-2 text-th-text-2 hover:bg-th-bg"
              }`}
            >
              {t(`dashboard.${opt.key}`)}
            </button>
          ))}
        </div>

        {/* Demo data badge (kept small in header for reference) */}
        {usingFallback && (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300 border border-yellow-300 dark:border-yellow-700">
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {t("dashboard.demoDataBadge")}
          </span>
        )}

        {/* Live indicator */}
        <span className="ml-auto flex items-center gap-1.5 text-xs text-th-text-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lean-green opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-lean-green" />
          </span>
          {t("dashboard.liveAutoRefresh")}
        </span>

        <ExportToolbar
          onPrint={() =>
            printView({
              title: t("common.titleDashboard"),
              subtitle: `${lines.find((l) => l.id === selectedLine)?.name || ""} — ${days} ${t("dashboard.days") || "days"}`,
            })
          }
          onExportExcel={() =>
            exportToExcel({
              filename: `OEE_Dashboard_${new Date().toISOString().slice(0, 10)}`,
              sheetName: "OEE",
              columns: [
                { key: "date", header: t("common.date"), width: 14 },
                { key: "oee", header: "OEE %", width: 10 },
                { key: "availability", header: t("dashboard.availability") || "Availability", width: 14 },
                { key: "performance", header: t("dashboard.performance") || "Performance", width: 14 },
                { key: "quality", header: t("dashboard.quality") || "Quality", width: 12 },
              ],
              rows: trend.map((p) => ({
                date: p.date,
                oee: (p.oee ?? 0).toFixed(1),
                availability: (p.availability ?? 0).toFixed(1),
                performance: (p.performance ?? 0).toFixed(1),
                quality: (p.quality ?? 0).toFixed(1),
              })),
              headerRows: [
                [
                  `${t("dashboard.avgOee") || "Avg OEE"}: ${summary.avg_oee.toFixed(1)}%`,
                  "",
                  `${t("dashboard.totalDowntime") || "Total Downtime"}: ${summary.total_downtime_min.toFixed(0)} min`,
                ],
              ],
            })
          }
        />
      </div>

      {/* -------- Error banner -------- */}
      {error && (
        <div className="flex items-center justify-between bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg px-4 py-3">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-red-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-sm text-red-700 dark:text-red-300">
              {error}
              {usingFallback && ` — ${t("dashboard.usingDemoData")}`}
            </span>
          </div>
          <button
            onClick={retry}
            className="px-3 py-1.5 text-sm font-medium text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900/40 rounded-md hover:bg-red-200 dark:hover:bg-red-900/60 transition-colors"
          >
            {t("dashboard.retry")}
          </button>
        </div>
      )}

      {/* -------- Prominent demo banner (API failed) -------- */}
      {usingFallback && !loading && (
        <div className="flex items-center justify-between bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-300 dark:border-yellow-700 rounded-lg px-4 py-3">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-yellow-600 dark:text-yellow-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
              {t("dashboard.demoBannerText")}
            </span>
          </div>
          <button
            onClick={retry}
            className="px-3 py-1.5 text-sm font-medium text-yellow-800 dark:text-yellow-200 bg-yellow-100 dark:bg-yellow-900/40 rounded-md hover:bg-yellow-200 dark:hover:bg-yellow-900/60 transition-colors"
          >
            {t("dashboard.retry")}
          </button>
        </div>
      )}

      {/* -------- Empty state (API works but no records) -------- */}
      {!loading && !usingFallback && summary.record_count === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 px-6 bg-th-bg-2 rounded-lg border border-th-border text-center">
          <svg className="w-16 h-16 text-th-text-2 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
          <h3 className="text-xl font-semibold text-th-text mb-2">
            {t("dashboard.noProductionDataYet")}
          </h3>
          <p className="text-sm text-th-text-2 max-w-md mb-6">
            {t("dashboard.oeeExplanation")}
          </p>
          <button
            onClick={() => onNavigate?.("production")}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-brand-500 text-white text-sm font-medium rounded-lg hover:bg-brand-600 transition-colors"
          >
            {t("dashboard.logFirstRecord")}
            <span aria-hidden="true">&rarr;</span>
          </button>
        </div>
      ) : (
      <>
      {/* -------- Overall OEE + 3 Gauge Cards -------- */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <SkeletonCard key={i} large={i === 0} />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <OEEGaugeCard
            label={t("dashboard.overallOee")}
            value={summary.avg_oee}
            target={WORLD_CLASS.oee}
            large
          />
          <OEEGaugeCard
            label={t("dashboard.availability")}
            value={summary.avg_availability}
            target={WORLD_CLASS.availability}
          />
          <OEEGaugeCard
            label={t("dashboard.performance")}
            value={summary.avg_performance}
            target={WORLD_CLASS.performance}
          />
          <OEEGaugeCard
            label={t("dashboard.quality")}
            value={summary.avg_quality}
            target={WORLD_CLASS.quality}
          />
        </div>
      )}

      {/* -------- Summary Stats -------- */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-th-bg-2 p-4 rounded-lg shadow-sm border border-th-border animate-pulse">
              <div className="h-4 bg-th-bg rounded w-2/3 mb-3" />
              <div className="h-7 bg-th-bg rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard
            label={t("dashboard.totalDowntime")}
            value={`${Math.floor(summary.total_downtime_min / 60)}h ${summary.total_downtime_min % 60}m`}
          />
          <StatCard
            label={t("dashboard.records")}
            value={String(summary.record_count)}
          />
          <StatCard
            label={t("dashboard.gapToWorldClass")}
            value={`${Math.max(0, WORLD_CLASS.oee - summary.avg_oee).toFixed(1)}%`}
            valueClass={summary.avg_oee >= WORLD_CLASS.oee ? "text-lean-green" : "text-lean-red"}
          />
        </div>
      )}

      {/* -------- World-Class Benchmark -------- */}
      {!loading && (
        <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
          <h3 className="text-lg font-semibold text-th-text mb-1">
            {t("dashboard.benchmark")}
          </h3>
          <p className="text-sm text-th-text-2 mb-5">
            {t("dashboard.benchmarkDesc")}
          </p>
          <BenchmarkTable summary={summary} />
        </div>
      )}

      {/* -------- OEE Trend -------- */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <h3 className="text-lg font-semibold mb-6 text-th-text">
          {t("dashboard.oeeTrend")}
        </h3>
        {loading ? <SkeletonChart /> : <OEETrendChart data={trend} />}
      </div>

      {/* -------- Six Big Losses -------- */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <h3 className="text-lg font-semibold mb-1 text-th-text">
          {t("dashboard.sixBigLosses")}
        </h3>
        <p className="text-sm text-th-text-2 mb-6">
          {t("dashboard.totalLossTime")}:{" "}
          <span className="font-semibold text-th-text">
            {totalLossPct.toFixed(1)}%
          </span>
        </p>
        {loading ? (
          <SkeletonChart />
        ) : (
          <SixBigLossesChart losses={sixLosses} totalLossPct={totalLossPct} />
        )}
      </div>

      {/* -------- OEE Waterfall -------- */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <h3 className="text-lg font-semibold mb-6 text-th-text">
          {t("dashboard.oeeWaterfall")}
        </h3>
        {loading ? <SkeletonChart /> : <OEEWaterfall summary={summary} />}
      </div>
      </>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Sub-components                                                     */
/* ================================================================== */

/* ---------- Skeleton Card ---------- */

function SkeletonCard({ large }: { large?: boolean }) {
  return (
    <div
      className={`bg-th-bg-2 p-5 rounded-lg shadow-sm border border-th-border animate-pulse ${
        large ? "ring-2 ring-brand-500/30" : ""
      }`}
    >
      <div className="flex justify-center mb-3">
        <div className={`${large ? "w-28 h-28" : "w-20 h-20"} rounded-full bg-th-bg`} />
      </div>
      <div className="h-4 bg-th-bg rounded w-1/2 mx-auto mb-2" />
      <div className="h-3 bg-th-bg rounded w-1/3 mx-auto" />
    </div>
  );
}

/* ---------- Skeleton Chart ---------- */

function SkeletonChart() {
  return (
    <div className="h-64 flex items-end gap-3 px-4 animate-pulse">
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2">
          <div
            className="w-full bg-th-bg rounded-t-md"
            style={{ height: `${30 + Math.random() * 50}%` }}
          />
          <div className="h-3 bg-th-bg rounded w-8" />
        </div>
      ))}
    </div>
  );
}

/* ---------- Stat Card ---------- */

function StatCard({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="bg-th-bg-2 p-4 rounded-lg shadow-sm border border-th-border">
      <p className="text-sm text-th-text-2">{label}</p>
      <p className={`text-2xl font-bold ${valueClass ?? "text-th-text"}`}>
        {value}
      </p>
    </div>
  );
}

/* ---------- OEE Gauge Card ---------- */

function OEEGaugeCard({
  label,
  value,
  target,
  large,
}: {
  label: string;
  value: number;
  target: number;
  large?: boolean;
}) {
  const { t } = useI18n();
  const size = large ? 112 : 80;
  const strokeWidth = large ? 8 : 6;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(value / 100, 1);
  const dashOffset = circumference * (1 - progress);
  const color = gaugeStroke(value);

  return (
    <div
      className={`bg-th-bg-2 p-5 rounded-lg shadow-sm border border-th-border text-center transition-shadow hover:shadow-md ${
        large ? "ring-2 ring-brand-500/40" : ""
      }`}
    >
      {/* SVG Ring Gauge */}
      <div className="relative inline-flex items-center justify-center mx-auto mb-3">
        <svg width={size} height={size} className="-rotate-90">
          {/* Background ring */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="currentColor"
            className="text-th-border"
            strokeWidth={strokeWidth}
          />
          {/* Progress ring */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            className="transition-all duration-700 ease-out"
          />
        </svg>
        {/* Center value */}
        <span
          className={`absolute inset-0 flex items-center justify-center font-bold ${oeeColorClass(value)} ${
            large ? "text-xl" : "text-sm"
          }`}
        >
          {value.toFixed(1)}%
        </span>
      </div>

      <p className={`font-semibold ${large ? "text-base" : "text-sm"} text-th-text`}>
        {label}
      </p>
      <p className="text-xs text-th-text-2 mt-0.5">
        {t("dashboard.target")}: {target}%
      </p>
    </div>
  );
}

/* ---------- Benchmark Table ---------- */

function BenchmarkTable({ summary }: { summary: OEESummary }) {
  const { t } = useI18n();

  const rows = [
    { key: "availability", actual: summary.avg_availability, wc: WORLD_CLASS.availability },
    { key: "performance",  actual: summary.avg_performance,  wc: WORLD_CLASS.performance },
    { key: "quality",      actual: summary.avg_quality,      wc: WORLD_CLASS.quality },
    { key: "oee",          actual: summary.avg_oee,          wc: WORLD_CLASS.oee },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-th-border">
            <th className="text-left py-2 font-medium text-th-text-2" />
            <th className="text-right py-2 font-medium text-th-text-2 px-3">
              {t("dashboard.actual")}
            </th>
            <th className="text-right py-2 font-medium text-th-text-2 px-3">
              {t("dashboard.worldClass")}
            </th>
            <th className="text-right py-2 font-medium text-th-text-2 px-3">
              {t("dashboard.gap")}
            </th>
            <th className="py-2 px-3 w-40" />
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const gap = row.wc - row.actual;
            const pctOfWc = Math.min((row.actual / row.wc) * 100, 100);
            const isLast = row.key === "oee";
            return (
              <tr
                key={row.key}
                className={`border-b border-th-border/50 ${isLast ? "font-semibold" : ""}`}
              >
                <td className="py-2.5 text-th-text">
                  {t(`dashboard.${row.key}`)}
                </td>
                <td className={`py-2.5 text-right px-3 tabular-nums ${oeeColorClass(row.actual)}`}>
                  {row.actual.toFixed(1)}%
                </td>
                <td className="py-2.5 text-right px-3 tabular-nums text-th-text-2">
                  {row.wc}%
                </td>
                <td className={`py-2.5 text-right px-3 tabular-nums ${gap > 0 ? "text-lean-red" : "text-lean-green"}`}>
                  {gap > 0 ? `-${gap.toFixed(1)}%` : `+${Math.abs(gap).toFixed(1)}%`}
                </td>
                <td className="py-2.5 px-3">
                  <div className="h-2 bg-th-bg rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${barBgClass(row.actual)}`}
                      style={{ width: `${pctOfWc}%` }}
                    />
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- OEE Trend Chart (CSS bar groups) ---------- */

function OEETrendChart({ data }: { data: OEETrendPoint[] }) {
  const { t } = useI18n();
  const Y_LABELS = [100, 75, 50, 25, 0];

  const legend = [
    { key: "oee",          color: "bg-brand-500" },
    { key: "availability", color: "bg-lean-green" },
    { key: "performance",  color: "bg-lean-yellow" },
    { key: "quality",      color: "bg-blue-400" },
  ] as const;

  return (
    <div>
      {/* Legend */}
      <div className="flex flex-wrap gap-4 mb-4">
        {legend.map((item) => (
          <span key={item.key} className="flex items-center gap-1.5 text-xs text-th-text-2">
            <span className={`inline-block w-2.5 h-2.5 rounded-sm ${item.color}`} />
            {t(`dashboard.${item.key}`)}
          </span>
        ))}
      </div>

      <div className="relative h-64 flex">
        {/* Y-axis labels */}
        <div className="flex flex-col justify-between pr-2 text-xs text-th-text-2 w-9 shrink-0 pb-7">
          {Y_LABELS.map((v) => (
            <span key={v} className="text-right leading-none">{v}%</span>
          ))}
        </div>

        {/* Chart area */}
        <div className="flex-1 relative border-l border-b border-th-border">
          {/* Grid lines */}
          {Y_LABELS.map((v) => (
            <div
              key={v}
              className="absolute left-0 right-0 border-t border-th-border/30"
              style={{ bottom: `${v}%` }}
            />
          ))}

          {/* World-class target line */}
          <div
            className="absolute left-0 right-0 border-t-2 border-dashed border-lean-green/50 z-10"
            style={{ bottom: `${WORLD_CLASS.oee}%` }}
          >
            <span className="absolute -top-4 right-0 text-[10px] font-medium text-lean-green">
              {t("dashboard.worldClass")} {WORLD_CLASS.oee}%
            </span>
          </div>

          {/* Bar groups */}
          <div className="absolute inset-0 flex items-end px-1 pb-0">
            {data.map((point, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center group" style={{ minWidth: 0 }}>
                {/* Tooltip on hover */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] text-th-text bg-th-bg-2 border border-th-border rounded px-1.5 py-0.5 mb-1 shadow-sm whitespace-nowrap pointer-events-none z-20">
                  OEE {point.oee.toFixed(1)}%
                </div>
                {/* 4 bars */}
                <div className="flex gap-px w-full justify-center items-end" style={{ height: "calc(100% - 28px)" }}>
                  {([
                    { val: point.availability, cls: "bg-lean-green" },
                    { val: point.performance, cls: "bg-lean-yellow" },
                    { val: point.quality, cls: "bg-blue-400" },
                    { val: point.oee, cls: "bg-brand-500" },
                  ] as const).map((bar, bi) => (
                    <div
                      key={bi}
                      className={`flex-1 max-w-3 rounded-t-sm ${bar.cls} transition-all duration-300 group-hover:brightness-110`}
                      style={{ height: `${Math.min(bar.val, 100)}%` }}
                    />
                  ))}
                </div>
                {/* Date label */}
                <span className="text-[10px] text-th-text-2 mt-1 truncate w-full text-center">
                  {formatDateLabel(point.date)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Six Big Losses Chart ---------- */

function SixBigLossesChart({
  losses,
  totalLossPct,
}: {
  losses: ReturnType<typeof computeSixBigLosses>;
  totalLossPct: number;
}) {
  const { t } = useI18n();

  // Family summaries
  const families = [
    { key: "availabilityLosses", color: "bg-red-500",    pct: losses.filter((l) => l.family === "availability").reduce((s, l) => s + l.pct, 0) },
    { key: "performanceLosses",  color: "bg-yellow-500", pct: losses.filter((l) => l.family === "performance").reduce((s, l) => s + l.pct, 0) },
    { key: "qualityLosses",      color: "bg-orange-500", pct: losses.filter((l) => l.family === "quality").reduce((s, l) => s + l.pct, 0) },
  ];

  return (
    <div>
      {/* Stacked overview bar */}
      <div className="mb-6">
        <div className="flex h-6 rounded-full overflow-hidden">
          {losses.map((loss) => (
            <div
              key={loss.key}
              className={`${loss.color} transition-all duration-500`}
              style={{ width: totalLossPct > 0 ? `${(loss.pct / totalLossPct) * 100}%` : "0%" }}
              title={`${t(`dashboard.${loss.key}`)}: ${loss.pct}%`}
            />
          ))}
        </div>
        <div className="flex mt-2 gap-4 flex-wrap">
          {losses.map((loss) => (
            <span key={loss.key} className="flex items-center gap-1.5 text-xs text-th-text-2">
              <span className={`inline-block w-2.5 h-2.5 rounded-sm ${loss.color}`} />
              {t(`dashboard.${loss.key}`)}
            </span>
          ))}
        </div>
      </div>

      {/* Individual horizontal bars */}
      <div className="space-y-3">
        {losses.map((loss) => {
          const widthPct = totalLossPct > 0 ? (loss.pct / totalLossPct) * 100 : 0;
          return (
            <div key={loss.key} className="group">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-th-text font-medium">
                  {t(`dashboard.${loss.key}`)}
                </span>
                <span className="text-th-text-2 tabular-nums">
                  {loss.pct.toFixed(1)}%
                </span>
              </div>
              <div className="h-5 bg-th-bg rounded overflow-hidden">
                <div
                  className={`h-full rounded ${loss.color} transition-all duration-500 group-hover:brightness-110`}
                  style={{ width: `${widthPct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Family summary */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-th-border">
        {families.map((fam) => (
          <div key={fam.key} className="text-center">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <span className={`w-2.5 h-2.5 rounded-full ${fam.color}`} />
              <span className="text-sm font-medium text-th-text">
                {t(`dashboard.${fam.key}`)}
              </span>
            </div>
            <p className="text-xl font-bold text-th-text">{fam.pct.toFixed(1)}%</p>
            <p className="text-xs text-th-text-2">
              {totalLossPct > 0 ? ((fam.pct / totalLossPct) * 100).toFixed(0) : 0}%{" "}
              {t("dashboard.totalLossTime").toLowerCase()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- OEE Waterfall ---------- */

function OEEWaterfall({ summary }: { summary: OEESummary }) {
  const { t } = useI18n();

  const a = summary.avg_availability;
  const p = summary.avg_performance;
  const q = summary.avg_quality;
  const oee = summary.avg_oee;

  const availLoss = 100 - a;
  const perfLoss = a - (a * p) / 100;
  const qualLoss = (a * p) / 100 - oee;

  const breakdownLoss = +(availLoss * 0.36).toFixed(1);
  const setupLoss = +(availLoss - breakdownLoss).toFixed(1);
  const minorStopLoss = +(perfLoss * 0.42).toFixed(1);
  const reducedSpeedLoss = +(perfLoss - minorStopLoss).toFixed(1);
  const defectLoss = +(qualLoss * 0.67).toFixed(1);
  const startupLoss = +(qualLoss - defectLoss).toFixed(1);

  type Step = {
    key: string;
    pct: number;
    type: "start" | "loss" | "subtotal" | "result";
    color?: string;
  };

  const steps: Step[] = ([
    { key: "plannedTime",      pct: 100,                                              type: "start" as const },
    { key: "breakdowns",       pct: -breakdownLoss,                                   type: "loss" as const, color: "bg-red-600" },
    { key: "setupAdjustments", pct: -setupLoss,                                       type: "loss" as const, color: "bg-red-400" },
    { key: "availability",     pct: +a.toFixed(1) as unknown as number,               type: "subtotal" as const },
    { key: "minorStops",       pct: -minorStopLoss,                                   type: "loss" as const, color: "bg-yellow-500" },
    { key: "reducedSpeed",     pct: -reducedSpeedLoss,                                type: "loss" as const, color: "bg-yellow-400" },
    { key: "performance",      pct: +((a * p) / 100).toFixed(1) as unknown as number, type: "subtotal" as const },
    { key: "defects",          pct: -defectLoss,                                      type: "loss" as const, color: "bg-orange-500" },
    { key: "startupLosses",    pct: -startupLoss,                                     type: "loss" as const, color: "bg-orange-400" },
    { key: "oee",              pct: +oee.toFixed(1) as unknown as number,             type: "result" as const },
  ] as const).map((s) => ({ ...s, pct: Number(s.pct) }));

  let running = 100;

  return (
    <div className="space-y-1.5">
      {steps.map((step) => {
        const isLoss = step.type === "loss";
        const isSubtotal = step.type === "subtotal";
        const isResult = step.type === "result";

        let barLeft: number;
        let barWidth: number;

        if (isLoss) {
          const newRunning = running + step.pct;
          barLeft = newRunning;
          barWidth = Math.abs(step.pct);
          running = newRunning;
        } else {
          barLeft = 0;
          barWidth = step.pct;
          running = step.pct;
        }

        const bgClass = isLoss
          ? step.color!
          : isResult
          ? "bg-brand-500"
          : isSubtotal
          ? "bg-brand-400/50"
          : "bg-th-bg";

        const textClass = isLoss
          ? "text-th-text"
          : isResult
          ? "text-brand-600 dark:text-brand-400 font-bold"
          : isSubtotal
          ? "text-brand-500 font-semibold"
          : "text-th-text";

        return (
          <div key={step.key} className="flex items-center gap-3 group">
            <div className="w-36 sm:w-44 shrink-0 text-right">
              <span className={`text-sm ${textClass}`}>
                {t(`dashboard.${step.key}`)}
              </span>
            </div>
            <div className="flex-1 relative h-7 bg-th-bg/40 rounded overflow-hidden">
              {isLoss && (
                <div
                  className="absolute top-0 h-full border-l border-dashed border-th-border"
                  style={{ left: `${barLeft + barWidth}%` }}
                />
              )}
              <div
                className={`absolute top-0 h-full rounded transition-all duration-500 ${bgClass} group-hover:brightness-110`}
                style={{
                  left: `${barLeft}%`,
                  width: `${barWidth}%`,
                }}
              />
            </div>
            <div className="w-16 shrink-0">
              <span className={`text-sm tabular-nums ${textClass}`}>
                {step.pct}%
              </span>
            </div>
          </div>
        );
      })}

      {/* Scale reference */}
      <div className="flex items-center gap-3 mt-2">
        <div className="w-36 sm:w-44 shrink-0" />
        <div className="flex-1 flex justify-between text-[10px] text-th-text-2 px-0.5">
          <span>0%</span>
          <span>25%</span>
          <span>50%</span>
          <span>75%</span>
          <span>100%</span>
        </div>
        <div className="w-16 shrink-0" />
      </div>
    </div>
  );
}
