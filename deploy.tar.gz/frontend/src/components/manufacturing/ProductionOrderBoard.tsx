"use client";
import { useState, useEffect, useCallback } from "react";
import { useI18n } from "@/stores/useI18n";
import { manufacturingApi, adminApi } from "@/lib/api";

// ─── Types ───────────────────────────────────────────────────────────────────

interface ProductionOrder {
  id: number;
  order_number: string;
  product_id: number;
  production_line_id: number;
  status: string;
  planned_quantity: number;
  actual_quantity_good: number;
  actual_quantity_scrap: number;
  planned_start: string | null;
  planned_end: string | null;
  actual_start: string | null;
  actual_end: string | null;
  customer_ref: string | null;
  qc_hold: boolean;
  qc_hold_reason: string | null;
  notes: string | null;
  created_at: string;
  product_name?: string;
  line_name?: string;
}

interface Product {
  id: number;
  code: string;
  name: string;
}

interface Line {
  id: number;
  name: string;
}

type StatusColumn = "planned" | "released" | "in_progress" | "on_hold" | "completed";

// ─── Component ───────────────────────────────────────────────────────────────

export default function ProductionOrderBoard() {
  const { t } = useI18n();

  const STATUS_COLUMNS: { key: StatusColumn; label: string; color: string; bg: string }[] = [
    { key: "planned", label: t("manufacturing.statusPlanned"), color: "text-gray-700", bg: "bg-gray-50 dark:bg-gray-900/30" },
    { key: "released", label: t("manufacturing.statusReleased"), color: "text-blue-700", bg: "bg-blue-50 dark:bg-blue-900/20" },
    { key: "in_progress", label: t("manufacturing.statusInProgress"), color: "text-green-700", bg: "bg-green-50 dark:bg-green-900/20" },
    { key: "on_hold", label: t("manufacturing.statusOnHold"), color: "text-red-700", bg: "bg-red-50 dark:bg-red-900/20" },
    { key: "completed", label: t("manufacturing.statusCompleted"), color: "text-purple-700", bg: "bg-purple-50 dark:bg-purple-900/20" },
  ];

  const [orders, setOrders] = useState<ProductionOrder[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [lines, setLines] = useState<Line[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  // Create form
  const [newOrder, setNewOrder] = useState({
    product_id: 0,
    production_line_id: 0,
    planned_quantity: 0,
    customer_ref: "",
    notes: "",
  });

  const fetchData = useCallback(async () => {
    try {
      const [ordersRes, productsRes, factoryRes] = await Promise.all([
        manufacturingApi.listOrders(),
        manufacturingApi.listProducts(),
        adminApi.getFactory(),
      ]);
      const ordersData = ordersRes.data ?? ordersRes;
      const productsData = productsRes.data ?? productsRes;
      const factory = factoryRes.data ?? factoryRes;

      // Enrich orders with product and line names
      const productMap = new Map<number, string>(productsData.map((p: Product) => [p.id, p.name]));
      const lineMap = new Map<number, string>((factory.production_lines || []).map((l: Line) => [l.id, l.name]));

      const enriched = (Array.isArray(ordersData) ? ordersData : []).map((o: ProductionOrder) => ({
        ...o,
        product_name: productMap.get(o.product_id) || `Product #${o.product_id}`,
        line_name: lineMap.get(o.production_line_id) || `Line #${o.production_line_id}`,
      }));

      setOrders(enriched);
      setProducts(productsData);
      setLines(factory.production_lines || []);
      setError(null);
    } catch {
      setError(t("manufacturing.failedLoadOrders"));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCreate = async () => {
    if (!newOrder.product_id || !newOrder.production_line_id || !newOrder.planned_quantity) return;
    try {
      await manufacturingApi.createOrder({
        ...newOrder,
        customer_ref: newOrder.customer_ref || undefined,
        notes: newOrder.notes || undefined,
      });
      setShowCreate(false);
      setNewOrder({ product_id: 0, production_line_id: 0, planned_quantity: 0, customer_ref: "", notes: "" });
      await fetchData();
    } catch {
      setError(t("manufacturing.failedCreateOrder"));
    }
  };

  const handleAction = async (orderId: number, action: string) => {
    setActionLoading(orderId);
    try {
      switch (action) {
        case "release":
          await manufacturingApi.releaseOrder(orderId);
          break;
        case "start":
          await manufacturingApi.startOrder(orderId);
          break;
        case "close":
          await manufacturingApi.closeOrder(orderId);
          break;
        case "hold":
          await manufacturingApi.holdOrder(orderId, "Manual hold");
          break;
        case "release-hold":
          await manufacturingApi.releaseHold(orderId);
          break;
      }
      await fetchData();
    } catch (err: any) {
      const msg = err?.response?.data?.detail?.message || err?.response?.data?.detail || "Action failed";
      setError(typeof msg === "string" ? msg : JSON.stringify(msg));
      setTimeout(() => setError(null), 5000);
    } finally {
      setActionLoading(null);
    }
  };

  const getOrdersByStatus = (status: StatusColumn) =>
    orders.filter((o) => o.status === status);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4" id="production-orders-view">
      {/* Header */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-th-text-3">
          {t("manufacturing.ordersTotal", { count: orders.length })}
        </p>
        <button
          onClick={() => setShowCreate(true)}
          className="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-sm font-semibold transition-colors"
        >
          {t("manufacturing.newOrder")}
        </button>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 px-4 py-3 rounded-xl text-sm border border-red-200 dark:border-red-800">
          {error}
        </div>
      )}

      {/* Kanban Board */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 min-h-[400px]">
        {STATUS_COLUMNS.map((col) => {
          const colOrders = getOrdersByStatus(col.key);
          return (
            <div key={col.key} className={`rounded-xl border border-th-border ${col.bg} p-3`}>
              <div className="flex items-center justify-between mb-3">
                <h3 className={`text-sm font-bold ${col.color}`}>{col.label}</h3>
                <span className="text-xs bg-white dark:bg-th-bg-2 px-2 py-0.5 rounded-full font-semibold text-th-text-2 border border-th-border">
                  {colOrders.length}
                </span>
              </div>

              <div className="space-y-2">
                {colOrders.map((order) => {
                  const progress = order.planned_quantity > 0
                    ? Math.round((order.actual_quantity_good / order.planned_quantity) * 100)
                    : 0;

                  return (
                    <div
                      key={order.id}
                      className={`bg-white dark:bg-th-bg rounded-lg border p-3 shadow-sm hover:shadow-md transition-shadow ${
                        order.qc_hold
                          ? "border-red-400 dark:border-red-600 ring-1 ring-red-200 dark:ring-red-800"
                          : "border-th-border"
                      }`}
                    >
                      {/* QC Hold Badge */}
                      {order.qc_hold && (
                        <div className="mb-2 px-2 py-1 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 text-xs font-bold rounded flex items-center gap-1">
                          <span>{t("manufacturing.qcHold")}</span>
                          {order.qc_hold_reason && (
                            <span className="font-normal truncate">- {order.qc_hold_reason}</span>
                          )}
                        </div>
                      )}

                      <div className="flex justify-between items-start mb-1">
                        <span className="text-xs font-mono font-bold text-brand-600 dark:text-brand-400">
                          {order.order_number}
                        </span>
                      </div>

                      <p className="text-sm font-semibold text-th-text truncate">{order.product_name}</p>
                      <p className="text-xs text-th-text-3">{order.line_name}</p>

                      {/* Progress bar */}
                      <div className="mt-2">
                        <div className="flex justify-between text-xs text-th-text-3 mb-0.5">
                          <span>{order.actual_quantity_good} / {order.planned_quantity}</span>
                          <span>{progress}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              progress >= 100 ? "bg-green-500" : progress > 50 ? "bg-blue-500" : "bg-amber-500"
                            }`}
                            style={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>
                      </div>

                      {order.customer_ref && (
                        <p className="text-xs text-th-text-3 mt-1 truncate">{t("manufacturing.ref")}: {order.customer_ref}</p>
                      )}

                      {/* Action buttons */}
                      <div className="mt-2 flex gap-1 flex-wrap">
                        {order.status === "planned" && (
                          <ActionBtn
                            label={t("manufacturing.actionRelease")}
                            color="blue"
                            loading={actionLoading === order.id}
                            onClick={() => handleAction(order.id, "release")}
                          />
                        )}
                        {order.status === "released" && (
                          <ActionBtn
                            label={t("manufacturing.actionStart")}
                            color="green"
                            loading={actionLoading === order.id}
                            onClick={() => handleAction(order.id, "start")}
                          />
                        )}
                        {order.status === "in_progress" && (
                          <>
                            <ActionBtn
                              label={t("manufacturing.actionHold")}
                              color="amber"
                              loading={actionLoading === order.id}
                              onClick={() => handleAction(order.id, "hold")}
                            />
                            <ActionBtn
                              label={t("manufacturing.actionClose")}
                              color="purple"
                              loading={actionLoading === order.id}
                              onClick={() => handleAction(order.id, "close")}
                            />
                          </>
                        )}
                        {order.status === "on_hold" && (
                          <ActionBtn
                            label={t("manufacturing.actionReleaseHold")}
                            color="green"
                            loading={actionLoading === order.id}
                            onClick={() => handleAction(order.id, "release-hold")}
                          />
                        )}
                      </div>
                    </div>
                  );
                })}

                {colOrders.length === 0 && (
                  <p className="text-xs text-th-text-3 text-center py-8 italic">{t("manufacturing.noOrders")}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* ═══ CREATE ORDER MODAL ═══ */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setShowCreate(false)}>
          <div className="bg-th-bg rounded-2xl shadow-xl border border-th-border w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <div className="p-5 border-b border-th-border">
              <h3 className="font-bold text-th-text text-lg">{t("manufacturing.newProductionOrder")}</h3>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-th-text-2 mb-1">{t("manufacturing.product")} *</label>
                <select
                  value={newOrder.product_id}
                  onChange={(e) => setNewOrder({ ...newOrder, product_id: Number(e.target.value) })}
                  className="w-full border border-th-border rounded-lg px-3 py-2 text-sm bg-th-bg text-th-text"
                >
                  <option value={0}>{t("manufacturing.selectProduct")}</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>{p.code} - {p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-th-text-2 mb-1">{t("manufacturing.productionLine")} *</label>
                <select
                  value={newOrder.production_line_id}
                  onChange={(e) => setNewOrder({ ...newOrder, production_line_id: Number(e.target.value) })}
                  className="w-full border border-th-border rounded-lg px-3 py-2 text-sm bg-th-bg text-th-text"
                >
                  <option value={0}>{t("manufacturing.selectLine")}</option>
                  {lines.map((l) => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-th-text-2 mb-1">{t("manufacturing.plannedQuantity")} *</label>
                <input
                  type="number"
                  min={1}
                  value={newOrder.planned_quantity || ""}
                  onChange={(e) => setNewOrder({ ...newOrder, planned_quantity: parseInt(e.target.value) || 0 })}
                  className="w-full border border-th-border rounded-lg px-3 py-2 text-sm bg-th-bg text-th-text"
                  inputMode="numeric"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-th-text-2 mb-1">{t("manufacturing.customerRef")}</label>
                <input
                  type="text"
                  value={newOrder.customer_ref}
                  onChange={(e) => setNewOrder({ ...newOrder, customer_ref: e.target.value })}
                  className="w-full border border-th-border rounded-lg px-3 py-2 text-sm bg-th-bg text-th-text"
                  placeholder={t("manufacturing.optional")}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-th-text-2 mb-1">Notes</label>
                <textarea
                  value={newOrder.notes}
                  onChange={(e) => setNewOrder({ ...newOrder, notes: e.target.value })}
                  rows={2}
                  className="w-full border border-th-border rounded-lg px-3 py-2 text-sm bg-th-bg text-th-text resize-none"
                />
              </div>
            </div>

            <div className="p-5 border-t border-th-border flex gap-3 justify-end">
              <button
                onClick={() => setShowCreate(false)}
                className="px-4 py-2 rounded-lg text-sm font-semibold text-th-text-2 hover:bg-th-bg-3"
              >
                {t("common.cancel")}
              </button>
              <button
                onClick={handleCreate}
                disabled={!newOrder.product_id || !newOrder.production_line_id || !newOrder.planned_quantity}
                className="px-5 py-2 bg-brand-600 hover:bg-brand-700 disabled:bg-gray-400 text-white rounded-lg text-sm font-bold"
              >
                {t("common.create")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionBtn({
  label,
  color,
  loading,
  onClick,
}: {
  label: string;
  color: string;
  loading: boolean;
  onClick: () => void;
}) {
  const colors: Record<string, string> = {
    blue: "bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/40 dark:text-blue-300",
    green: "bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/40 dark:text-green-300",
    amber: "bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-300",
    purple: "bg-purple-100 text-purple-700 hover:bg-purple-200 dark:bg-purple-900/40 dark:text-purple-300",
    red: "bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/40 dark:text-red-300",
  };
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className={`px-2 py-1 rounded text-xs font-semibold transition-colors ${colors[color] || colors.blue}`}
    >
      {loading ? "..." : label}
    </button>
  );
}
