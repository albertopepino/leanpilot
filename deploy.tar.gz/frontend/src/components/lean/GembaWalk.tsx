"use client";
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useI18n } from "@/stores/useI18n";
import { advancedLeanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

// ─── Types ──────────────────────────────────────────────────────────────────

type ViewMode = "new-walk" | "history" | "action-tracker";
type ObservationCategory = "Safety" | "Quality" | "Productivity" | "5S" | "Maintenance";
type Severity = "info" | "warning" | "critical";
type ActionStatus = "open" | "in-progress" | "done";

interface ActionItem {
  id: string;
  what: string;
  who: string;
  when: string;
  status: ActionStatus;
}

interface Observation {
  id: string;
  description: string;
  category: ObservationCategory;
  severity: Severity;
  photoPlaceholder: string;
  actions: ActionItem[];
}

interface GembaWalkData {
  id?: string | number;
  area: string;
  date: string;
  observations: Observation[];
  created_at?: string;
}

interface WalkHistoryItem {
  id: string | number;
  area: string;
  date: string;
  observationCount: number;
  openActions: number;
  totalActions: number;
  raw: GembaWalkData;
}

// ─── Constants ──────────────────────────────────────────────────────────────

const AREAS = [
  "Assembly Line A",
  "Assembly Line B",
  "Warehouse",
  "Packaging",
  "CNC Department",
  "Paint Shop",
  "Quality Lab",
  "Shipping Dock",
  "Maintenance Shop",
  "Office / Admin",
];

const CATEGORIES: { key: ObservationCategory; icon: string; color: string; bg: string }[] = [
  { key: "Safety", icon: "🛡️", color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800" },
  { key: "Quality", icon: "🎯", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800" },
  { key: "Productivity", icon: "⚡", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800" },
  { key: "5S", icon: "🧹", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800" },
  { key: "Maintenance", icon: "🔧", color: "text-purple-600 dark:text-purple-400", bg: "bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800" },
];

const SEVERITY_CONFIG: Record<Severity, { icon: string; color: string; bg: string; labelKey: string }> = {
  info: { icon: "ℹ️", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-100 dark:bg-blue-900/40", labelKey: "gembaSeverityInfo" },
  warning: { icon: "⚠️", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-100 dark:bg-amber-900/40", labelKey: "gembaSeverityWarning" },
  critical: { icon: "🔴", color: "text-red-600 dark:text-red-400", bg: "bg-red-100 dark:bg-red-900/40", labelKey: "gembaSeverityCritical" },
};

const ACTION_STATUS_CONFIG: Record<ActionStatus, { icon: string; color: string; labelKey: string }> = {
  open: { icon: "○", color: "text-red-600 dark:text-red-400", labelKey: "gembaStatusOpen" },
  "in-progress": { icon: "◐", color: "text-amber-600 dark:text-amber-400", labelKey: "gembaStatusInProgress" },
  done: { icon: "●", color: "text-emerald-600 dark:text-emerald-400", labelKey: "gembaStatusDone" },
};

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

// ─── Component ──────────────────────────────────────────────────────────────

export default function GembaWalk() {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();

  // ── View state ──────────────────────────────────────────────────────────
  const [view, setView] = useState<ViewMode>("new-walk");

  // ── New Walk form state ─────────────────────────────────────────────────
  const [walkArea, setWalkArea] = useState(AREAS[0]);
  const [walkDate, setWalkDate] = useState(todayISO());
  const [observations, setObservations] = useState<Observation[]>([]);

  // ── Current observation being built ─────────────────────────────────────
  const [obsDescription, setObsDescription] = useState("");
  const [obsCategory, setObsCategory] = useState<ObservationCategory>("Safety");
  const [obsSeverity, setObsSeverity] = useState<Severity>("info");
  const [obsPhoto, setObsPhoto] = useState("");
  const descRef = useRef<HTMLTextAreaElement>(null);

  // ── Action form per observation ─────────────────────────────────────────
  const [expandedObsAction, setExpandedObsAction] = useState<string | null>(null);
  const [actionWhat, setActionWhat] = useState("");
  const [actionWho, setActionWho] = useState("");
  const [actionWhen, setActionWhen] = useState("");

  // ── History + detail state ──────────────────────────────────────────────
  const [history, setHistory] = useState<WalkHistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [historyError, setHistoryError] = useState("");
  const [selectedWalk, setSelectedWalk] = useState<GembaWalkData | null>(null);

  // ── Save state ──────────────────────────────────────────────────────────
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveSuccess, setSaveSuccess] = useState(false);

  // ─── Derived: summary dashboard ─────────────────────────────────────────

  const dashboardStats = useMemo(() => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
    const thisMonthWalks = history.filter((w) => w.date >= monthStart);

    const catCounts: Record<ObservationCategory, number> = { Safety: 0, Quality: 0, Productivity: 0, "5S": 0, Maintenance: 0 };
    let totalOpen = 0;
    let totalClosed = 0;
    let totalObs = 0;

    for (const w of history) {
      totalObs += w.observationCount;
      totalOpen += w.openActions;
      totalClosed += w.totalActions - w.openActions;
      if (w.raw.observations) {
        for (const obs of w.raw.observations) {
          if (obs.category in catCounts) catCounts[obs.category]++;
        }
      }
    }

    return { walksThisMonth: thisMonthWalks.length, catCounts, totalOpen, totalClosed, totalObs };
  }, [history]);

  // ── All open actions across walks ───────────────────────────────────────

  const allOpenActions = useMemo(() => {
    const result: { walkArea: string; walkDate: string; obsDesc: string; action: ActionItem }[] = [];
    for (const w of history) {
      for (const obs of w.raw.observations ?? []) {
        for (const a of obs.actions ?? []) {
          if (a.status !== "done") {
            result.push({ walkArea: w.area, walkDate: w.date, obsDesc: obs.description, action: a });
          }
        }
      }
    }
    return result;
  }, [history]);

  // ─── API: Load History ────────────────────────────────────────────────

  const loadHistory = useCallback(async () => {
    setLoadingHistory(true);
    setHistoryError("");
    try {
      const res = await advancedLeanApi.listGembaWalks();
      const items: any[] = Array.isArray(res.data) ? res.data : [];
      setHistory(
        items.map((w: any) => {
          const obs: Observation[] = w.observations ?? [];
          let openCount = 0;
          let totalAct = 0;
          for (const o of obs) {
            for (const a of o.actions ?? []) {
              totalAct++;
              if (a.status !== "done") openCount++;
            }
          }
          return {
            id: w.id ?? uid(),
            area: w.area ?? "-",
            date: w.date ?? w.created_at?.slice(0, 10) ?? "-",
            observationCount: obs.length,
            openActions: openCount,
            totalActions: totalAct,
            raw: w,
          };
        })
      );
    } catch (err: any) {
      setHistoryError(err?.message ?? t("improvement.gembaLoadError"));
    } finally {
      setLoadingHistory(false);
    }
  }, [t]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  // ─── API: Save Walk ───────────────────────────────────────────────────

  const saveWalk = async () => {
    if (observations.length === 0) return;
    setSaving(true);
    setSaveError("");
    setSaveSuccess(false);
    try {
      await advancedLeanApi.createGembaWalk({
        area: walkArea,
        date: walkDate,
        observations: observations.map((o) => ({
          id: o.id,
          description: o.description,
          category: o.category,
          severity: o.severity,
          photoPlaceholder: o.photoPlaceholder,
          actions: o.actions.map((a) => ({
            id: a.id,
            what: a.what,
            who: a.who,
            when: a.when,
            status: a.status,
          })),
        })),
      });
      setSaveSuccess(true);
      // Reset form
      setObservations([]);
      setObsDescription("");
      setObsCategory("Safety");
      setObsSeverity("info");
      setObsPhoto("");
      setWalkArea(AREAS[0]);
      setWalkDate(todayISO());
      loadHistory();
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      setSaveError(err?.message ?? t("improvement.gembaSaveError"));
    } finally {
      setSaving(false);
    }
  };

  // ─── Observation Handlers ─────────────────────────────────────────────

  const addObservation = () => {
    if (!obsDescription.trim()) return;
    const obs: Observation = {
      id: uid(),
      description: obsDescription.trim(),
      category: obsCategory,
      severity: obsSeverity,
      photoPlaceholder: obsPhoto.trim(),
      actions: [],
    };
    setObservations((prev) => [...prev, obs]);
    setObsDescription("");
    setObsSeverity("info");
    setObsPhoto("");
    descRef.current?.focus();
  };

  const removeObservation = (id: string) => {
    setObservations((prev) => prev.filter((o) => o.id !== id));
  };

  // ─── Action Item Handlers ─────────────────────────────────────────────

  const addActionToObs = (obsId: string) => {
    if (!actionWhat.trim()) return;
    const action: ActionItem = { id: uid(), what: actionWhat.trim(), who: actionWho.trim(), when: actionWhen, status: "open" };
    setObservations((prev) =>
      prev.map((o) => (o.id === obsId ? { ...o, actions: [...o.actions, action] } : o))
    );
    setActionWhat("");
    setActionWho("");
    setActionWhen("");
    setExpandedObsAction(null);
  };

  const removeActionFromObs = (obsId: string, actionId: string) => {
    setObservations((prev) =>
      prev.map((o) =>
        o.id === obsId ? { ...o, actions: o.actions.filter((a) => a.id !== actionId) } : o
      )
    );
  };

  const cycleActionStatus = (obsId: string, actionId: string) => {
    setObservations((prev) =>
      prev.map((o) =>
        o.id === obsId
          ? {
              ...o,
              actions: o.actions.map((a) => {
                if (a.id !== actionId) return a;
                const next: ActionStatus = a.status === "open" ? "in-progress" : a.status === "in-progress" ? "done" : "open";
                return { ...a, status: next };
              }),
            }
          : o
      )
    );
  };

  // ─── Helpers ──────────────────────────────────────────────────────────

  const getCatConfig = (key: ObservationCategory) => CATEGORIES.find((c) => c.key === key)!;

  const totalActions = observations.reduce((s, o) => s + o.actions.length, 0);
  const closedActions = observations.reduce((s, o) => s + o.actions.filter((a) => a.status === "done").length, 0);

  // ─── Render ───────────────────────────────────────────────────────────

  return (
    <div className="space-y-6 max-w-5xl mx-auto" data-print-area="true">
      {/* ═══════════════ Header ═══════════════════════════════════════════ */}
      <div className="bg-gradient-to-r from-teal-500 to-emerald-600 rounded-2xl p-6 text-white shadow-glow-green">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl backdrop-blur-sm">
            🚶
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold">{t("improvement.gembaTitle")}</h2>
            <p className="text-sm text-white/80">{t("improvement.gembaSubtitle")}</p>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex gap-2 flex-wrap" role="tablist" aria-label="Gemba Walk views">
          {(
            [
              { key: "new-walk", labelKey: "gembaStartNew", icon: "+" },
              { key: "history", labelKey: "gembaViewHistory", icon: "📋" },
              { key: "action-tracker", labelKey: "gembaActionTracker", icon: "⚡" },
            ] as { key: ViewMode; labelKey: string; icon: string }[]
          ).map((v) => (
            <button
              key={v.key}
              role="tab"
              aria-selected={view === v.key}
              onClick={() => {
                setView(v.key);
                setSelectedWalk(null);
              }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition touch-check ${
                view === v.key
                  ? "bg-white/90 text-teal-700 shadow-md"
                  : "bg-white/15 text-white hover:bg-white/25"
              }`}
            >
              {v.icon} {t(`improvement.${v.labelKey}`)}
            </button>
          ))}
        </div>
      </div>

      {/* ═══════════════ Summary Dashboard ═════════════════════════════════ */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-th-bg-2 rounded-xl p-4 border border-th-border text-center">
          <div className="text-2xl font-bold text-teal-600 dark:text-teal-400">{dashboardStats.walksThisMonth}</div>
          <div className="text-xs text-th-text-2">{t("improvement.gembaWalksThisMonth")}</div>
        </div>
        <div className="bg-th-bg-2 rounded-xl p-4 border border-th-border text-center">
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{dashboardStats.totalObs}</div>
          <div className="text-xs text-th-text-2">{t("improvement.gembaTotalObs")}</div>
        </div>
        <div className="bg-th-bg-2 rounded-xl p-4 border border-th-border text-center">
          <div className="text-2xl font-bold text-red-600 dark:text-red-400">{dashboardStats.totalOpen}</div>
          <div className="text-xs text-th-text-2">{t("improvement.gembaOpenActions")}</div>
        </div>
        <div className="bg-th-bg-2 rounded-xl p-4 border border-th-border text-center">
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{dashboardStats.totalClosed}</div>
          <div className="text-xs text-th-text-2">{t("improvement.gembaClosedActions")}</div>
        </div>
      </div>

      {/* Category breakdown */}
      {dashboardStats.totalObs > 0 && (
        <div className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border">
          <h3 className="font-semibold text-th-text mb-3 text-sm">{t("improvement.gembaObsByCategory")}</h3>
          <div className="grid grid-cols-5 gap-2">
            {CATEGORIES.map((cat) => (
              <div key={cat.key} className="text-center p-2 rounded-lg bg-th-bg border border-th-border">
                <div className="text-lg">{cat.icon}</div>
                <div className={`text-lg font-bold ${cat.color}`}>{dashboardStats.catCounts[cat.key] || 0}</div>
                <div className="text-[10px] text-th-text-2 leading-tight">
                  {t(`improvement.gembaCat${cat.key}`)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════ Export Toolbar ═════════════════════════════════════ */}
      <ExportToolbar
        onPrint={() => printView(t("common.titleGemba"))}
        onExportExcel={() =>
          exportToExcel({
            title: t("common.titleGemba"),
            columns: [
              t("improvement.gembaCategory") || "Category",
              t("improvement.gembaObservation") || "Observation",
              t("improvement.gembaSeverity") || "Severity",
              t("improvement.gembaActions") || "Actions",
            ],
            rows: observations.map((obs) => [
              obs.category,
              obs.description,
              obs.severity,
              obs.actions?.map((a) => a.what).join("; ") ?? "",
            ]),
          })
        }
      />

      {/* ═══════════════ NEW WALK VIEW ═════════════════════════════════════ */}
      {view === "new-walk" && (
        <div className="space-y-5">
          {/* Walk Metadata */}
          <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border space-y-4">
            <h3 className="font-semibold text-th-text flex items-center gap-2">
              📝 {t("improvement.gembaNewWalkTitle")}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Area selector */}
              <div>
                <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.gembaArea")}</label>
                <select
                  value={walkArea}
                  onChange={(e) => setWalkArea(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-500 outline-none"
                >
                  {AREAS.map((a) => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>
              </div>
              {/* Date */}
              <div>
                <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.gembaDate")}</label>
                <input
                  type="date"
                  value={walkDate}
                  onChange={(e) => setWalkDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Add Observation Form */}
          <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border space-y-4">
            <h3 className="font-semibold text-th-text flex items-center gap-2">
              👁️ {t("improvement.gembaAddObservation")}
            </h3>

            {/* Category selector */}
            <div>
              <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.category")}</label>
              <div className="flex gap-2 flex-wrap">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.key}
                    onClick={() => setObsCategory(cat.key)}
                    className={`px-3 py-1.5 rounded-lg text-xs border transition ${
                      obsCategory === cat.key
                        ? `${cat.bg} ${cat.color} font-semibold border-current`
                        : "bg-th-bg text-th-text-2 border-th-border hover:bg-th-bg-3"
                    }`}
                  >
                    {cat.icon} {t(`improvement.gembaCat${cat.key}`)}
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.description")}</label>
              <textarea
                ref={descRef}
                value={obsDescription}
                onChange={(e) => setObsDescription(e.target.value)}
                rows={3}
                placeholder={t("improvement.describeObservation")}
                className="w-full px-3 py-2 text-sm border border-th-border rounded-lg focus:ring-2 focus:ring-teal-500 outline-none resize-none bg-th-input text-th-text"
              />
            </div>

            {/* Photo placeholder + Severity */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.gembaPhotoPlaceholder")}</label>
                <input
                  type="text"
                  value={obsPhoto}
                  onChange={(e) => setObsPhoto(e.target.value)}
                  placeholder={t("improvement.gembaPhotoHint")}
                  className="w-full px-3 py-2 text-sm border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>
              <div>
                <label className="text-xs text-th-text-2 mb-1 block">{t("improvement.gembaSeverity")}</label>
                <div className="flex gap-2">
                  {(["info", "warning", "critical"] as Severity[]).map((sev) => {
                    const cfg = SEVERITY_CONFIG[sev];
                    return (
                      <button
                        key={sev}
                        onClick={() => setObsSeverity(sev)}
                        className={`flex-1 px-3 py-1.5 rounded-lg text-xs border transition text-center ${
                          obsSeverity === sev
                            ? `${cfg.bg} ${cfg.color} font-semibold border-current`
                            : "bg-th-bg text-th-text-2 border-th-border hover:bg-th-bg-3"
                        }`}
                      >
                        {cfg.icon} {t(`improvement.${cfg.labelKey}`)}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Add button */}
            <div className="flex justify-end">
              <button
                onClick={addObservation}
                disabled={!obsDescription.trim()}
                className="px-5 py-2 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-lg font-semibold text-sm hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t("improvement.gembaAddObs")}
              </button>
            </div>
          </div>

          {/* Observations List */}
          <div className="space-y-3">
            {observations.length === 0 && (
              <div className="text-center py-12 text-th-text-3">
                <div className="text-4xl mb-3">🚶</div>
                <p className="text-sm">{t("improvement.emptyGemba")}</p>
              </div>
            )}

            {observations.map((obs, idx) => {
              const catCfg = getCatConfig(obs.category);
              const sevCfg = SEVERITY_CONFIG[obs.severity];

              return (
                <div key={obs.id} className={`rounded-xl p-4 border ${catCfg.bg} space-y-2`}>
                  {/* Header row */}
                  <div className="flex items-start gap-3">
                    <span className="text-xl mt-0.5">{catCfg.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-semibold text-th-text bg-white/60 dark:bg-white/10 px-2 py-0.5 rounded-full">
                          #{idx + 1}
                        </span>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${catCfg.color} bg-white/60 dark:bg-white/10`}>
                          {t(`improvement.gembaCat${obs.category}`)}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${sevCfg.bg} ${sevCfg.color}`}>
                          {sevCfg.icon} {t(`improvement.${sevCfg.labelKey}`)}
                        </span>
                      </div>
                      <p className="text-sm text-th-text">{obs.description}</p>
                      {obs.photoPlaceholder && (
                        <p className="text-xs text-th-text-3 mt-1">📷 {obs.photoPlaceholder}</p>
                      )}
                    </div>
                    <button
                      onClick={() => removeObservation(obs.id)}
                      className="text-th-text-3 hover:text-red-500 text-lg transition flex-shrink-0"
                      title={t("improvement.gembaRemove")}
                    >
                      ×
                    </button>
                  </div>

                  {/* Action items list */}
                  {obs.actions.length > 0 && (
                    <div className="ml-8 space-y-1.5">
                      {obs.actions.map((action) => {
                        const aCfg = ACTION_STATUS_CONFIG[action.status];
                        return (
                          <div key={action.id} className="flex items-center gap-2 text-xs bg-white/50 dark:bg-white/5 rounded-lg px-3 py-2">
                            <button
                              onClick={() => cycleActionStatus(obs.id, action.id)}
                              title={t(`improvement.${aCfg.labelKey}`)}
                              className={`w-5 h-5 rounded-full border flex-shrink-0 flex items-center justify-center transition font-bold text-[11px] ${
                                action.status === "done"
                                  ? "bg-emerald-500 border-emerald-500 text-white"
                                  : action.status === "in-progress"
                                  ? "bg-amber-400 border-amber-400 text-white"
                                  : "border-th-border hover:border-teal-400"
                              }`}
                            >
                              {aCfg.icon}
                            </button>
                            <span className={`flex-1 ${action.status === "done" ? "line-through text-th-text-3" : "text-th-text"}`}>
                              {action.what}
                            </span>
                            {action.who && <span className="text-th-text-3 hidden sm:inline">👤 {action.who}</span>}
                            {action.when && <span className="text-th-text-3 hidden sm:inline">📅 {action.when}</span>}
                            <button
                              onClick={() => removeActionFromObs(obs.id, action.id)}
                              className="text-th-text-3 hover:text-red-500 transition"
                            >
                              ×
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Add action form */}
                  <div className="ml-8">
                    {expandedObsAction === obs.id ? (
                      <div className="bg-white/60 dark:bg-white/5 rounded-lg p-3 space-y-2 border border-th-border">
                        <input
                          type="text"
                          value={actionWhat}
                          onChange={(e) => setActionWhat(e.target.value)}
                          autoFocus
                          placeholder={t("improvement.gembaActionWhat")}
                          className="w-full px-2 py-1.5 text-xs border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-400 outline-none"
                        />
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={actionWho}
                            onChange={(e) => setActionWho(e.target.value)}
                            placeholder={t("improvement.gembaActionWho")}
                            className="px-2 py-1.5 text-xs border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-400 outline-none"
                          />
                          <input
                            type="date"
                            value={actionWhen}
                            onChange={(e) => setActionWhen(e.target.value)}
                            className="px-2 py-1.5 text-xs border border-th-border rounded-lg bg-th-input text-th-text focus:ring-2 focus:ring-teal-400 outline-none"
                          />
                        </div>
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => {
                              setExpandedObsAction(null);
                              setActionWhat("");
                              setActionWho("");
                              setActionWhen("");
                            }}
                            className="px-3 py-1 text-xs text-th-text-3 hover:text-th-text transition"
                          >
                            {t("improvement.gembaCancel")}
                          </button>
                          <button
                            onClick={() => addActionToObs(obs.id)}
                            disabled={!actionWhat.trim()}
                            className="px-3 py-1 text-xs bg-teal-500 text-white rounded-lg font-semibold hover:bg-teal-600 transition disabled:opacity-50"
                          >
                            {t("improvement.addAction")}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setExpandedObsAction(obs.id)}
                        className="text-[11px] text-teal-600 dark:text-teal-400 hover:underline font-medium"
                      >
                        + {t("improvement.createAction")}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Save Walk */}
          {observations.length > 0 && (
            <div className="flex flex-col sm:flex-row items-center gap-3 justify-end">
              {saveSuccess && (
                <span className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">
                  {t("improvement.gembaSavedOk")}
                </span>
              )}
              {saveError && (
                <span className="text-sm text-red-600 dark:text-red-400 font-medium">{saveError}</span>
              )}
              <div className="text-xs text-th-text-3">
                {observations.length} {t("improvement.observations")} &middot; {totalActions} {t("improvement.actionItems")} ({closedActions} {t("improvement.gembaStatusDone")})
              </div>
              <button
                onClick={saveWalk}
                disabled={saving}
                className="px-6 py-2.5 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-xl font-semibold text-sm hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {saving ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    {t("improvement.gembaSaving")}
                  </>
                ) : (
                  <>{t("improvement.gembaSaveWalk")}</>
                )}
              </button>
            </div>
          )}
        </div>
      )}

      {/* ═══════════════ HISTORY VIEW ═════════════════════════════════════ */}
      {view === "history" && (
        <div className="space-y-4">
          {/* History detail: show selected walk */}
          {selectedWalk ? (
            <div className="space-y-4">
              <button
                onClick={() => setSelectedWalk(null)}
                className="text-sm text-teal-600 dark:text-teal-400 hover:underline font-medium"
              >
                &larr; {t("improvement.gembaBackToHistory")}
              </button>

              <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border">
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-3xl">📍</div>
                  <div>
                    <h3 className="font-bold text-th-text text-lg">{selectedWalk.area}</h3>
                    <p className="text-sm text-th-text-2">📅 {selectedWalk.date}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {(selectedWalk.observations ?? []).map((obs, idx) => {
                    const catCfg = CATEGORIES.find((c) => c.key === obs.category) ?? CATEGORIES[0];
                    const sevCfg = SEVERITY_CONFIG[obs.severity] ?? SEVERITY_CONFIG.info;
                    return (
                      <div key={obs.id ?? idx} className={`rounded-xl p-4 border ${catCfg.bg}`}>
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="text-sm">{catCfg.icon}</span>
                          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${catCfg.color} bg-white/60 dark:bg-white/10`}>
                            {t(`improvement.gembaCat${obs.category}`)}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${sevCfg.bg} ${sevCfg.color}`}>
                            {sevCfg.icon} {t(`improvement.${sevCfg.labelKey}`)}
                          </span>
                        </div>
                        <p className="text-sm text-th-text">{obs.description}</p>
                        {obs.photoPlaceholder && (
                          <p className="text-xs text-th-text-3 mt-1">📷 {obs.photoPlaceholder}</p>
                        )}
                        {(obs.actions ?? []).length > 0 && (
                          <div className="mt-2 space-y-1">
                            {obs.actions.map((a, aIdx) => {
                              const aCfg = ACTION_STATUS_CONFIG[a.status] ?? ACTION_STATUS_CONFIG.open;
                              return (
                                <div key={a.id ?? aIdx} className="flex items-center gap-2 text-xs bg-white/50 dark:bg-white/5 rounded px-3 py-1.5">
                                  <span className={aCfg.color}>{aCfg.icon}</span>
                                  <span className={`flex-1 ${a.status === "done" ? "line-through text-th-text-3" : "text-th-text"}`}>
                                    {a.what}
                                  </span>
                                  {a.who && <span className="text-th-text-3">👤 {a.who}</span>}
                                  {a.when && <span className="text-th-text-3">📅 {a.when}</span>}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* History list */
            <div className="bg-th-bg-2 rounded-xl shadow-card border border-th-border overflow-hidden">
              <div className="px-5 py-4 border-b border-th-border">
                <h3 className="font-semibold text-th-text flex items-center gap-2">
                  📋 {t("improvement.gembaWalkHistory")}
                  <span className="text-xs font-normal text-th-text-3">({history.length})</span>
                </h3>
              </div>

              {loadingHistory ? (
                <div className="p-8 text-center text-th-text-3">
                  <span className="inline-block w-5 h-5 border-2 border-th-border border-t-teal-500 rounded-full animate-spin mr-2" />
                  {t("improvement.gembaLoading")}
                </div>
              ) : historyError ? (
                <div className="p-8 text-center">
                  <p className="text-sm text-red-600 dark:text-red-400 mb-2">{historyError}</p>
                  <button onClick={loadHistory} className="text-sm text-teal-600 dark:text-teal-400 hover:underline">
                    {t("improvement.gembaRetry")}
                  </button>
                </div>
              ) : history.length === 0 ? (
                <div className="p-8 text-center text-th-text-3 text-sm">
                  {t("improvement.gembaNoHistory")}
                </div>
              ) : (
                <div>
                  {/* Table header */}
                  <div className="hidden md:grid grid-cols-12 gap-2 px-5 py-2 bg-th-bg-3 text-xs font-semibold text-th-text-2 border-b border-th-border">
                    <div className="col-span-2">{t("improvement.gembaDate")}</div>
                    <div className="col-span-4">{t("improvement.gembaArea")}</div>
                    <div className="col-span-2 text-center">{t("improvement.observations")}</div>
                    <div className="col-span-2 text-center">{t("improvement.gembaOpenActions")}</div>
                    <div className="col-span-2 text-right"></div>
                  </div>

                  <div className="divide-y divide-th-border">
                    {history.map((walk) => (
                      <button
                        key={walk.id}
                        onClick={() => setSelectedWalk(walk.raw)}
                        className="w-full grid grid-cols-1 md:grid-cols-12 gap-2 px-5 py-3 text-left hover:bg-th-bg-3 transition items-center"
                      >
                        <div className="md:col-span-2 text-sm text-th-text">📅 {walk.date}</div>
                        <div className="md:col-span-4 text-sm font-medium text-th-text truncate">📍 {walk.area}</div>
                        <div className="md:col-span-2 text-center">
                          <span className="px-2 py-1 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 font-semibold text-xs">
                            {walk.observationCount}
                          </span>
                        </div>
                        <div className="md:col-span-2 text-center">
                          {walk.openActions > 0 ? (
                            <span className="px-2 py-1 rounded-lg bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 font-semibold text-xs">
                              {walk.openActions} {t("improvement.gembaStatusOpen")}
                            </span>
                          ) : (
                            <span className="px-2 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 font-semibold text-xs">
                              {t("improvement.gembaAllClosed")}
                            </span>
                          )}
                        </div>
                        <div className="md:col-span-2 text-right text-xs text-teal-600 dark:text-teal-400 font-medium">
                          {t("improvement.gembaViewDetails")} &rarr;
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ═══════════════ ACTION TRACKER VIEW ═══════════════════════════════ */}
      {view === "action-tracker" && (
        <div className="bg-th-bg-2 rounded-xl shadow-card border border-th-border overflow-hidden">
          <div className="px-5 py-4 border-b border-th-border">
            <h3 className="font-semibold text-th-text flex items-center gap-2">
              ⚡ {t("improvement.gembaActionTracker")}
              <span className="text-xs font-normal text-th-text-3">
                ({allOpenActions.length} {t("improvement.gembaStatusOpen")})
              </span>
            </h3>
          </div>

          {loadingHistory ? (
            <div className="p-8 text-center text-th-text-3">
              <span className="inline-block w-5 h-5 border-2 border-th-border border-t-teal-500 rounded-full animate-spin mr-2" />
              {t("improvement.gembaLoading")}
            </div>
          ) : allOpenActions.length === 0 ? (
            <div className="p-8 text-center text-th-text-3 text-sm">
              {t("improvement.gembaNoOpenActions")}
            </div>
          ) : (
            <div>
              {/* Table header */}
              <div className="hidden md:grid grid-cols-12 gap-2 px-5 py-2 bg-th-bg-3 text-xs font-semibold text-th-text-2 border-b border-th-border">
                <div className="col-span-1">{t("improvement.gembaStatus")}</div>
                <div className="col-span-3">{t("improvement.gembaActionWhat")}</div>
                <div className="col-span-2">{t("improvement.gembaActionWho")}</div>
                <div className="col-span-2">{t("improvement.gembaActionWhen")}</div>
                <div className="col-span-2">{t("improvement.gembaArea")}</div>
                <div className="col-span-2">{t("improvement.gembaDate")}</div>
              </div>

              <div className="divide-y divide-th-border">
                {allOpenActions.map((item, idx) => {
                  const aCfg = ACTION_STATUS_CONFIG[item.action.status] ?? ACTION_STATUS_CONFIG.open;
                  return (
                    <div key={idx} className="grid grid-cols-1 md:grid-cols-12 gap-2 px-5 py-3 items-center hover:bg-th-bg-3 transition">
                      <div className="md:col-span-1">
                        <span className={`text-sm ${aCfg.color}`}>{aCfg.icon}</span>
                      </div>
                      <div className="md:col-span-3 text-sm text-th-text">{item.action.what}</div>
                      <div className="md:col-span-2 text-xs text-th-text-2">{item.action.who || "-"}</div>
                      <div className="md:col-span-2 text-xs text-th-text-2">{item.action.when || "-"}</div>
                      <div className="md:col-span-2 text-xs text-th-text-3">{item.walkArea}</div>
                      <div className="md:col-span-2 text-xs text-th-text-3">{item.walkDate}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
