"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { useI18n } from "@/stores/useI18n";
import { advancedLeanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type A3Status =
  | "draft"
  | "in_review"
  | "approved"
  | "implementing"
  | "completed";

interface A3Section {
  key: keyof A3Sections;
  labelKey: string;
  icon: string;
  hintKey: string;
  side: "left" | "right";
}

interface A3Sections {
  background: string;
  current_condition: string;
  goal_statement: string;
  root_cause_analysis: string;
  countermeasures: string;
  implementation_plan: string;
  follow_up: string;
  results: string;
}

interface A3Data extends A3Sections {
  title: string;
  owner: string;
  date: string;
  status: A3Status;
}

interface SavedA3 extends A3Data {
  id: number;
  created_at?: string;
  updated_at?: string;
}

/* ------------------------------------------------------------------ */
/*  Section definitions                                                */
/* ------------------------------------------------------------------ */

const SECTION_DEFS: A3Section[] = [
  { key: "background",          labelKey: "background",        icon: "\u{1F4C4}", hintKey: "backgroundHint",        side: "left"  },
  { key: "current_condition",   labelKey: "currentCondition",  icon: "\u{1F4CA}", hintKey: "currentConditionHint",  side: "left"  },
  { key: "goal_statement",      labelKey: "goalTarget",        icon: "\u{1F3AF}", hintKey: "goalTargetHint",        side: "left"  },
  { key: "root_cause_analysis", labelKey: "rootCauseAnalysis", icon: "\u{1F50D}", hintKey: "rootCauseAnalysisHint", side: "left"  },
  { key: "countermeasures",     labelKey: "countermeasures",   icon: "\u{1F4A1}", hintKey: "countermeasuresHint",   side: "right" },
  { key: "implementation_plan", labelKey: "implementationPlan",icon: "\u{1F4C5}", hintKey: "implementationPlanHint",side: "right" },
  { key: "follow_up",           labelKey: "followUp",          icon: "\u2705",    hintKey: "followUpHint",          side: "right" },
  { key: "results",             labelKey: "results",           icon: "\u{1F4C8}", hintKey: "resultsHint",           side: "right" },
];

const LEFT_SECTIONS = SECTION_DEFS.filter((s) => s.side === "left");
const RIGHT_SECTIONS = SECTION_DEFS.filter((s) => s.side === "right");

/* ------------------------------------------------------------------ */
/*  Status workflow                                                    */
/* ------------------------------------------------------------------ */

const STATUS_FLOW: A3Status[] = [
  "draft",
  "in_review",
  "approved",
  "implementing",
  "completed",
];

const STATUS_META: Record<
  A3Status,
  { labelKey: string; color: string; bg: string }
> = {
  draft: {
    labelKey: "statusDraft",
    color: "text-gray-700 dark:text-gray-300",
    bg: "bg-gray-100 border-gray-300 dark:bg-gray-800 dark:border-gray-600",
  },
  in_review: {
    labelKey: "statusInReview",
    color: "text-amber-700 dark:text-amber-300",
    bg: "bg-amber-50 border-amber-300 dark:bg-amber-950/30 dark:border-amber-600",
  },
  approved: {
    labelKey: "statusApproved",
    color: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-50 border-emerald-300 dark:bg-emerald-950/30 dark:border-emerald-600",
  },
  implementing: {
    labelKey: "statusImplementing",
    color: "text-blue-700 dark:text-blue-300",
    bg: "bg-blue-50 border-blue-300 dark:bg-blue-950/30 dark:border-blue-600",
  },
  completed: {
    labelKey: "statusCompleted",
    color: "text-violet-700 dark:text-violet-300",
    bg: "bg-violet-50 border-violet-300 dark:bg-violet-950/30 dark:border-violet-600",
  },
};

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const emptyA3 = (): A3Data => ({
  title: "",
  owner: "",
  date: new Date().toISOString().slice(0, 10),
  status: "draft",
  background: "",
  current_condition: "",
  goal_statement: "",
  root_cause_analysis: "",
  countermeasures: "",
  implementation_plan: "",
  follow_up: "",
  results: "",
});

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function A3Report() {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();

  /* ---- State ---------------------------------------------------- */
  const [data, setData] = useState<A3Data>(emptyA3());
  const [savedReports, setSavedReports] = useState<SavedA3[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [isPrintView, setIsPrintView] = useState(false);
  const [showList, setShowList] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [listError, setListError] = useState(false);
  const [feedback, setFeedback] = useState<{
    type: "ok" | "err";
    msg: string;
  } | null>(null);

  const feedbackTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  /* ---- Derived -------------------------------------------------- */
  const filledSections = SECTION_DEFS.filter(
    (s) => data[s.key]?.trim(),
  ).length;
  const progress = Math.round((filledSections / SECTION_DEFS.length) * 100);

  const nextStatus = (): A3Status | null => {
    const idx = STATUS_FLOW.indexOf(data.status);
    return idx < STATUS_FLOW.length - 1 ? STATUS_FLOW[idx + 1] : null;
  };

  /* ---- Field update --------------------------------------------- */
  const updateField = (key: string, value: string) => {
    setData((prev) => ({ ...prev, [key]: value }));
  };

  /* ---- Flash feedback ------------------------------------------- */
  const flash = useCallback((type: "ok" | "err", msg: string) => {
    setFeedback({ type, msg });
    if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
    feedbackTimer.current = setTimeout(() => setFeedback(null), 3500);
  }, []);

  /* ---- Load list from API --------------------------------------- */
  const loadList = useCallback(async () => {
    setLoading(true);
    setListError(false);
    try {
      const res = await advancedLeanApi.listA3();
      const list: SavedA3[] = Array.isArray(res.data) ? res.data : [];
      setSavedReports(list);
    } catch {
      setListError(true);
      flash("err", t("problem-solving.loadFailed"));
    } finally {
      setLoading(false);
    }
  }, [flash, t]);

  /* ---- Save to API ---------------------------------------------- */
  const handleSave = async () => {
    if (!data.title.trim()) {
      flash("err", t("problem-solving.titleRequired"));
      return;
    }
    setSaving(true);
    try {
      const res = await advancedLeanApi.createA3(data);
      const saved: SavedA3 = res.data;
      setActiveId(saved.id);
      flash("ok", t("problem-solving.saved"));
      loadList();
    } catch {
      flash("err", t("problem-solving.saveFailed"));
    } finally {
      setSaving(false);
    }
  };

  /* ---- Status transition ---------------------------------------- */
  const handleStatusChange = async (newStatus: A3Status) => {
    if (activeId && activeId > 0) {
      try {
        await advancedLeanApi.updateA3Status(
          activeId,
          newStatus,
          newStatus === "completed" ? data.results : undefined,
        );
        flash("ok", t("problem-solving.statusUpdated"));
      } catch {
        flash("err", t("problem-solving.statusFailed"));
      }
    }
    setData((prev) => ({ ...prev, status: newStatus }));
  };

  /* ---- Load a saved report into editor -------------------------- */
  const openReport = (report: SavedA3) => {
    setData({
      title: report.title,
      owner: report.owner,
      date: report.date,
      status: report.status,
      background: report.background,
      current_condition: report.current_condition,
      goal_statement: report.goal_statement,
      root_cause_analysis: report.root_cause_analysis,
      countermeasures: report.countermeasures,
      implementation_plan: report.implementation_plan,
      follow_up: report.follow_up,
      results: report.results,
    });
    setActiveId(report.id);
    setShowList(false);
  };

  /* ---- New blank report ----------------------------------------- */
  const handleNew = () => {
    setData(emptyA3());
    setActiveId(null);
  };

  /* ---- Fetch on mount ------------------------------------------- */
  useEffect(() => {
    loadList();
  }, [loadList]);

  /* ---- Cleanup timer on unmount --------------------------------- */
  useEffect(() => {
    return () => {
      if (feedbackTimer.current) clearTimeout(feedbackTimer.current);
    };
  }, []);

  /* ================================================================ */
  /*  Render helpers                                                   */
  /* ================================================================ */

  const statusMeta = STATUS_META[data.status];
  const next = nextStatus();

  const renderSectionCard = (section: A3Section) => (
    <div
      key={section.key}
      className={
        isPrintView
          ? "border border-th-border p-3 print:border-black print:p-2"
          : "bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border hover:shadow-card-hover transition"
      }
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="text-lg print:text-base">{section.icon}</span>
        <h3 className="font-semibold text-sm text-th-text print:text-xs print:text-black">
          {t(`problem-solving.${section.labelKey}`)}
        </h3>
      </div>

      {!isPrintView && (
        <p className="text-xs text-th-text-3 mb-2">
          {t(`problem-solving.${section.hintKey}`)}
        </p>
      )}

      {isPrintView ? (
        <p className="text-xs text-th-text-2 whitespace-pre-wrap print:text-black print:text-[10px] print:leading-tight min-h-[60px]">
          {data[section.key] || "\u2014"}
        </p>
      ) : (
        <textarea
          value={data[section.key]}
          onChange={(e) => updateField(section.key, e.target.value)}
          rows={5}
          className="w-full px-3 py-2 text-sm border border-th-border rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none resize-y bg-th-input text-th-text placeholder:text-th-text-3"
          placeholder={t(`problem-solving.${section.hintKey}`)}
        />
      )}
    </div>
  );

  /* ================================================================ */
  /*  RENDER                                                           */
  /* ================================================================ */

  return (
    <div className="space-y-6 max-w-7xl mx-auto print:max-w-none print:m-0 print:p-0" data-print-area="true" role="region" aria-label="A3 Report">
      {/* ---------- Feedback toast ---------- */}
      {feedback && (
        <div
          role="status"
          aria-live="polite"
          className={`fixed top-4 right-4 z-50 px-4 py-2.5 rounded-lg shadow-lg text-sm font-medium transition-all animate-in fade-in slide-in-from-top-2 ${
            feedback.type === "ok"
              ? "bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-900/80 dark:text-emerald-200 dark:border-emerald-700"
              : "bg-red-100 text-red-800 border border-red-300 dark:bg-red-900/80 dark:text-red-200 dark:border-red-700"
          }`}
        >
          {feedback.type === "ok" ? "\u2713" : "\u2717"} {feedback.msg}
        </div>
      )}

      {/* ---------- Header (hidden when printing) ---------- */}
      <div className="bg-gradient-to-r from-violet-500 to-purple-600 rounded-2xl p-6 text-white shadow-glow print:hidden">
        <div className="flex items-center gap-3 mb-3 flex-wrap">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl backdrop-blur-sm">
            {"\u{1F4CB}"}
          </div>
          <div className="flex-1 min-w-[180px]">
            <h2 className="text-xl font-bold">
              {t("problem-solving.a3Title")}
            </h2>
            <p className="text-sm text-white/80">
              {t("problem-solving.a3Subtitle")}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleNew}
              className="px-3 py-2 bg-white/20 rounded-lg text-sm hover:bg-white/30 transition backdrop-blur-sm"
            >
              {t("problem-solving.newReport")}
            </button>
            <button
              type="button"
              onClick={() => {
                setShowList(!showList);
                if (!showList) loadList();
              }}
              disabled={loading}
              className="px-3 py-2 bg-white/20 rounded-lg text-sm hover:bg-white/30 transition backdrop-blur-sm disabled:opacity-50"
            >
              {loading ? "\u2026" : t("problem-solving.loadReport")}
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="px-3 py-2 bg-white/30 rounded-lg text-sm font-semibold hover:bg-white/40 transition backdrop-blur-sm disabled:opacity-50"
            >
              {saving ? "\u2026" : t("problem-solving.saveReport")}
            </button>
            <button
              type="button"
              onClick={() => setIsPrintView(!isPrintView)}
              className="px-3 py-2 bg-white/20 rounded-lg text-sm hover:bg-white/30 transition backdrop-blur-sm"
            >
              {isPrintView
                ? t("problem-solving.editMode")
                : t("problem-solving.printView")}
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-2 bg-white/20 rounded-lg text-sm hover:bg-white/30 transition backdrop-blur-sm"
              aria-label={t("problem-solving.print")}
            >
              {"\u{1F5A8}\uFE0F"}
            </button>
          </div>
        </div>

        {/* Title input */}
        <input
          type="text"
          value={data.title}
          onChange={(e) => updateField("title", e.target.value)}
          placeholder={t("problem-solving.a3TitlePlaceholder")}
          className="w-full px-4 py-2.5 bg-white/15 backdrop-blur-sm border border-white/20 rounded-lg text-white placeholder-white/50 text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-white/40"
        />

        {/* Owner, Date, Status row */}
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs text-white/60 mb-1">
              {t("problem-solving.owner")}
            </label>
            <input
              type="text"
              value={data.owner}
              onChange={(e) => updateField("owner", e.target.value)}
              placeholder={t("problem-solving.ownerPlaceholder")}
              className="w-full px-3 py-1.5 bg-white/15 backdrop-blur-sm border border-white/20 rounded-lg text-white placeholder-white/40 text-sm focus:outline-none focus:ring-2 focus:ring-white/40"
            />
          </div>
          <div>
            <label className="block text-xs text-white/60 mb-1">
              {t("problem-solving.date")}
            </label>
            <input
              type="date"
              value={data.date}
              onChange={(e) => updateField("date", e.target.value)}
              className="w-full px-3 py-1.5 bg-white/15 backdrop-blur-sm border border-white/20 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-white/40 [color-scheme:dark]"
            />
          </div>
          <div>
            <label className="block text-xs text-white/60 mb-1">
              {t("problem-solving.status")}
            </label>
            <div className="flex items-center gap-2">
              <span
                className={`px-2.5 py-1 rounded-md text-xs font-medium border ${statusMeta.bg} ${statusMeta.color}`}
              >
                {t(`problem-solving.${statusMeta.labelKey}`)}
              </span>
              {next && (
                <button
                  type="button"
                  onClick={() => handleStatusChange(next)}
                  className="px-2.5 py-1 bg-white/20 rounded-md text-xs hover:bg-white/30 transition"
                  title={t(`problem-solving.${STATUS_META[next].labelKey}`)}
                >
                  {"→"} {t(`problem-solving.${STATUS_META[next].labelKey}`)}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-3 flex items-center gap-3">
          <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-white/80 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-sm text-white/70 tabular-nums">
            {filledSections}/{SECTION_DEFS.length}{" "}
            {t("problem-solving.sections")}
          </span>
        </div>
      </div>

      {/* ---------- Export Toolbar ---------- */}
      <ExportToolbar
        onPrint={() => printView(t("common.titleA3"))}
        onExportExcel={() =>
          exportToExcel({
            title: t("common.titleA3"),
            columns: [
              t("problem-solving.a3Title") || "Title",
              t("problem-solving.status") || "Status",
              t("problem-solving.owner") || "Owner",
              t("problem-solving.date") || "Date",
              t("problem-solving.background") || "Background",
              t("problem-solving.currentCondition") || "Current Condition",
              t("problem-solving.goalStatement") || "Goal Statement",
              t("problem-solving.rootCauseAnalysis") || "Root Cause Analysis",
              t("problem-solving.countermeasures") || "Countermeasures",
              t("problem-solving.implementationPlan") || "Implementation Plan",
              t("problem-solving.followUp") || "Follow Up",
              t("problem-solving.results") || "Results",
            ],
            rows: [
              [
                data.title,
                data.status,
                data.owner,
                data.date,
                data.background,
                data.current_condition,
                data.goal_statement,
                data.root_cause_analysis,
                data.countermeasures,
                data.implementation_plan,
                data.follow_up,
                data.results,
              ],
            ],
          })
        }
      />

      {/* ---------- Saved reports list (collapsible) ---------- */}
      {showList && (
        <div className="bg-th-bg-2 rounded-xl border border-th-border shadow-card overflow-hidden print:hidden">
          <div className="p-4 border-b border-th-border flex items-center justify-between">
            <h3 className="font-semibold text-th-text text-sm">
              {t("problem-solving.savedReports")}
            </h3>
            <button
              type="button"
              onClick={() => setShowList(false)}
              className="text-th-text-3 hover:text-th-text text-lg leading-none"
              aria-label={t("problem-solving.close")}
            >
              \u00D7
            </button>
          </div>

          {loading ? (
            <div className="p-6 flex items-center justify-center gap-2 text-th-text-3 text-sm">
              <svg
                className="animate-spin h-4 w-4"
                viewBox="0 0 24 24"
                fill="none"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                />
              </svg>
              {t("problem-solving.loading")}
            </div>
          ) : listError ? (
            <div className="p-4 text-sm text-red-600 dark:text-red-400 flex items-center justify-between">
              <span>{t("problem-solving.loadFailed")}</span>
              <button
                type="button"
                onClick={loadList}
                className="text-xs underline hover:no-underline"
              >
                {t("problem-solving.retry")}
              </button>
            </div>
          ) : savedReports.length === 0 ? (
            <p className="p-4 text-sm text-th-text-3">
              {t("problem-solving.noReports")}
            </p>
          ) : (
            <ul className="divide-y divide-th-border max-h-72 overflow-y-auto">
              {savedReports.map((r) => {
                const meta = STATUS_META[r.status] ?? STATUS_META.draft;
                return (
                  <li key={r.id}>
                    <button
                      type="button"
                      onClick={() => openReport(r)}
                      className={`w-full text-left px-4 py-3 hover:bg-th-bg-3 transition flex items-center gap-3 ${
                        activeId === r.id
                          ? "bg-th-bg-3 ring-1 ring-inset ring-brand-500"
                          : ""
                      }`}
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-th-text truncate">
                          {r.title}
                        </p>
                        <p className="text-xs text-th-text-3">
                          {r.owner} &middot; {r.date}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 px-2 py-0.5 rounded text-xs font-medium border ${meta.bg} ${meta.color}`}
                      >
                        {t(`problem-solving.${meta.labelKey}`)}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}

      {/* ---------- A3 Grid (landscape two-column layout) ---------- */}
      {isPrintView && (
        <div className="text-center mb-2 print:mb-1">
          <p className="text-xs text-th-text-3 print:hidden">
            {t("problem-solving.a3PrintHint")}
          </p>
        </div>
      )}

      <div
        className={
          isPrintView
            ? "grid grid-cols-2 gap-0 border-2 border-th-border rounded-lg overflow-hidden print:border-black print:rounded-none"
            : "grid grid-cols-1 lg:grid-cols-2 gap-4"
        }
      >
        {/* Left side: Problem / Analysis */}
        {isPrintView ? (
          <>
            {LEFT_SECTIONS.map(renderSectionCard)}
            {RIGHT_SECTIONS.map(renderSectionCard)}
          </>
        ) : (
          <>
            <div className="space-y-4">
              <div className="flex items-center gap-2 px-1">
                <div className="h-px flex-1 bg-th-border" />
                <span className="text-xs font-semibold text-th-text-3 uppercase tracking-wider">
                  {t("problem-solving.problemAnalysis")}
                </span>
                <div className="h-px flex-1 bg-th-border" />
              </div>
              {LEFT_SECTIONS.map(renderSectionCard)}
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-2 px-1">
                <div className="h-px flex-1 bg-th-border" />
                <span className="text-xs font-semibold text-th-text-3 uppercase tracking-wider">
                  {t("problem-solving.solutionAction")}
                </span>
                <div className="h-px flex-1 bg-th-border" />
              </div>
              {RIGHT_SECTIONS.map(renderSectionCard)}
            </div>
          </>
        )}
      </div>

      {/* ---------- Status workflow stepper (screen only) ---------- */}
      <div className="bg-th-bg-2 rounded-xl p-4 border border-th-border shadow-card print:hidden">
        <h3 className="text-sm font-semibold text-th-text mb-3">
          {t("problem-solving.workflow")}
        </h3>
        <div className="flex items-center gap-1 flex-wrap">
          {STATUS_FLOW.map((s, i) => {
            const meta = STATUS_META[s];
            const isActive = s === data.status;
            const isPast = STATUS_FLOW.indexOf(data.status) > i;
            return (
              <div key={s} className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleStatusChange(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                    isActive
                      ? `${meta.bg} ${meta.color} ring-2 ring-brand-500`
                      : isPast
                        ? "bg-th-bg-3 text-th-text-2 border-th-border"
                        : "bg-th-bg border-th-border text-th-text-3 hover:bg-th-bg-3"
                  }`}
                  aria-current={isActive ? "step" : undefined}
                >
                  {isPast && "\u2713 "}
                  {t(`problem-solving.${meta.labelKey}`)}
                </button>
                {i < STATUS_FLOW.length - 1 && (
                  <span className="text-th-text-3 text-xs">{"→"}</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ---------- Print header (visible only in @media print) ---- */}
      <div className="hidden print:block mb-4">
        <div className="text-center border-b-2 border-black pb-2 mb-2">
          <h1 className="text-lg font-bold">
            {data.title || t("problem-solving.a3Title")}
          </h1>
          <p className="text-xs">
            {t("problem-solving.owner")}: {data.owner || "\u2014"} &nbsp;|&nbsp;
            {t("problem-solving.date")}: {data.date} &nbsp;|&nbsp;
            {t("problem-solving.status")}:{" "}
            {t(`problem-solving.${statusMeta.labelKey}`)}
          </p>
        </div>
      </div>

      {/* ---------- Print styles ---------------------------------- */}
      <style>{`
        @media print {
          @page {
            size: A3 landscape;
            margin: 10mm;
          }
          body * { visibility: hidden; }
          .print\\:block,
          .print\\:block * { visibility: visible; }
          [class*="grid-cols-2"],
          [class*="grid-cols-2"] * {
            visibility: visible;
          }
          .print\\:hidden { display: none !important; }
        }
      `}</style>
    </div>
  );
}
