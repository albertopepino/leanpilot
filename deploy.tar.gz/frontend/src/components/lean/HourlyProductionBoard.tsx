"use client";
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useI18n } from "@/stores/useI18n";
import { advancedLeanApi, adminApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
type MissReason =
  | ""
  | "equipment"
  | "material"
  | "quality"
  | "personnel"
  | "changeover"
  | "breakdown"
  | "speed_loss"
  | "minor_stop"
  | "planned"
  | "other";

interface HourlySlot {
  hour: string;
  target: number;
  actual: number | null;
  cumulativeTarget: number;
  cumulativeActual: number | null;
  notes: string;
  reasonCode: MissReason;
  dirty: boolean;
}

interface LineOption {
  id: number;
  name: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const MISS_REASONS: MissReason[] = [
  "equipment",
  "material",
  "quality",
  "personnel",
  "changeover",
  "breakdown",
  "speed_loss",
  "minor_stop",
  "planned",
  "other",
];

const DEFAULT_SHIFT_HOURS = [
  "06:00", "07:00", "08:00", "09:00", "10:00", "11:00",
  "12:00", "13:00", "14:00", "15:00", "16:00", "17:00",
];

const DEFAULT_TARGET = 50;
const REFRESH_INTERVAL_MS = 30_000;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function getCurrentHour(): string {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, "0")}:00`;
}

function buildEmptySlots(): HourlySlot[] {
  let cumTarget = 0;
  return DEFAULT_SHIFT_HOURS.map((hour) => {
    cumTarget += DEFAULT_TARGET;
    return {
      hour,
      target: DEFAULT_TARGET,
      actual: null,
      cumulativeTarget: cumTarget,
      cumulativeActual: null,
      notes: "",
      reasonCode: "" as MissReason,
      dirty: false,
    };
  });
}

function recalcCumulatives(slots: HourlySlot[]): HourlySlot[] {
  let cumTarget = 0;
  let cumActual = 0;
  let hasActual = false;
  return slots.map((s) => {
    cumTarget += s.target;
    if (s.actual !== null) {
      cumActual += s.actual;
      hasActual = true;
    }
    return {
      ...s,
      cumulativeTarget: cumTarget,
      cumulativeActual: hasActual ? cumActual : null,
    };
  });
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function HourlyProductionBoard() {
  const { t, locale } = useI18n();
  const { printView, exportToExcel } = useExport();
  const dateLocale = locale === "it" ? "it-IT" : "en-GB";

  // --- State ---------------------------------------------------------------
  const [lines, setLines] = useState<LineOption[]>([]);
  const [linesLoading, setLinesLoading] = useState(true);
  const [selectedLineId, setSelectedLineId] = useState<number | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(() => toISODate(new Date()));
  const [slots, setSlots] = useState<HourlySlot[]>(() => buildEmptySlots());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  const refreshTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  // --- Load lines from factory ---------------------------------------------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLinesLoading(true);
      try {
        const res = await adminApi.getFactory();
        const factory = res.data;
        if (factory?.lines && Array.isArray(factory.lines) && factory.lines.length > 0) {
          const mapped = factory.lines.map((l: any) => ({ id: l.id, name: l.name }));
          if (!cancelled) {
            setLines(mapped);
            setSelectedLineId(mapped[0].id);
          }
        } else {
          // Fallback demo lines
          if (!cancelled) {
            setLines([
              { id: 1, name: t("dashboard.demoLine1") },
              { id: 2, name: t("dashboard.demoLine2") },
            ]);
            setSelectedLineId(1);
          }
        }
      } catch {
        if (!cancelled) {
          setLines([
            { id: 1, name: t("dashboard.demoLine1") },
            { id: 2, name: t("dashboard.demoLine2") },
          ]);
          setSelectedLineId(1);
        }
      } finally {
        if (!cancelled) setLinesLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [t]);

  // --- Fetch hourly data ---------------------------------------------------
  const fetchData = useCallback(async (lineId: number, date: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await advancedLeanApi.getHourlyView(lineId, date);
      const data = res.data;
      if (data && Array.isArray(data.slots) && data.slots.length > 0) {
        const mapped: HourlySlot[] = data.slots.map((s: any) => ({
          hour: s.hour ?? "00:00",
          target: s.target ?? DEFAULT_TARGET,
          actual: s.actual ?? null,
          cumulativeTarget: 0,
          cumulativeActual: null,
          notes: s.notes ?? "",
          reasonCode: (s.reasonCode ?? s.reason_code ?? "") as MissReason,
          dirty: false,
        }));
        setSlots(recalcCumulatives(mapped));
      } else {
        setSlots(buildEmptySlots());
      }
    } catch {
      setSlots(buildEmptySlots());
      setError(t("dashboard.errorLoadingData"));
    } finally {
      setLoading(false);
      setLastRefresh(new Date());
    }
  }, [t]);

  // Fetch when line/date changes
  useEffect(() => {
    if (selectedLineId !== null) {
      fetchData(selectedLineId, selectedDate);
    }
  }, [selectedLineId, selectedDate, fetchData]);

  // Auto-refresh
  useEffect(() => {
    if (selectedLineId === null) return;
    refreshTimer.current = setInterval(() => {
      fetchData(selectedLineId, selectedDate);
    }, REFRESH_INTERVAL_MS);
    return () => {
      if (refreshTimer.current) clearInterval(refreshTimer.current);
    };
  }, [selectedLineId, selectedDate, fetchData]);

  // --- Slot editing --------------------------------------------------------
  const updateSlot = (idx: number, field: "actual" | "notes" | "reasonCode", value: string) => {
    setSlots((prev) => {
      const updated = prev.map((s, i) => {
        if (i !== idx) return s;
        if (field === "actual") {
          const actual = value === "" ? null : Number(value);
          const needsReason = actual !== null && actual < s.target;
          return { ...s, actual, reasonCode: needsReason ? s.reasonCode : ("" as MissReason), dirty: true };
        }
        return { ...s, [field]: value, dirty: true };
      });
      return recalcCumulatives(updated);
    });
  };

  // --- Save single row -----------------------------------------------------
  const saveSlot = async (slot: HourlySlot) => {
    if (selectedLineId === null) return;
    setSaving(true);
    try {
      await advancedLeanApi.logHourly({
        lineId: selectedLineId,
        date: selectedDate,
        hour: slot.hour,
        target: slot.target,
        actual: slot.actual,
        notes: slot.notes,
        reasonCode: slot.reasonCode || null,
      });
      setSlots((prev) =>
        prev.map((s) => (s.hour === slot.hour ? { ...s, dirty: false } : s))
      );
    } catch {
      // keep dirty flag so user knows it wasn't saved
    } finally {
      setSaving(false);
    }
  };

  // --- Save all dirty rows -------------------------------------------------
  const saveAll = async () => {
    if (selectedLineId === null) return;
    const dirtySlots = slots.filter((s) => s.dirty);
    if (dirtySlots.length === 0) return;
    setSaving(true);
    setSaveSuccess(false);
    let hadError = false;
    for (const slot of dirtySlots) {
      try {
        await advancedLeanApi.logHourly({
          lineId: selectedLineId,
          date: selectedDate,
          hour: slot.hour,
          target: slot.target,
          actual: slot.actual,
          notes: slot.notes,
          reasonCode: slot.reasonCode || null,
        });
        setSlots((prev) =>
          prev.map((s) => (s.hour === slot.hour ? { ...s, dirty: false } : s))
        );
      } catch {
        hadError = true;
      }
    }
    setSaving(false);
    if (!hadError) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  // --- Computed KPIs -------------------------------------------------------
  const currentHour = getCurrentHour();

  const stats = useMemo(() => {
    const completed = slots.filter((s) => s.actual !== null);
    const totalTarget = completed.reduce((acc, s) => acc + s.target, 0);
    const totalActual = completed.reduce((acc, s) => acc + (s.actual ?? 0), 0);
    const wins = completed.filter((s) => (s.actual ?? 0) >= s.target).length;
    const losses = completed.length - wins;
    const variancePct = totalTarget > 0
      ? Math.round(((totalActual - totalTarget) / totalTarget) * 100)
      : 0;
    const cumDelta = totalActual - totalTarget;
    return { totalTarget, totalActual, wins, losses, variancePct, cumDelta, completedCount: completed.length };
  }, [slots]);

  const hasDirtyRows = slots.some((s) => s.dirty);

  // --- Date helpers --------------------------------------------------------
  const shiftDate = (days: number) => {
    const d = new Date(selectedDate + "T00:00:00");
    d.setDate(d.getDate() + days);
    setSelectedDate(toISODate(d));
  };

  const displayDate = new Date(selectedDate + "T00:00:00").toLocaleDateString(dateLocale, {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  const isToday = selectedDate === toISODate(new Date());

  const selectedLine = lines.find((l) => l.id === selectedLineId);
  const lineName = selectedLine?.name ?? "";

  // --- Cumulative chart data -----------------------------------------------
  const chartData = useMemo(() => {
    return slots.map((s) => ({
      hour: s.hour,
      cumTarget: s.cumulativeTarget,
      cumActual: s.cumulativeActual,
    }));
  }, [slots]);

  const chartMax = useMemo(() => {
    let max = 0;
    for (const d of chartData) {
      if (d.cumTarget > max) max = d.cumTarget;
      if (d.cumActual !== null && d.cumActual > max) max = d.cumActual;
    }
    return max || 1;
  }, [chartData]);

  // --- Render --------------------------------------------------------------
  return (
    <div className="space-y-6 max-w-6xl mx-auto" data-print-area="true" role="region" aria-label="Hourly Production Board">
      {/* ------------------------------------------------------------------ */}
      {/* Line + Date selectors                                              */}
      {/* ------------------------------------------------------------------ */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Line selector */}
        {linesLoading ? (
          <span className="text-sm text-th-text-3 animate-pulse">{t("dashboard.loadingLines")}</span>
        ) : lines.length === 0 ? (
          <span className="text-sm text-th-text-3">{t("dashboard.noLinesAvailable")}</span>
        ) : (
          <select
            value={selectedLineId ?? ""}
            onChange={(e) => setSelectedLineId(Number(e.target.value))}
            aria-label="Production line"
            className="text-sm font-semibold border border-th-border rounded-xl px-3 py-2 bg-th-input text-th-text focus:ring-2 focus:ring-brand-500 outline-none"
          >
            {lines.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        )}

        {/* Date navigation */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => shiftDate(-1)}
            className="px-2 py-2 rounded-lg border border-th-border bg-th-bg-2 text-th-text hover:bg-th-bg-3 transition text-sm"
            aria-label="Previous day"
          >
            &#8592;
          </button>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="text-sm border border-th-border rounded-xl px-3 py-2 bg-th-input text-th-text focus:ring-2 focus:ring-brand-500 outline-none"
          />
          <button
            onClick={() => shiftDate(1)}
            className="px-2 py-2 rounded-lg border border-th-border bg-th-bg-2 text-th-text hover:bg-th-bg-3 transition text-sm"
            aria-label="Next day"
          >
            &#8594;
          </button>
          {!isToday && (
            <button
              onClick={() => setSelectedDate(toISODate(new Date()))}
              className="ml-1 px-3 py-2 text-xs font-semibold rounded-xl border border-brand-300 dark:border-brand-700 text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/30 hover:bg-brand-100 dark:hover:bg-brand-900/30 transition"
            >
              {t("dashboard.today")}
            </button>
          )}
        </div>

        {/* Status badges */}
        <ExportToolbar
          onPrint={() => printView(t("common.titleHourly"))}
          onExportExcel={() =>
            exportToExcel({
              title: t("common.titleHourly"),
              columns: [
                t("dashboard.hour") || "Hour",
                t("dashboard.target") || "Target",
                t("dashboard.actual") || "Actual",
                t("dashboard.difference") || "Difference",
                t("dashboard.missReason") || "Miss Reason",
              ],
              rows: slots.map((s) => [
                s.hour,
                String(s.target),
                String(s.actual ?? ""),
                s.actual != null ? String(s.actual - s.target) : "",
                s.reasonCode || "",
              ]),
            })
          }
        />

        <div className="ml-auto flex items-center gap-2 text-xs text-th-text-3">
          {saving && (
            <span className="px-2 py-1 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 font-semibold animate-pulse">
              {t("dashboard.saving")}
            </span>
          )}
          {saveSuccess && (
            <span className="px-2 py-1 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 font-semibold">
              {t("dashboard.saveAllSuccess")}
            </span>
          )}
          <span title={lastRefresh.toLocaleTimeString(dateLocale)}>
            {t("dashboard.autoRefresh")}
          </span>
        </div>
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* Loading / Error states                                             */}
      {/* ------------------------------------------------------------------ */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="flex items-center gap-3 text-th-text-2">
            <div className="w-5 h-5 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-sm">{t("dashboard.loadingData")}</span>
          </div>
        </div>
      )}

      {error && !loading && (
        <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-2xl p-4 flex items-center justify-between">
          <span className="text-sm text-red-700 dark:text-red-400">{error}</span>
          <button
            onClick={() => selectedLineId !== null && fetchData(selectedLineId, selectedDate)}
            className="px-3 py-1 text-sm font-semibold rounded-lg bg-red-600 text-white hover:bg-red-700 transition"
          >
            {t("dashboard.retry")}
          </button>
        </div>
      )}

      {!loading && (
        <>
          {/* ---------------------------------------------------------------- */}
          {/* KPI Banner                                                       */}
          {/* ---------------------------------------------------------------- */}
          <div
            className={`rounded-2xl p-6 text-white shadow-glow ${
              stats.cumDelta >= 0
                ? "bg-gradient-to-r from-emerald-600 to-teal-600"
                : "bg-gradient-to-r from-red-600 to-rose-600"
            }`}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl backdrop-blur-sm">
                &#9201;
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold">{t("dashboard.hourlyTitle")}</h2>
                <p className="text-sm text-white/80">
                  {lineName} &mdash; {displayDate}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
                <div className="text-xl font-bold">{stats.totalTarget}</div>
                <div className="text-xs text-white/70">{t("dashboard.totalTarget")}</div>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
                <div className="text-xl font-bold">{stats.totalActual}</div>
                <div className="text-xs text-white/70">{t("dashboard.totalActual")}</div>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
                <div className="text-xl font-bold">
                  {stats.variancePct >= 0 ? "+" : ""}{stats.variancePct}%
                </div>
                <div className="text-xs text-white/70">{t("dashboard.overallVariance")}</div>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
                <div className="text-xl font-bold">{stats.wins}</div>
                <div className="text-xs text-white/70">{t("dashboard.hoursWon")}</div>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
                <div className="text-xl font-bold">{stats.losses}</div>
                <div className="text-xs text-white/70">{t("dashboard.hoursLost")}</div>
              </div>
            </div>
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* Cumulative Run Chart (CSS-based bar chart)                        */}
          {/* ---------------------------------------------------------------- */}
          <div className="bg-th-bg-2 rounded-2xl shadow-card border border-th-border p-4">
            <h3 className="text-sm font-semibold text-th-text mb-3">{t("dashboard.cumulativeChart")}</h3>
            <div className="flex items-end gap-1 h-40">
              {chartData.map((d, idx) => {
                const targetH = (d.cumTarget / chartMax) * 100;
                const actualH = d.cumActual !== null ? (d.cumActual / chartMax) * 100 : 0;
                const ahead = d.cumActual !== null && d.cumActual >= d.cumTarget;
                return (
                  <div key={d.hour} className="flex-1 flex flex-col items-center gap-0.5 h-full justify-end">
                    <div className="flex items-end gap-0.5 w-full h-full">
                      {/* Target bar */}
                      <div
                        className="flex-1 bg-gray-300 dark:bg-gray-600 rounded-t transition-all duration-300"
                        style={{ height: `${targetH}%`, minHeight: "2px" }}
                        title={`${t("dashboard.hourlyTarget")}: ${d.cumTarget}`}
                      />
                      {/* Actual bar */}
                      <div
                        className={`flex-1 rounded-t transition-all duration-300 ${
                          d.cumActual === null
                            ? "bg-gray-200 dark:bg-gray-700"
                            : ahead
                            ? "bg-emerald-500"
                            : "bg-red-500"
                        }`}
                        style={{ height: d.cumActual !== null ? `${actualH}%` : "2px", minHeight: "2px" }}
                        title={d.cumActual !== null ? `${t("dashboard.hourlyActual")}: ${d.cumActual}` : "--"}
                      />
                    </div>
                    <span className="text-[9px] text-th-text-3 leading-none mt-1">
                      {d.hour.slice(0, 2)}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-4 mt-2 text-xs text-th-text-3">
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-sm bg-gray-300 dark:bg-gray-600 inline-block" />
                {t("dashboard.cumTarget")}
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" />
                {t("dashboard.cumActual")}
              </span>
            </div>
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* Save All button                                                  */}
          {/* ---------------------------------------------------------------- */}
          <div className="flex justify-end">
            <button
              onClick={saveAll}
              disabled={!hasDirtyRows || saving}
              className={`px-5 py-2 text-sm font-semibold rounded-xl transition shadow-sm ${
                hasDirtyRows && !saving
                  ? "bg-brand-600 text-white hover:bg-brand-700"
                  : "bg-th-bg-3 text-th-text-3 cursor-not-allowed"
              }`}
            >
              {saving ? t("dashboard.saving") : t("dashboard.saveAll")}
            </button>
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* Hour-by-Hour Table                                               */}
          {/* ---------------------------------------------------------------- */}
          <div className="bg-th-bg-2 rounded-2xl shadow-card border border-th-border overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-th-bg-3 text-xs font-semibold text-th-text-2 uppercase tracking-wider">
                  <th className="p-3 text-left">{t("dashboard.hour")}</th>
                  <th className="p-3 text-center">{t("dashboard.hourlyTarget")}</th>
                  <th className="p-3 text-center">{t("dashboard.hourlyActual")}</th>
                  <th className="p-3 text-center">{t("dashboard.cumTarget")}</th>
                  <th className="p-3 text-center">{t("dashboard.cumActual")}</th>
                  <th className="p-3 text-center">{t("dashboard.variance")}</th>
                  <th className="p-3 text-center">{t("dashboard.winLoss")}</th>
                  <th className="p-3 text-left">{t("dashboard.reasonCode")}</th>
                  <th className="p-3 text-left">{t("dashboard.notes")}</th>
                  <th className="p-3 text-center w-16"></th>
                </tr>
              </thead>
              <tbody>
                {slots.map((slot, idx) => {
                  const delta = slot.actual !== null ? slot.actual - slot.target : null;
                  const isWin = delta !== null && delta >= 0;
                  const isMiss = delta !== null && delta < 0;
                  const isFuture = slot.actual === null;
                  const isCurrentHour = isToday && slot.hour === currentHour;

                  // Row background color gradient
                  let rowBg = "bg-th-bg-2";
                  if (isCurrentHour) {
                    rowBg = "ring-2 ring-inset ring-brand-400 dark:ring-brand-500 bg-brand-50/30 dark:bg-brand-950/20";
                  } else if (!isFuture && isWin) {
                    rowBg = "bg-emerald-50/50 dark:bg-emerald-950/20";
                  } else if (!isFuture && isMiss) {
                    rowBg = "bg-red-50/50 dark:bg-red-950/20";
                  } else if (isFuture) {
                    rowBg = "bg-th-bg-3/40";
                  }

                  return (
                    <tr
                      key={slot.hour}
                      className={`border-t border-th-border transition-colors ${rowBg}`}
                    >
                      {/* Hour */}
                      <td className="p-3 font-mono font-semibold text-th-text whitespace-nowrap">
                        {slot.hour}
                        {isCurrentHour && (
                          <span className="ml-1.5 inline-block w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
                        )}
                      </td>

                      {/* Target */}
                      <td className="p-3 text-center text-th-text-2">{slot.target}</td>

                      {/* Actual (editable) */}
                      <td className="p-3 text-center">
                        <input
                          type="number"
                          min={0}
                          value={slot.actual ?? ""}
                          onChange={(e) => updateSlot(idx, "actual", e.target.value)}
                          onBlur={() => { if (slot.dirty) saveSlot(slots[idx]); }}
                          className="w-16 text-center text-sm font-bold border border-th-border rounded-lg py-1 focus:ring-2 focus:ring-brand-500 outline-none bg-th-input text-th-text"
                          placeholder="--"
                        />
                      </td>

                      {/* Cumulative Target */}
                      <td className="p-3 text-center text-th-text-2 font-mono text-xs">
                        {slot.cumulativeTarget}
                      </td>

                      {/* Cumulative Actual */}
                      <td className="p-3 text-center font-mono text-xs">
                        {slot.cumulativeActual !== null ? (
                          <span className={slot.cumulativeActual >= slot.cumulativeTarget ? "text-emerald-600 dark:text-emerald-400 font-bold" : "text-red-600 dark:text-red-400 font-bold"}>
                            {slot.cumulativeActual}
                          </span>
                        ) : (
                          <span className="text-th-text-3">--</span>
                        )}
                      </td>

                      {/* Variance */}
                      <td className="p-3 text-center text-sm font-bold">
                        {delta !== null ? (
                          <span className={isWin ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}>
                            {delta >= 0 ? "+" : ""}{delta}
                          </span>
                        ) : (
                          <span className="text-th-text-3">--</span>
                        )}
                      </td>

                      {/* Win/Loss indicator */}
                      <td className="p-3 text-center">
                        {delta !== null ? (
                          isWin ? (
                            <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-emerald-500 text-white text-base font-bold" title={t("dashboard.win")}>
                              &#10003;
                            </span>
                          ) : (
                            <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-red-500 text-white text-base font-bold" title={t("dashboard.loss")}>
                              &#10007;
                            </span>
                          )
                        ) : (
                          <span className="inline-block w-7 h-7 rounded-lg bg-th-bg-3 text-th-text-3 text-center leading-7 text-xs">
                            --
                          </span>
                        )}
                      </td>

                      {/* Reason for miss */}
                      <td className="p-3">
                        {isMiss ? (
                          <select
                            value={slot.reasonCode}
                            onChange={(e) => {
                              updateSlot(idx, "reasonCode", e.target.value);
                              const updated = { ...slot, reasonCode: e.target.value as MissReason, dirty: true };
                              saveSlot(updated);
                            }}
                            className={`w-full text-xs border rounded-lg px-1.5 py-1 focus:ring-2 focus:ring-red-400 outline-none bg-th-input text-th-text ${
                              slot.reasonCode
                                ? "border-th-border"
                                : "border-red-300 dark:border-red-700 animate-pulse"
                            }`}
                          >
                            <option value="">{t("dashboard.selectReason")}</option>
                            {MISS_REASONS.map((r) => (
                              <option key={r} value={r}>
                                {t(`dashboard.reason_${r}`)}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <span className="text-xs text-th-text-3">--</span>
                        )}
                      </td>

                      {/* Notes */}
                      <td className="p-3">
                        <input
                          type="text"
                          value={slot.notes}
                          onChange={(e) => updateSlot(idx, "notes", e.target.value)}
                          onBlur={() => { if (slot.dirty) saveSlot(slots[idx]); }}
                          className="w-full text-xs border border-th-border rounded-lg px-2 py-1 focus:ring-2 focus:ring-brand-500 outline-none bg-th-input text-th-text"
                          placeholder={t("dashboard.notesPlaceholder")}
                        />
                      </td>

                      {/* Per-row save indicator */}
                      <td className="p-3 text-center">
                        {slot.dirty && (
                          <button
                            onClick={() => saveSlot(slots[idx])}
                            disabled={saving}
                            className="p-1 rounded-lg text-brand-600 dark:text-brand-400 hover:bg-brand-50 dark:hover:bg-brand-950/30 transition"
                            title={t("dashboard.saveAll")}
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* ---------------------------------------------------------------- */}
          {/* Summary Stats                                                    */}
          {/* ---------------------------------------------------------------- */}
          <div className="bg-th-bg-2 rounded-2xl shadow-card border border-th-border p-5">
            <h3 className="text-sm font-semibold text-th-text mb-3">{t("dashboard.summaryStats")}</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-th-text">{stats.totalTarget}</div>
                <div className="text-xs text-th-text-3">{t("dashboard.totalTarget")}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-th-text">{stats.totalActual}</div>
                <div className="text-xs text-th-text-3">{t("dashboard.totalActual")}</div>
              </div>
              <div className="text-center">
                <div className={`text-2xl font-bold ${stats.variancePct >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
                  {stats.variancePct >= 0 ? "+" : ""}{stats.variancePct}%
                </div>
                <div className="text-xs text-th-text-3">{t("dashboard.overallVariance")}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{stats.wins}</div>
                <div className="text-xs text-th-text-3">{t("dashboard.hoursWon")}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.losses}</div>
                <div className="text-xs text-th-text-3">{t("dashboard.hoursLost")}</div>
              </div>
            </div>

            {/* Overall progress bar */}
            {stats.totalTarget > 0 && (
              <div className="mt-4">
                <div className="flex justify-between text-xs font-semibold text-th-text-2 mb-1">
                  <span>{stats.totalActual} / {stats.totalTarget}</span>
                  <span>{Math.round((stats.totalActual / stats.totalTarget) * 100)}%</span>
                </div>
                <div className="w-full h-3 bg-th-bg-3 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      stats.totalActual >= stats.totalTarget ? "bg-emerald-500" : "bg-red-500"
                    }`}
                    style={{ width: `${Math.min((stats.totalActual / stats.totalTarget) * 100, 100)}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
