"use client";
import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { useI18n } from "@/stores/useI18n";
import { leanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface SubCause {
  text: string;
  isRoot: boolean;
}

interface Cause {
  text: string;
  isRoot: boolean;
  subCauses: SubCause[];
}

interface IshikawaData {
  title: string;
  effect: string;
  categories: Record<CategoryKey, Cause[]>;
  notes: string;
}

interface SavedIshikawa extends IshikawaData {
  id: number;
  created_at?: string;
  updated_at?: string;
}

interface Toast {
  type: "success" | "error";
  message: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */

const CATEGORIES = [
  { key: "man",         labelKey: "man",         stroke: "#3b82f6", fill: "#dbeafe", darkFill: "#1e3a5f" },
  { key: "machine",     labelKey: "machine",     stroke: "#ef4444", fill: "#fee2e2", darkFill: "#5f1e1e" },
  { key: "method",      labelKey: "method",      stroke: "#22c55e", fill: "#dcfce7", darkFill: "#1a3d1e" },
  { key: "material",    labelKey: "material",    stroke: "#eab308", fill: "#fef9c3", darkFill: "#4a3d0a" },
  { key: "measurement", labelKey: "measurement", stroke: "#a855f7", fill: "#f3e8ff", darkFill: "#3b1f5e" },
  { key: "environment", labelKey: "environment", stroke: "#f97316", fill: "#ffedd5", darkFill: "#4a2a0a" },
] as const;

type CategoryKey = (typeof CATEGORIES)[number]["key"];

const UPPER_INDICES = [0, 2, 4]; // Man, Method, Measurement
const LOWER_INDICES = [1, 3, 5]; // Machine, Material, Environment

const TOAST_DURATION_MS = 4000;

const CATEGORY_CLASSES: Record<CategoryKey, string> = {
  man:         "bg-blue-50 border-blue-300 dark:bg-blue-950/30 dark:border-blue-700",
  machine:     "bg-red-50 border-red-300 dark:bg-red-950/30 dark:border-red-700",
  method:      "bg-green-50 border-green-300 dark:bg-green-950/30 dark:border-green-700",
  material:    "bg-yellow-50 border-yellow-300 dark:bg-yellow-950/30 dark:border-yellow-700",
  measurement: "bg-purple-50 border-purple-300 dark:bg-purple-950/30 dark:border-purple-700",
  environment: "bg-orange-50 border-orange-300 dark:bg-orange-950/30 dark:border-orange-700",
};

/* ------------------------------------------------------------------ */
/*  SVG Layout Constants                                               */
/* ------------------------------------------------------------------ */

const SVG_W = 1100;
const SVG_H = 560;
const SPINE_Y = SVG_H / 2;
const SPINE_X_START = 60;
const SPINE_X_END = SVG_W - 180;
const EFFECT_BOX_X = SPINE_X_END + 8;
const EFFECT_BOX_W = 160;
const EFFECT_BOX_H = 56;
const BRANCH_ANGLE = Math.PI / 3; // 60 degrees
const BRANCH_LENGTH = 180;
const CAUSE_LENGTH = 75;

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function emptyCause(): Cause {
  return { text: "", isRoot: false, subCauses: [] };
}

function emptyCategories(): Record<CategoryKey, Cause[]> {
  return Object.fromEntries(
    CATEGORIES.map((c) => [c.key, [emptyCause()]])
  ) as Record<CategoryKey, Cause[]>;
}

function emptyForm(): IshikawaData {
  return {
    title: "",
    effect: "",
    categories: emptyCategories(),
    notes: "",
  };
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function IshikawaDiagram() {
  const { t } = useI18n();
  const { printView, exportToExcel, exportToCSV } = useExport();

  // --- form state ---
  const [title, setTitle] = useState("");
  const [effect, setEffect] = useState("");
  const [categories, setCategories] = useState<Record<CategoryKey, Cause[]>>(emptyCategories);
  const [notes, setNotes] = useState("");

  // --- UI state ---
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<Toast | null>(null);
  const [highlightedCategory, setHighlightedCategory] = useState<string | null>(null);
  const [savedAnalyses, setSavedAnalyses] = useState<SavedIshikawa[]>([]);
  const [loadingList, setLoadingList] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);

  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --- toast helper ---
  const showToast = useCallback((type: Toast["type"], message: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ type, message });
    toastTimer.current = setTimeout(() => setToast(null), TOAST_DURATION_MS);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  // --- load history on mount ---
  const loadHistory = useCallback(async () => {
    setLoadingList(true);
    try {
      const res = await leanApi.listIshikawa();
      setSavedAnalyses(res.data ?? []);
    } catch {
      /* silent */
    } finally {
      setLoadingList(false);
    }
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  // --- load a saved analysis ---
  const loadAnalysis = useCallback(
    async (id: number) => {
      try {
        const res = await leanApi.getIshikawa(id);
        const d = res.data as SavedIshikawa;
        setTitle(d.title ?? "");
        setEffect(d.effect ?? "");
        setCategories(d.categories ?? emptyCategories());
        setNotes(d.notes ?? "");
        setActiveId(d.id);
        setShowHistory(false);
        showToast("success", t("problem-solving.loaded") || "Loaded");
      } catch {
        showToast("error", t("problem-solving.loadError") || "Failed to load");
      }
    },
    [t, showToast],
  );

  // --- delete ---
  const deleteAnalysis = useCallback(
    async (id: number) => {
      try {
        await leanApi.deleteIshikawa(id);
        setSavedAnalyses((prev) => prev.filter((a) => a.id !== id));
        if (activeId === id) {
          setTitle("");
          setEffect("");
          setCategories(emptyCategories());
          setNotes("");
          setActiveId(null);
        }
        showToast("success", t("problem-solving.deleted") || "Deleted");
      } catch {
        showToast("error", t("problem-solving.deleteError") || "Delete failed");
      }
    },
    [activeId, t, showToast],
  );

  // --- save ---
  const save = useCallback(async () => {
    if (!title.trim() || !effect.trim()) {
      showToast("error", t("problem-solving.validationError") || "Title and effect are required");
      return;
    }
    setSaving(true);
    try {
      const payload: IshikawaData = { title, effect, categories, notes };
      await leanApi.createIshikawa(payload);
      showToast("success", t("problem-solving.saved") || "Analysis saved");
      loadHistory();
    } catch {
      showToast("error", t("problem-solving.saveError") || "Save failed");
    } finally {
      setSaving(false);
    }
  }, [title, effect, categories, notes, t, showToast, loadHistory]);

  // --- new analysis ---
  const resetForm = useCallback(() => {
    const fresh = emptyForm();
    setTitle(fresh.title);
    setEffect(fresh.effect);
    setCategories(fresh.categories);
    setNotes(fresh.notes);
    setActiveId(null);
    setHighlightedCategory(null);
  }, []);

  /* ---------------------------------------------------------------- */
  /*  Cause mutations                                                  */
  /* ---------------------------------------------------------------- */

  const addCause = useCallback((catKey: CategoryKey) => {
    setCategories((prev) => ({
      ...prev,
      [catKey]: [...prev[catKey], emptyCause()],
    }));
  }, []);

  const updateCauseText = useCallback((catKey: CategoryKey, idx: number, text: string) => {
    setCategories((prev) => {
      const arr = [...prev[catKey]];
      arr[idx] = { ...arr[idx], text };
      return { ...prev, [catKey]: arr };
    });
  }, []);

  const toggleCauseRoot = useCallback((catKey: CategoryKey, idx: number) => {
    setCategories((prev) => {
      const arr = [...prev[catKey]];
      arr[idx] = { ...arr[idx], isRoot: !arr[idx].isRoot };
      return { ...prev, [catKey]: arr };
    });
  }, []);

  const removeCause = useCallback((catKey: CategoryKey, idx: number) => {
    setCategories((prev) => {
      const arr = prev[catKey].filter((_, i) => i !== idx);
      return { ...prev, [catKey]: arr.length > 0 ? arr : [emptyCause()] };
    });
  }, []);

  // --- sub-causes ---
  const addSubCause = useCallback((catKey: CategoryKey, causeIdx: number) => {
    setCategories((prev) => {
      const arr = [...prev[catKey]];
      const cause = { ...arr[causeIdx] };
      cause.subCauses = [...cause.subCauses, { text: "", isRoot: false }];
      arr[causeIdx] = cause;
      return { ...prev, [catKey]: arr };
    });
  }, []);

  const updateSubCauseText = useCallback(
    (catKey: CategoryKey, causeIdx: number, subIdx: number, text: string) => {
      setCategories((prev) => {
        const arr = [...prev[catKey]];
        const cause = { ...arr[causeIdx] };
        const subs = [...cause.subCauses];
        subs[subIdx] = { ...subs[subIdx], text };
        cause.subCauses = subs;
        arr[causeIdx] = cause;
        return { ...prev, [catKey]: arr };
      });
    },
    [],
  );

  const toggleSubCauseRoot = useCallback(
    (catKey: CategoryKey, causeIdx: number, subIdx: number) => {
      setCategories((prev) => {
        const arr = [...prev[catKey]];
        const cause = { ...arr[causeIdx] };
        const subs = [...cause.subCauses];
        subs[subIdx] = { ...subs[subIdx], isRoot: !subs[subIdx].isRoot };
        cause.subCauses = subs;
        arr[causeIdx] = cause;
        return { ...prev, [catKey]: arr };
      });
    },
    [],
  );

  const removeSubCause = useCallback(
    (catKey: CategoryKey, causeIdx: number, subIdx: number) => {
      setCategories((prev) => {
        const arr = [...prev[catKey]];
        const cause = { ...arr[causeIdx] };
        cause.subCauses = cause.subCauses.filter((_, i) => i !== subIdx);
        arr[causeIdx] = cause;
        return { ...prev, [catKey]: arr };
      });
    },
    [],
  );

  const toggleHighlight = useCallback((key: string) => {
    setHighlightedCategory((prev) => (prev === key ? null : key));
  }, []);

  /* ---------------------------------------------------------------- */
  /*  SVG Branch Geometry                                              */
  /* ---------------------------------------------------------------- */

  const branchPositions = useMemo(() => {
    const spineLen = SPINE_X_END - SPINE_X_START;
    const positions: Record<string, { x: number; side: "upper" | "lower" }> = {};
    UPPER_INDICES.forEach((ci, i) => {
      positions[CATEGORIES[ci].key] = {
        x: SPINE_X_START + spineLen * ((i + 1) / 4),
        side: "upper",
      };
    });
    LOWER_INDICES.forEach((ci, i) => {
      positions[CATEGORIES[ci].key] = {
        x: SPINE_X_START + spineLen * ((i + 1) / 4),
        side: "lower",
      };
    });
    return positions;
  }, []);

  /* ---------------------------------------------------------------- */
  /*  SVG Branch Renderer                                              */
  /* ---------------------------------------------------------------- */

  const renderBranch = useCallback(
    (cat: (typeof CATEGORIES)[number]) => {
      const pos = branchPositions[cat.key];
      if (!pos) return null;

      const dir = pos.side === "upper" ? -1 : 1;
      const dx = -Math.cos(BRANCH_ANGLE) * BRANCH_LENGTH;
      const dy = dir * Math.sin(BRANCH_ANGLE) * BRANCH_LENGTH;
      const endX = pos.x + dx;
      const endY = SPINE_Y + dy;

      const causesForCat = categories[cat.key as CategoryKey] ?? [];
      const activeCauses = causesForCat.filter((c) => c.text.trim() !== "");
      const isHighlighted = highlightedCategory === null || highlightedCategory === cat.key;
      const opacity = isHighlighted ? 1 : 0.15;

      // Render each cause as a sub-branch off the main bone
      const causeElements = activeCauses.map((cause, i) => {
        const frac = activeCauses.length === 1 ? 0.5 : (i + 1) / (activeCauses.length + 1);
        const cx = pos.x + dx * frac;
        const cy = SPINE_Y + dy * frac;

        const causeAngle = pos.side === "upper" ? -Math.PI / 6 : Math.PI / 6;
        const causeDx = -Math.cos(causeAngle) * CAUSE_LENGTH;
        const causeDy = dir * Math.sin(causeAngle) * CAUSE_LENGTH * 0.4;
        const cEndX = cx + causeDx;
        const cEndY = cy + causeDy;

        const textX = cEndX - 4;
        const textY = cEndY + (dir === -1 ? -6 : 14);

        const isRoot = cause.isRoot;
        const rootSubs = cause.subCauses.filter((s) => s.isRoot);

        // Sub-cause tick marks along the cause line
        const subElements = cause.subCauses
          .filter((s) => s.text.trim())
          .map((sub, si, arr) => {
            const sFrac = arr.length === 1 ? 0.5 : (si + 1) / (arr.length + 1);
            const sx = cx + causeDx * sFrac;
            const sy = cy + causeDy * sFrac;
            const tickLen = 30;
            const tickDx = dir * tickLen * 0.3;
            const tickDy = -tickLen * 0.6;
            const stx = sx + tickDx;
            const sty = sy + tickDy;

            return (
              <g key={`sub-${cat.key}-${i}-${si}`}>
                <line
                  x1={sx} y1={sy} x2={stx} y2={sty}
                  stroke={sub.isRoot ? "#dc2626" : cat.stroke}
                  strokeWidth={1}
                  strokeDasharray={sub.isRoot ? "" : "3,2"}
                  strokeLinecap="round"
                />
                <circle cx={sx} cy={sy} r={1.8} fill={sub.isRoot ? "#dc2626" : cat.stroke} />
                <text
                  x={stx} y={sty - 3}
                  textAnchor="middle"
                  fontSize={8.5}
                  fontFamily="system-ui, sans-serif"
                  fill={sub.isRoot ? "#dc2626" : "currentColor"}
                  fontWeight={sub.isRoot ? 700 : 400}
                  className="text-th-text"
                >
                  {sub.text.length > 20 ? sub.text.slice(0, 18) + "\u2026" : sub.text}
                </text>
              </g>
            );
          });

        return (
          <g key={`${cat.key}-cause-${i}`}>
            <line
              x1={cx} y1={cy} x2={cEndX} y2={cEndY}
              stroke={isRoot ? "#dc2626" : cat.stroke}
              strokeWidth={isRoot ? 2.5 : 1.5}
              strokeLinecap="round"
            />
            <circle cx={cx} cy={cy} r={isRoot ? 3.5 : 2.5} fill={isRoot ? "#dc2626" : cat.stroke} />
            <text
              x={textX} y={textY}
              textAnchor="end"
              fontSize={isRoot ? 11 : 10.5}
              fontFamily="system-ui, sans-serif"
              fill={isRoot ? "#dc2626" : "currentColor"}
              fontWeight={isRoot ? 700 : 400}
              className="text-th-text"
            >
              {cause.text.length > 28 ? cause.text.slice(0, 26) + "\u2026" : cause.text}
            </text>
            {isRoot && (
              <text
                x={textX} y={textY + 12}
                textAnchor="end"
                fontSize={8}
                fontFamily="system-ui, sans-serif"
                fill="#dc2626"
                fontWeight={600}
              >
                ROOT
              </text>
            )}
            {subElements}
          </g>
        );
      });

      // Category label pill at the end of the branch
      const labelX = endX - 8;
      const labelY = endY + (dir === -1 ? -12 : 20);

      return (
        <g
          key={cat.key}
          opacity={opacity}
          style={{ transition: "opacity 0.3s ease", cursor: "pointer" }}
          onClick={() => toggleHighlight(cat.key)}
        >
          {/* Main branch line */}
          <line
            x1={pos.x} y1={SPINE_Y}
            x2={endX} y2={endY}
            stroke={cat.stroke}
            strokeWidth={2.5}
            strokeLinecap="round"
          />
          {/* Arrowhead */}
          <polygon
            points={(() => {
              const aLen = 10;
              const angle = Math.atan2(endY - SPINE_Y, endX - pos.x);
              const lx = endX - aLen * Math.cos(angle - 0.35);
              const ly = endY - aLen * Math.sin(angle - 0.35);
              const rx = endX - aLen * Math.cos(angle + 0.35);
              const ry = endY - aLen * Math.sin(angle + 0.35);
              return `${endX},${endY} ${lx},${ly} ${rx},${ry}`;
            })()}
            fill={cat.stroke}
          />

          {/* Category label pill */}
          <rect
            x={labelX - 48} y={labelY - 13}
            width={96} height={22}
            rx={11} ry={11}
            fill={cat.stroke}
            fillOpacity={0.12}
            stroke={cat.stroke}
            strokeWidth={1}
          />
          <text
            x={labelX} y={labelY + 2}
            textAnchor="middle"
            fontSize={11.5}
            fontWeight={600}
            fontFamily="system-ui, sans-serif"
            fill={cat.stroke}
          >
            {t(`problem-solving.${cat.labelKey}`)}
          </text>

          {causeElements}
        </g>
      );
    },
    [categories, highlightedCategory, branchPositions, t, toggleHighlight],
  );

  /* ---------------------------------------------------------------- */
  /*  Render                                                           */
  /* ---------------------------------------------------------------- */

  return (
    <div className="space-y-6" data-print-area="true">
      {/* === Toast === */}
      {toast && (
        <div
          className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-lg shadow-lg text-sm font-medium text-white transition-all ${
            toast.type === "success" ? "bg-emerald-600" : "bg-red-600"
          }`}
        >
          {toast.message}
        </div>
      )}

      {/* === Top bar: Title + Actions === */}
      <div className="bg-th-bg-2 p-4 rounded-lg shadow-sm border border-th-border flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-th-border rounded-lg bg-th-input text-th-text text-sm font-semibold"
            placeholder={t("problem-solving.analysisTitle") || "Analysis title\u2026"}
          />
        </div>
        <ExportToolbar
          onPrint={() => printView({ title: t("problem-solving.ishikawaTitle") || "Ishikawa Diagram", subtitle: title || effect })}
          onExportExcel={() => {
            const rows: Record<string, any>[] = [];
            for (const cat of CATEGORIES) {
              const causes = categories[cat.key as CategoryKey] || [];
              for (const cause of causes) {
                rows.push({ category: t(`problem-solving.${cat.labelKey}`) || cat.key, cause: cause.text, root: cause.isRoot ? "Yes" : "", effect });
                for (const sub of cause.subCauses) {
                  rows.push({ category: t(`problem-solving.${cat.labelKey}`) || cat.key, cause: `  └ ${sub.text}`, root: sub.isRoot ? "Yes" : "", effect });
                }
              }
            }
            exportToExcel({
              filename: `ishikawa_${title || "analysis"}`,
              sheetName: "Ishikawa",
              columns: [
                { key: "category", header: t("problem-solving.category") || "Category", width: 18 },
                { key: "cause", header: t("problem-solving.cause") || "Cause", width: 35 },
                { key: "root", header: t("problem-solving.rootCause") || "Root Cause", width: 12 },
                { key: "effect", header: t("problem-solving.effect") || "Effect", width: 30 },
              ],
              rows,
              headerRows: [[t("problem-solving.effect") || "Effect", effect]],
            });
          }}
          onExportCSV={() => {
            const rows: Record<string, any>[] = [];
            for (const cat of CATEGORIES) {
              const causes = categories[cat.key as CategoryKey] || [];
              for (const cause of causes) {
                rows.push({ category: t(`problem-solving.${cat.labelKey}`) || cat.key, cause: cause.text, root: cause.isRoot ? "Yes" : "", effect });
                for (const sub of cause.subCauses) {
                  rows.push({ category: t(`problem-solving.${cat.labelKey}`) || cat.key, cause: `  └ ${sub.text}`, root: sub.isRoot ? "Yes" : "", effect });
                }
              }
            }
            exportToCSV({
              filename: `ishikawa_${title || "analysis"}`,
              columns: [
                { key: "category", header: t("problem-solving.category") || "Category" },
                { key: "cause", header: t("problem-solving.cause") || "Cause" },
                { key: "root", header: t("problem-solving.rootCause") || "Root Cause" },
                { key: "effect", header: t("problem-solving.effect") || "Effect" },
              ],
              rows,
            });
          }}
        />
        <button
          onClick={save}
          disabled={saving}
          className="bg-brand-600 text-white px-5 py-2 rounded-lg hover:bg-brand-700 disabled:opacity-50 text-sm font-medium"
        >
          {saving
            ? t("problem-solving.saving") || "Saving\u2026"
            : t("problem-solving.saveIshikawa") || "Save"}
        </button>
        <button
          onClick={resetForm}
          className="bg-th-bg text-th-text-2 px-4 py-2 rounded-lg hover:bg-th-bg-3 border border-th-border text-sm"
        >
          {t("problem-solving.newAnalysis") || "New Analysis"}
        </button>
        <button
          onClick={() => {
            setShowHistory((p) => !p);
            if (!showHistory) loadHistory();
          }}
          className="bg-th-bg text-th-text-2 px-4 py-2 rounded-lg hover:bg-th-bg-3 border border-th-border text-sm"
        >
          {t("problem-solving.history") || "History"}
        </button>
      </div>

      {/* === History Panel === */}
      {showHistory && (
        <div className="bg-th-bg-2 rounded-xl border border-th-border shadow-card overflow-hidden">
          <div className="p-4 border-b border-th-border flex items-center justify-between">
            <h3 className="font-semibold text-th-text text-sm">
              {t("problem-solving.savedAnalyses") || "Saved Analyses"}
            </h3>
            <button
              onClick={() => setShowHistory(false)}
              className="text-th-text-3 hover:text-th-text text-lg leading-none"
            >
              &times;
            </button>
          </div>
          {loadingList ? (
            <p className="p-4 text-sm text-th-text-3">
              {t("problem-solving.loading") || "Loading\u2026"}
            </p>
          ) : savedAnalyses.length === 0 ? (
            <p className="p-4 text-sm text-th-text-3">
              {t("problem-solving.noAnalyses") || "No saved analyses yet."}
            </p>
          ) : (
            <ul className="divide-y divide-th-border max-h-64 overflow-y-auto">
              {savedAnalyses.map((a) => (
                <li key={a.id} className="flex items-center justify-between px-4 py-3 hover:bg-th-bg-3 transition">
                  <button
                    onClick={() => loadAnalysis(a.id)}
                    className="flex-1 text-left"
                  >
                    <p className="text-sm font-medium text-th-text truncate">{a.title || a.effect}</p>
                    <p className="text-xs text-th-text-3">
                      {a.created_at
                        ? new Date(a.created_at).toLocaleDateString()
                        : ""}
                    </p>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteAnalysis(a.id);
                    }}
                    className="ml-2 text-th-text-3 hover:text-red-500 text-xs"
                    title={t("problem-solving.delete") || "Delete"}
                  >
                    &times;
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* === SVG Fishbone Diagram === */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-th-text">
            {t("problem-solving.ishikawaTitle") || "Ishikawa Diagram"}
          </h3>
          {highlightedCategory && (
            <button
              onClick={() => setHighlightedCategory(null)}
              className="text-xs text-th-text-3 hover:text-th-text px-3 py-1 rounded border border-th-border"
            >
              {t("problem-solving.showAll") || "Show all branches"}
            </button>
          )}
        </div>

        <div className="w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${SVG_W} ${SVG_H}`}
            className="w-full h-auto min-w-[700px]"
            xmlns="http://www.w3.org/2000/svg"
            role="img"
            aria-label={t("problem-solving.ishikawaTitle") || "Ishikawa Diagram"}
          >
            {/* Defs */}
            <defs>
              <marker
                id="spine-arrow"
                markerWidth="12" markerHeight="10"
                refX="10" refY="5"
                orient="auto"
                markerUnits="userSpaceOnUse"
              >
                <path d="M 0 1 L 10 5 L 0 9 Z" fill="#64748b" />
              </marker>
              <filter id="effectShadow" x="-10%" y="-10%" width="130%" height="140%">
                <feDropShadow dx="1" dy="2" stdDeviation="3" floodColor="#00000030" />
              </filter>
            </defs>

            {/* Spine */}
            <line
              x1={SPINE_X_START} y1={SPINE_Y}
              x2={SPINE_X_END} y2={SPINE_Y}
              stroke="#64748b"
              strokeWidth={3}
              markerEnd="url(#spine-arrow)"
            />

            {/* Dots on spine for polish */}
            {Array.from({ length: 5 }).map((_, i) => {
              const dotX = SPINE_X_START + ((SPINE_X_END - SPINE_X_START) * (i + 1)) / 6;
              return (
                <circle key={`dot-${i}`} cx={dotX} cy={SPINE_Y} r={2} fill="#94a3b8" opacity={0.3} />
              );
            })}

            {/* Branches */}
            {CATEGORIES.map((cat) => renderBranch(cat))}

            {/* Effect box (fish head) */}
            <g>
              <rect
                x={EFFECT_BOX_X}
                y={SPINE_Y - EFFECT_BOX_H / 2}
                width={EFFECT_BOX_W}
                height={EFFECT_BOX_H}
                rx={8} ry={8}
                fill="#dc2626"
                stroke="#b91c1c"
                strokeWidth={1.5}
                filter="url(#effectShadow)"
              />
              <foreignObject
                x={EFFECT_BOX_X + 8}
                y={SPINE_Y - EFFECT_BOX_H / 2 + 4}
                width={EFFECT_BOX_W - 16}
                height={EFFECT_BOX_H - 8}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    height: "100%",
                    color: "white",
                    fontSize: "11px",
                    fontWeight: 600,
                    textAlign: "center",
                    lineHeight: 1.3,
                    fontFamily: "system-ui, sans-serif",
                    overflow: "hidden",
                  }}
                >
                  {effect || t("problem-solving.effect") || "Effect / Problem"}
                </div>
              </foreignObject>
            </g>

            {/* Legend */}
            <text
              x={SVG_W / 2} y={SVG_H - 8}
              textAnchor="middle"
              fontSize={10}
              fontFamily="system-ui, sans-serif"
              fill="#94a3b8"
              opacity={0.6}
            >
              {t("problem-solving.clickBranch") || "Click a branch to highlight it"}
            </text>

            {/* Root cause legend */}
            <g>
              <circle cx={SPINE_X_START + 10} cy={SVG_H - 14} r={4} fill="#dc2626" />
              <text
                x={SPINE_X_START + 20} y={SVG_H - 10}
                fontSize={9}
                fontFamily="system-ui, sans-serif"
                fill="#dc2626"
              >
                = {t("problem-solving.rootCause") || "Root Cause"}
              </text>
            </g>
          </svg>
        </div>
      </div>

      {/* === Cause Input Form === */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <h3 className="text-lg font-semibold mb-4 text-th-text">
          {t("problem-solving.editCauses") || "Edit Causes"}
        </h3>

        {/* Effect / Problem input */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-th-text-2 mb-1">
            {t("problem-solving.effectProblem") || "Effect / Problem Statement"}
          </label>
          <input
            type="text"
            value={effect}
            onChange={(e) => setEffect(e.target.value)}
            className="w-full px-3 py-2 border border-th-border rounded-lg bg-th-input text-th-text"
            placeholder={t("problem-solving.effectPlaceholder") || "Describe the effect or problem\u2026"}
          />
        </div>

        {/* 6M Categories grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CATEGORIES.map((cat) => {
            const catKey = cat.key as CategoryKey;
            const label = t(`problem-solving.${cat.labelKey}`) || cat.key;
            const isActive = highlightedCategory === null || highlightedCategory === cat.key;
            const causesForCat = categories[catKey] ?? [];

            return (
              <div
                key={cat.key}
                className={`p-4 rounded-lg border transition-opacity duration-300 ${CATEGORY_CLASSES[catKey]} ${
                  isActive ? "opacity-100" : "opacity-40"
                }`}
              >
                {/* Category header */}
                <div className="flex items-center justify-between mb-2">
                  <h4
                    className="font-semibold text-sm text-th-text flex items-center gap-2 cursor-pointer"
                    onClick={() => toggleHighlight(cat.key)}
                  >
                    <span
                      className="inline-block w-3 h-3 rounded-full"
                      style={{ backgroundColor: cat.stroke }}
                    />
                    {label}
                  </h4>
                  <span className="text-[10px] text-th-text-3">
                    {causesForCat.filter((c) => c.text.trim()).length}
                  </span>
                </div>

                {/* Causes list */}
                {causesForCat.map((cause, idx) => (
                  <div key={idx} className="mb-2">
                    {/* Main cause row */}
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        value={cause.text}
                        onChange={(e) => updateCauseText(catKey, idx, e.target.value)}
                        className="flex-1 px-2 py-1 border border-th-border rounded text-sm bg-th-input text-th-text"
                        placeholder={t("problem-solving.causePlaceholder") || `Cause\u2026`}
                      />
                      <label
                        className="flex items-center gap-0.5 text-[10px] text-red-500 cursor-pointer whitespace-nowrap"
                        title={t("problem-solving.markRoot") || "Mark as root cause"}
                      >
                        <input
                          type="checkbox"
                          checked={cause.isRoot}
                          onChange={() => toggleCauseRoot(catKey, idx)}
                          className="w-3 h-3 accent-red-600"
                        />
                        RC
                      </label>
                      <button
                        onClick={() => addSubCause(catKey, idx)}
                        className="text-th-text-3 hover:text-th-text text-xs px-1"
                        title={t("problem-solving.addSubCause") || "Add sub-cause"}
                      >
                        +&darr;
                      </button>
                      {causesForCat.length > 1 && (
                        <button
                          onClick={() => removeCause(catKey, idx)}
                          className="text-th-text-3 hover:text-red-500 text-xs px-1"
                          title={t("problem-solving.removeCause") || "Remove"}
                          aria-label={`Remove cause ${idx + 1}`}
                        >
                          &times;
                        </button>
                      )}
                    </div>

                    {/* Sub-causes */}
                    {cause.subCauses.length > 0 && (
                      <div className="ml-4 mt-1 space-y-1 border-l-2 border-th-border pl-2">
                        {cause.subCauses.map((sub, si) => (
                          <div key={si} className="flex items-center gap-1">
                            <input
                              type="text"
                              value={sub.text}
                              onChange={(e) =>
                                updateSubCauseText(catKey, idx, si, e.target.value)
                              }
                              className="flex-1 px-2 py-0.5 border border-th-border rounded text-xs bg-th-input text-th-text"
                              placeholder={t("problem-solving.subCausePlaceholder") || "Sub-cause\u2026"}
                            />
                            <label className="flex items-center gap-0.5 text-[9px] text-red-500 cursor-pointer whitespace-nowrap">
                              <input
                                type="checkbox"
                                checked={sub.isRoot}
                                onChange={() => toggleSubCauseRoot(catKey, idx, si)}
                                className="w-3 h-3 accent-red-600"
                              />
                              RC
                            </label>
                            <button
                              onClick={() => removeSubCause(catKey, idx, si)}
                              className="text-th-text-3 hover:text-red-500 text-[10px] px-0.5"
                              aria-label={`Remove sub-cause ${si + 1}`}
                            >
                              &times;
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                <button
                  onClick={() => addCause(catKey)}
                  className="text-xs text-th-text-3 hover:text-th-text mt-1"
                >
                  + {t("problem-solving.addCause") || "Add cause"}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* === Notes / Conclusion === */}
      <div className="bg-th-bg-2 p-6 rounded-lg shadow-sm border border-th-border">
        <h3 className="text-sm font-semibold text-th-text mb-2">
          {t("problem-solving.conclusionNotes") || "Conclusion / Notes"}
        </h3>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={4}
          className="w-full px-3 py-2 text-sm border border-th-border rounded-lg bg-th-input text-th-text resize-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
          placeholder={t("problem-solving.notesPlaceholder") || "Summary of findings, recommended next steps\u2026"}
        />
      </div>
    </div>
  );
}
