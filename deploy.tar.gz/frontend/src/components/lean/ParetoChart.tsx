"use client";
import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useI18n } from "@/stores/useI18n";
import { productionApi, advancedLeanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type DataSource = "downtime" | "defects" | "scrap" | "andon";
type DatePreset = 7 | 14 | 30 | 90;

interface ParetoItem {
  id: number;
  categoryKey: string;
  count: number;
  minutes: number;
  cost: number;
}

interface DrillDownRecord {
  date: string;
  line: string;
  duration: number;
  cost: number;
  notes: string;
}

interface ComputedItem extends ParetoItem {
  pct: number;
  cumPct: number;
  isVital: boolean;
}

// ---------------------------------------------------------------------------
// Demo data (fallback when API is unavailable)
// ---------------------------------------------------------------------------

const DEMO_DATA: Record<DataSource, ParetoItem[]> = {
  downtime: [
    { id: 1, categoryKey: "toolBreakage", count: 23, minutes: 460, cost: 4600 },
    { id: 2, categoryKey: "materialShortage", count: 18, minutes: 360, cost: 3200 },
    { id: 3, categoryKey: "setupError", count: 14, minutes: 280, cost: 2100 },
    { id: 4, categoryKey: "qualityReject", count: 11, minutes: 165, cost: 1650 },
    { id: 5, categoryKey: "equipmentJam", count: 8, minutes: 200, cost: 1800 },
    { id: 6, categoryKey: "operatorAbsent", count: 5, minutes: 300, cost: 900 },
    { id: 7, categoryKey: "itSystemDown", count: 3, minutes: 90, cost: 750 },
    { id: 8, categoryKey: "other", count: 2, minutes: 30, cost: 120 },
  ],
  defects: [
    { id: 1, categoryKey: "dimensionError", count: 30, minutes: 0, cost: 5400 },
    { id: 2, categoryKey: "surfaceFinish", count: 22, minutes: 0, cost: 3300 },
    { id: 3, categoryKey: "assemblyMismatch", count: 15, minutes: 0, cost: 2700 },
    { id: 4, categoryKey: "materialDefect", count: 10, minutes: 0, cost: 2000 },
    { id: 5, categoryKey: "colorVariation", count: 7, minutes: 0, cost: 700 },
    { id: 6, categoryKey: "packaging", count: 4, minutes: 0, cost: 200 },
  ],
  scrap: [
    { id: 1, categoryKey: "rawMaterial", count: 35, minutes: 0, cost: 7000 },
    { id: 2, categoryKey: "rework", count: 20, minutes: 0, cost: 4000 },
    { id: 3, categoryKey: "processWaste", count: 12, minutes: 0, cost: 1800 },
    { id: 4, categoryKey: "overProduction", count: 8, minutes: 0, cost: 1600 },
    { id: 5, categoryKey: "handling", count: 5, minutes: 0, cost: 500 },
  ],
  andon: [
    { id: 1, categoryKey: "andonRed", count: 15, minutes: 320, cost: 4800 },
    { id: 2, categoryKey: "andonMaintenance", count: 12, minutes: 240, cost: 3600 },
    { id: 3, categoryKey: "andonQuality", count: 10, minutes: 200, cost: 3000 },
    { id: 4, categoryKey: "andonMaterial", count: 8, minutes: 120, cost: 1600 },
    { id: 5, categoryKey: "andonYellow", count: 6, minutes: 90, cost: 900 },
    { id: 6, categoryKey: "andonSafety", count: 3, minutes: 60, cost: 1200 },
  ],
};

const DEMO_DRILLDOWN: DrillDownRecord[] = [
  { date: "2026-03-12", line: "Line A", duration: 45, cost: 450, notes: "Worn tool tip on CNC #3" },
  { date: "2026-03-11", line: "Line B", duration: 30, cost: 300, notes: "Feed jam after shift change" },
  { date: "2026-03-10", line: "Line A", duration: 60, cost: 600, notes: "Spindle alignment issue" },
  { date: "2026-03-09", line: "Line C", duration: 25, cost: 250, notes: "Insert chipped mid-cycle" },
  { date: "2026-03-08", line: "Line A", duration: 50, cost: 500, notes: "Emergency replacement" },
];

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const BAR_VITAL = "bg-rose-500 dark:bg-rose-500";
const BAR_TRIVIAL = "bg-slate-300 dark:bg-slate-600";

const DATA_SOURCES: { key: DataSource; labelKey: string }[] = [
  { key: "downtime", labelKey: "problem-solving.dsDowntime" },
  { key: "defects", labelKey: "problem-solving.dsDefects" },
  { key: "scrap", labelKey: "problem-solving.dsScrap" },
  { key: "andon", labelKey: "problem-solving.dsAndon" },
];

const DATE_PRESETS: { days: DatePreset; labelKey: string }[] = [
  { days: 7, labelKey: "problem-solving.last7" },
  { days: 14, labelKey: "problem-solving.last14" },
  { days: 30, labelKey: "problem-solving.last30" },
  { days: 90, labelKey: "problem-solving.last90" },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function fmtCurrency(v: number): string {
  if (v >= 1000) return `€${(v / 1000).toFixed(1)}k`;
  return `€${v}`;
}

function computePareto(items: ParetoItem[]): ComputedItem[] {
  const sorted = [...items].sort((a, b) => b.count - a.count);
  const total = sorted.reduce((s, i) => s + i.count, 0) || 1;
  let cum = 0;
  let crossedThreshold = false;
  return sorted.map((item, idx) => {
    cum += item.count;
    const cumPct = (cum / total) * 100;
    const isVital = !crossedThreshold;
    if (cumPct >= 80 && !crossedThreshold) crossedThreshold = true;
    return {
      ...item,
      pct: (item.count / total) * 100,
      cumPct,
      isVital: isVital || idx === 0,
    };
  });
}

function buildCsvString(computed: ComputedItem[], t: (k: string) => string): string {
  const header = [
    t("problem-solving.category"),
    t("problem-solving.count"),
    t("problem-solving.percentage"),
    t("problem-solving.cumulative"),
  ].join(",");
  const rows = computed.map(
    (c) =>
      `"${t(`problem-solving.${c.categoryKey}`) || c.categoryKey}",${c.count},${c.pct.toFixed(1)}%,${c.cumPct.toFixed(1)}%`
  );
  return [header, ...rows].join("\n");
}

// ---------------------------------------------------------------------------
// Pure CSS Pareto Chart
// ---------------------------------------------------------------------------

function ParetoBarChart({
  data,
  onBarClick,
  selectedId,
  t,
}: {
  data: ComputedItem[];
  onBarClick: (item: ComputedItem) => void;
  selectedId: number | null;
  t: (key: string) => string;
}) {
  const maxCount = data.length > 0 ? data[0].count : 1;
  const chartRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={chartRef} className="relative">
      {/* Y-axis labels and chart area */}
      <div className="flex">
        {/* Left Y-axis: Count */}
        <div className="flex flex-col justify-between w-12 text-right pr-2 text-xs text-th-text-3 shrink-0"
          style={{ height: 260 }}
        >
          <span>{maxCount}</span>
          <span>{Math.round(maxCount * 0.75)}</span>
          <span>{Math.round(maxCount * 0.5)}</span>
          <span>{Math.round(maxCount * 0.25)}</span>
          <span>0</span>
        </div>

        {/* Chart body */}
        <div className="flex-1 relative" style={{ height: 260 }}>
          {/* Grid lines */}
          {[0, 25, 50, 75, 100].map((pct) => (
            <div
              key={pct}
              className="absolute left-0 right-0 border-t border-th-border/40"
              style={{ top: `${100 - pct}%` }}
            />
          ))}

          {/* 80% threshold line */}
          <div
            className="absolute left-0 right-0 border-t-2 border-dashed border-red-500 z-10"
            style={{ top: "20%" }}
          >
            <span className="absolute -top-5 left-1 text-[10px] font-semibold text-red-500">
              80%
            </span>
          </div>

          {/* Bars container */}
          <div className="absolute inset-0 flex items-end gap-1 px-1">
            {data.map((item) => {
              const heightPct = (item.count / maxCount) * 100;
              const isSelected = selectedId === item.id;
              return (
                <div
                  key={item.id}
                  className="flex-1 flex flex-col items-center justify-end cursor-pointer group relative min-w-0"
                  onClick={() => onBarClick(item)}
                >
                  {/* Count label above bar */}
                  <span className="text-[10px] font-semibold text-th-text mb-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.count}
                  </span>
                  {/* Bar */}
                  <div
                    className={`w-full rounded-t transition-all duration-200 ${
                      item.isVital ? BAR_VITAL : BAR_TRIVIAL
                    } ${isSelected ? "ring-2 ring-indigo-500 ring-offset-1 ring-offset-th-bg-2" : ""} hover:opacity-90`}
                    style={{ height: `${heightPct}%`, minHeight: heightPct > 0 ? 4 : 0 }}
                    title={`${t(`problem-solving.${item.categoryKey}`) || item.categoryKey}: ${item.count} (${item.pct.toFixed(1)}%)`}
                  />
                </div>
              );
            })}
          </div>

          {/* Cumulative line overlay (SVG) */}
          {data.length > 1 && (
            <svg
              className="absolute inset-0 pointer-events-none z-20"
              viewBox={`0 0 ${data.length * 100} 100`}
              preserveAspectRatio="none"
            >
              <polyline
                fill="none"
                stroke="#6366f1"
                strokeWidth="2"
                vectorEffect="non-scaling-stroke"
                points={data
                  .map((item, i) => {
                    const x = (i + 0.5) * (100 / data.length) * data.length;
                    const y = 100 - item.cumPct;
                    return `${x},${y}`;
                  })
                  .join(" ")}
              />
              {data.map((item, i) => {
                const x = (i + 0.5) * (100 / data.length) * data.length;
                const y = 100 - item.cumPct;
                return (
                  <circle
                    key={item.id}
                    cx={x}
                    cy={y}
                    r="3"
                    fill="white"
                    stroke="#6366f1"
                    strokeWidth="2"
                    vectorEffect="non-scaling-stroke"
                  />
                );
              })}
            </svg>
          )}
        </div>

        {/* Right Y-axis: Cumulative % */}
        <div className="flex flex-col justify-between w-10 text-left pl-2 text-xs text-th-text-3 shrink-0"
          style={{ height: 260 }}
        >
          <span>100%</span>
          <span>75%</span>
          <span>50%</span>
          <span>25%</span>
          <span>0%</span>
        </div>
      </div>

      {/* X-axis labels */}
      <div className="flex ml-12 mr-10 mt-1">
        {data.map((item) => (
          <div
            key={item.id}
            className={`flex-1 text-center text-[10px] leading-tight truncate px-0.5 ${
              item.isVital ? "font-semibold text-th-text" : "text-th-text-3"
            }`}
            title={t(`problem-solving.${item.categoryKey}`) || item.categoryKey}
          >
            {t(`problem-solving.${item.categoryKey}`) || item.categoryKey}
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main Component
// ---------------------------------------------------------------------------

export default function ParetoChart() {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();

  // State
  const [dataSource, setDataSource] = useState<DataSource>("downtime");
  const [datePreset, setDatePreset] = useState<DatePreset>(30);
  const [items, setItems] = useState<ParetoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDemo, setIsDemo] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ComputedItem | null>(null);
  const [drillDownData, setDrillDownData] = useState<DrillDownRecord[]>([]);
  const [drillDownLoading, setDrillDownLoading] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);

  // -----------------------------------------------------------------------
  // Computed Pareto data
  // -----------------------------------------------------------------------

  const computed = useMemo(() => computePareto(items), [items]);

  const total = useMemo(() => computed.reduce((s, i) => s + i.count, 0), [computed]);
  const vitalCount = useMemo(() => computed.filter((c) => c.isVital).length, [computed]);

  // -----------------------------------------------------------------------
  // Data fetching
  // -----------------------------------------------------------------------

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    setSelectedItem(null);
    setDrillDownData([]);

    const startDate = daysAgo(datePreset);

    try {
      let rawRecords: any[] = [];

      if (dataSource === "andon") {
        const res = await advancedLeanApi.getAndonStatus();
        const payload = res.data?.events ?? res.data?.active ?? res.data ?? res;
        rawRecords = Array.isArray(payload) ? payload : [];
      } else {
        const res = await productionApi.listRecords();
        const payload = res.data?.records ?? res.data ?? res;
        rawRecords = Array.isArray(payload) ? payload : [];
      }

      if (rawRecords.length === 0) throw new Error("empty");

      // Filter by date range
      const start = new Date(startDate);
      const end = new Date();
      end.setHours(23, 59, 59, 999);

      const filtered = rawRecords.filter((r: any) => {
        const d = new Date(r.created_at || r.date || r.timestamp || r.started_at);
        return d >= start && d <= end;
      });

      if (filtered.length === 0) throw new Error("empty-range");

      // Aggregate into categories
      const fieldMap: Record<DataSource, string> = {
        downtime: "downtime_reason",
        defects: "defect_type",
        scrap: "scrap_category",
        andon: "event_type",
      };
      const field = fieldMap[dataSource];
      const agg = new Map<string, { count: number; minutes: number; cost: number }>();

      for (const r of filtered) {
        const key = r[field] || r.reason || r.type || r.category || "other";
        const existing = agg.get(key) || { count: 0, minutes: 0, cost: 0 };
        existing.count += 1;
        existing.minutes += Number(r.duration_minutes || r.minutes || r.duration || 0);
        existing.cost += Number(r.cost || r.unit_cost || r.estimated_cost || 0);
        agg.set(key, existing);
      }

      if (agg.size === 0) throw new Error("no-categories");

      const result: ParetoItem[] = [];
      let id = 1;
      for (const [key, val] of Array.from(agg.entries())) {
        result.push({ id: id++, categoryKey: key, ...val });
      }

      setItems(result);
      setIsDemo(false);
    } catch {
      setItems(DEMO_DATA[dataSource]);
      setIsDemo(true);
    } finally {
      setLoading(false);
    }
  }, [dataSource, datePreset]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // -----------------------------------------------------------------------
  // Drill-down
  // -----------------------------------------------------------------------

  const handleBarClick = useCallback(
    (item: ComputedItem) => {
      if (selectedItem?.id === item.id) {
        setSelectedItem(null);
        setDrillDownData([]);
        return;
      }
      setSelectedItem(item);
      setDrillDownLoading(true);

      // Attempt to fetch detail records from API; fall back to demo
      (async () => {
        try {
          if (!isDemo) {
            const res = await productionApi.listRecords();
            const records: any[] = res.data?.records ?? res.data ?? res;
            if (Array.isArray(records) && records.length > 0) {
              const fieldMap: Record<DataSource, string> = {
                downtime: "downtime_reason",
                defects: "defect_type",
                scrap: "scrap_category",
                andon: "event_type",
              };
              const field = fieldMap[dataSource];
              const details = records
                .filter((r: any) => (r[field] || r.reason || r.type || r.category || "other") === item.categoryKey)
                .slice(0, 20)
                .map((r: any) => ({
                  date: (r.created_at || r.date || r.timestamp || "").slice(0, 10),
                  line: r.line_name || r.line || r.area || "-",
                  duration: Number(r.duration_minutes || r.minutes || r.duration || 0),
                  cost: Number(r.cost || r.unit_cost || 0),
                  notes: r.notes || r.description || r.comment || "-",
                }));
              if (details.length > 0) {
                setDrillDownData(details);
                setDrillDownLoading(false);
                return;
              }
            }
          }
          throw new Error("fallback");
        } catch {
          setDrillDownData(DEMO_DRILLDOWN);
        } finally {
          setDrillDownLoading(false);
        }
      })();
    },
    [selectedItem, isDemo, dataSource]
  );

  // -----------------------------------------------------------------------
  // Export CSV
  // -----------------------------------------------------------------------

  const handleExportCsv = useCallback(() => {
    const csv = buildCsvString(computed, t);
    navigator.clipboard.writeText(csv).then(() => {
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
    });
  }, [computed, t]);

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------

  return (
    <div className="space-y-5 max-w-5xl mx-auto" data-print-area="true">
      {/* ---- Demo data banner ---- */}
      {isDemo && (
        <div className="mb-4 px-4 py-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-sm">
          <span className="text-amber-800 font-medium">{"\u26A0\uFE0F"} {t("dashboard.demoDataBadge")} — {t("dashboard.usingDemoData")}</span>
          <button onClick={() => fetchData()} className="text-amber-700 hover:text-amber-900 font-semibold underline">
            {t("dashboard.retry")}
          </button>
        </div>
      )}

      {/* ---- Header ---- */}
      <div className="bg-gradient-to-r from-rose-500 to-pink-600 rounded-2xl p-5 text-white shadow-lg">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center text-xl backdrop-blur-sm">
            {"\u{1F4CA}"}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold truncate">{t("problem-solving.paretoTitle")}</h2>
            <p className="text-sm text-white/80">{t("problem-solving.paretoSubtitle")}</p>
          </div>
          {isDemo && (
            <span className="text-xs bg-yellow-400/90 text-yellow-900 font-semibold rounded-lg px-2.5 py-1 shrink-0">
              {t("problem-solving.demoData")}
            </span>
          )}
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl font-bold">{items.length}</div>
            <div className="text-xs text-white/70">{t("problem-solving.categories")}</div>
          </div>
          <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl font-bold">{total}</div>
            <div className="text-xs text-white/70">{t("problem-solving.totalEvents")}</div>
          </div>
          <div className="bg-white/15 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl font-bold">{vitalCount}</div>
            <div className="text-xs text-white/70">{t("problem-solving.categoriesEighty")}</div>
          </div>
        </div>
      </div>

      {/* ---- Export ---- */}
      <ExportToolbar
        onPrint={() => printView(t("common.titlePareto"))}
        onExportExcel={() =>
          exportToExcel({
            title: t("common.titlePareto"),
            columns: [
              t("problem-solving.category") || "Category",
              t("problem-solving.count") || "Count",
              t("problem-solving.percentage") || "Percentage",
              t("problem-solving.cumulativePct") || "Cumulative %",
            ],
            rows: computed.map((item) => [
              t(`problem-solving.${item.categoryKey}`) || item.categoryKey,
              String(item.count),
              `${item.pct.toFixed(1)}%`,
              `${item.cumPct.toFixed(1)}%`,
            ]),
          })
        }
      />

      {/* ---- Filters ---- */}
      <div className="bg-th-bg-2 rounded-2xl p-4 shadow-card border border-th-border space-y-3">
        {/* Data source tabs */}
        <div>
          <div className="text-xs text-th-text-3 mb-1.5 font-medium">{t("problem-solving.dataSource")}</div>
          <div className="flex flex-wrap gap-2">
            {DATA_SOURCES.map((ds) => (
              <button
                key={ds.key}
                onClick={() => setDataSource(ds.key)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                  dataSource === ds.key
                    ? "bg-rose-500 text-white shadow"
                    : "bg-th-bg-3 text-th-text-2 border border-th-border hover:bg-th-bg-3/80"
                }`}
              >
                {t(ds.labelKey)}
              </button>
            ))}
          </div>
        </div>

        {/* Date range + export */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-xs text-th-text-3 font-medium mr-1">{t("problem-solving.dateRange")}:</div>
          {DATE_PRESETS.map((p) => (
            <button
              key={p.days}
              onClick={() => setDatePreset(p.days)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                datePreset === p.days
                  ? "bg-indigo-500 text-white shadow"
                  : "bg-th-bg-3 text-th-text-2 border border-th-border hover:bg-th-bg-3/80"
              }`}
            >
              {t(p.labelKey)}
            </button>
          ))}

          <div className="flex-1" />

          {/* Export CSV */}
          <button
            onClick={handleExportCsv}
            disabled={computed.length === 0}
            className="px-3 py-1.5 rounded-lg text-sm font-medium bg-th-bg-3 text-th-text-2 border border-th-border hover:bg-th-bg-3/80 transition disabled:opacity-40"
          >
            {copyFeedback ? t("problem-solving.copiedCsv") : t("problem-solving.exportCsv")}
          </button>
        </div>
      </div>

      {/* ---- Chart ---- */}
      <div className="bg-th-bg-2 rounded-2xl p-5 shadow-card border border-th-border relative min-h-[320px]">
        {/* Loading overlay */}
        {loading && (
          <div className="absolute inset-0 bg-th-bg-2/70 backdrop-blur-sm rounded-2xl flex items-center justify-center z-30">
            <div className="animate-spin w-8 h-8 border-4 border-rose-500 border-t-transparent rounded-full" />
          </div>
        )}

        {/* Error state */}
        {!loading && error && (
          <div className="flex items-center justify-center h-64 text-th-text-3">
            <p>{t("problem-solving.loadError")}</p>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && computed.length === 0 && (
          <div className="flex items-center justify-center h-64 text-th-text-3">
            <p>{t("problem-solving.noData")}</p>
          </div>
        )}

        {/* Chart */}
        {!loading && computed.length > 0 && (
          <>
            <ParetoBarChart
              data={computed}
              onBarClick={handleBarClick}
              selectedId={selectedItem?.id ?? null}
              t={t}
            />

            {/* Legend */}
            <div className="mt-4 pt-3 border-t border-th-border flex flex-wrap gap-x-5 gap-y-1 text-xs text-th-text-3">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-rose-500" />
                <span>{t("problem-solving.vitalFew")}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-slate-400 dark:bg-slate-600" />
                <span>{t("problem-solving.usefulMany")}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded bg-indigo-500" />
                <span>{t("problem-solving.cumulativeLine")}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0 border-t-2 border-dashed border-red-500" />
                <span>{t("problem-solving.threshold80")}</span>
              </div>
            </div>

            {/* 80% summary */}
            <p className="mt-2 text-sm text-th-text-2 font-medium">
              {t("problem-solving.summaryEighty", { count: vitalCount })}
            </p>
          </>
        )}
      </div>

      {/* ---- Data Table ---- */}
      {!loading && computed.length > 0 && (
        <div className="bg-th-bg-2 rounded-2xl shadow-card border border-th-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-th-bg-3 border-b border-th-border">
                  <th className="text-left py-2.5 px-4 font-semibold text-th-text-2">#</th>
                  <th className="text-left py-2.5 px-4 font-semibold text-th-text-2">
                    {t("problem-solving.category")}
                  </th>
                  <th className="text-right py-2.5 px-4 font-semibold text-th-text-2">
                    {t("problem-solving.count")}
                  </th>
                  <th className="text-right py-2.5 px-4 font-semibold text-th-text-2">
                    {t("problem-solving.percentage")}
                  </th>
                  <th className="text-right py-2.5 px-4 font-semibold text-th-text-2">
                    {t("problem-solving.cumulative")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {computed.map((item, idx) => (
                  <tr
                    key={item.id}
                    onClick={() => handleBarClick(item)}
                    className={`border-b border-th-border/50 cursor-pointer transition ${
                      selectedItem?.id === item.id
                        ? "bg-indigo-50 dark:bg-indigo-950/30"
                        : "hover:bg-th-bg-3/50"
                    }`}
                  >
                    <td className="py-2 px-4 text-th-text-3">{idx + 1}</td>
                    <td className="py-2 px-4 text-th-text font-medium">
                      <span className="flex items-center gap-2">
                        <span
                          className={`inline-block w-2.5 h-2.5 rounded-sm shrink-0 ${
                            item.isVital ? "bg-rose-500" : "bg-slate-400 dark:bg-slate-600"
                          }`}
                        />
                        {t(`problem-solving.${item.categoryKey}`) || item.categoryKey}
                      </span>
                    </td>
                    <td className="py-2 px-4 text-right text-th-text tabular-nums">{item.count}</td>
                    <td className="py-2 px-4 text-right text-th-text tabular-nums">{item.pct.toFixed(1)}%</td>
                    <td className="py-2 px-4 text-right tabular-nums">
                      <span
                        className={
                          item.cumPct <= 80
                            ? "text-rose-600 dark:text-rose-400 font-semibold"
                            : "text-th-text-3"
                        }
                      >
                        {item.cumPct.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---- Drill-down Panel ---- */}
      {selectedItem && (
        <div className="bg-th-bg-2 rounded-2xl p-5 shadow-card border border-th-border animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-th-text">
              {t("problem-solving.drillDownTitle")} &mdash;{" "}
              {t(`problem-solving.${selectedItem.categoryKey}`) || selectedItem.categoryKey}
            </h3>
            <button
              onClick={() => {
                setSelectedItem(null);
                setDrillDownData([]);
              }}
              className="text-th-text-3 hover:text-th-text transition text-lg leading-none px-1"
              aria-label={t("problem-solving.close")}
            >
              {"\u2715"}
            </button>
          </div>

          {/* Summary cards */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-th-bg-3 rounded-xl p-3 text-center">
              <div className="text-lg font-bold text-th-text">{selectedItem.count}</div>
              <div className="text-xs text-th-text-3">{t("problem-solving.occurrences")}</div>
            </div>
            <div className="bg-th-bg-3 rounded-xl p-3 text-center">
              <div className="text-lg font-bold text-th-text">{selectedItem.minutes} min</div>
              <div className="text-xs text-th-text-3">{t("problem-solving.totalDowntime")}</div>
            </div>
            <div className="bg-th-bg-3 rounded-xl p-3 text-center">
              <div className="text-lg font-bold text-purple-600 dark:text-purple-400">
                {fmtCurrency(selectedItem.cost)}
              </div>
              <div className="text-xs text-th-text-3">{t("problem-solving.costImpact")}</div>
            </div>
          </div>

          {/* Detail table */}
          {drillDownLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin w-6 h-6 border-3 border-rose-500 border-t-transparent rounded-full" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-th-border text-th-text-3">
                    <th className="text-left py-2 pr-4 font-medium">{t("problem-solving.date")}</th>
                    <th className="text-left py-2 pr-4 font-medium">{t("problem-solving.line")}</th>
                    <th className="text-right py-2 pr-4 font-medium">{t("problem-solving.duration")}</th>
                    <th className="text-right py-2 pr-4 font-medium">{t("problem-solving.cost")}</th>
                    <th className="text-left py-2 font-medium">{t("problem-solving.notes")}</th>
                  </tr>
                </thead>
                <tbody>
                  {drillDownData.map((row, i) => (
                    <tr key={i} className="border-b border-th-border/50 hover:bg-th-bg-3/50 transition">
                      <td className="py-2 pr-4 text-th-text">{row.date}</td>
                      <td className="py-2 pr-4 text-th-text">{row.line}</td>
                      <td className="py-2 pr-4 text-right text-th-text tabular-nums">{row.duration} min</td>
                      <td className="py-2 pr-4 text-right text-purple-600 dark:text-purple-400 font-medium tabular-nums">
                        {fmtCurrency(row.cost)}
                      </td>
                      <td className="py-2 text-th-text-2">{row.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {isDemo && drillDownData.length > 0 && (
            <p className="mt-2 text-xs text-th-text-3 italic">
              {t("problem-solving.demoData")}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
