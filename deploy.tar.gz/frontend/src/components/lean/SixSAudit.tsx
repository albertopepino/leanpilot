"use client";
import { useState, useEffect, useCallback, useMemo } from "react";
import { useI18n } from "@/stores/useI18n";
import { advancedLeanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

// ─── Constants ─────────────────────────────────────────────────────────────────

const CATEGORY_KEYS = [
  { id: "sort", labelKey: "catSort", shortKey: "catSortShort", icon: "\u{1F5C2}\uFE0F", color: "from-red-500 to-rose-500", descKey: "catSortDesc" },
  { id: "set_in_order", labelKey: "catSetInOrder", shortKey: "catSetInOrderShort", icon: "\u{1F4D0}", color: "from-orange-500 to-amber-500", descKey: "catSetInOrderDesc" },
  { id: "shine", labelKey: "catShine", shortKey: "catShineShort", icon: "\u2728", color: "from-yellow-500 to-lime-500", descKey: "catShineDesc" },
  { id: "standardize", labelKey: "catStandardize", shortKey: "catStandardizeShort", icon: "\u{1F4CB}", color: "from-green-500 to-emerald-500", descKey: "catStandardizeDesc" },
  { id: "sustain", labelKey: "catSustain", shortKey: "catSustainShort", icon: "\u{1F504}", color: "from-blue-500 to-cyan-500", descKey: "catSustainDesc" },
  { id: "safety", labelKey: "catSafety", shortKey: "catSafetyShort", icon: "\u{1F6E1}\uFE0F", color: "from-purple-500 to-violet-500", descKey: "catSafetyDesc" },
];

const QUESTION_KEYS: Record<string, string[]> = {
  sort: ["sort_q1", "sort_q2", "sort_q3", "sort_q4", "sort_q5"],
  set_in_order: ["setInOrder_q1", "setInOrder_q2", "setInOrder_q3", "setInOrder_q4", "setInOrder_q5"],
  shine: ["shine_q1", "shine_q2", "shine_q3", "shine_q4", "shine_q5"],
  standardize: ["standardize_q1", "standardize_q2", "standardize_q3", "standardize_q4", "standardize_q5"],
  sustain: ["sustain_q1", "sustain_q2", "sustain_q3", "sustain_q4", "sustain_q5"],
  safety: ["safety_q1", "safety_q2", "safety_q3", "safety_q4", "safety_q5"],
};

const AREA_PRESETS = [
  "Production Floor",
  "Warehouse",
  "Assembly Line",
  "Quality Lab",
  "Packaging",
  "Receiving Dock",
  "Shipping Dock",
  "Tool Crib",
  "Maintenance Shop",
  "Office Area",
];

const SCORE_LABELS: Record<number, { key: string; fallback: string }> = {
  1: { key: "scorePoor", fallback: "Poor" },
  2: { key: "scoreBelowAvg", fallback: "Below Avg" },
  3: { key: "scoreAverage", fallback: "Average" },
  4: { key: "scoreGood", fallback: "Good" },
  5: { key: "scoreExcellent", fallback: "Excellent" },
};

const SCORE_COLORS = [
  "",
  "bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400 border-red-300 dark:border-red-700",
  "bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-400 border-orange-300 dark:border-orange-700",
  "bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-400 border-yellow-300 dark:border-yellow-700",
  "bg-lime-100 dark:bg-lime-900/40 text-lime-700 dark:text-lime-400 border-lime-300 dark:border-lime-700",
  "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 border-emerald-300 dark:border-emerald-700",
];

// ─── Types ─────────────────────────────────────────────────────────────────────

interface AuditHistoryItem {
  id: number;
  area: string;
  date: string;
  overall_score: number;
  grade: string;
  scores: Record<string, number>;
}

interface TrendPoint {
  date: string;
  score: number;
}

type ViewMode = "audit" | "results" | "history";

// ─── Helpers ───────────────────────────────────────────────────────────────────

function computeGrade(score: number): { letter: string; color: string } {
  if (score >= 90) return { letter: "A", color: "text-emerald-600 dark:text-emerald-400" };
  if (score >= 80) return { letter: "B", color: "text-green-600 dark:text-green-400" };
  if (score >= 70) return { letter: "C", color: "text-yellow-600 dark:text-yellow-400" };
  if (score >= 55) return { letter: "D", color: "text-orange-600 dark:text-orange-400" };
  return { letter: "F", color: "text-red-600 dark:text-red-400" };
}

function getMaturityLevel(score: number): { level: number; labelKey: string; color: string } {
  if (score >= 90) return { level: 5, labelKey: "matWorldClass", color: "text-emerald-600 dark:text-emerald-400" };
  if (score >= 75) return { level: 4, labelKey: "matSustainable", color: "text-green-600 dark:text-green-400" };
  if (score >= 60) return { level: 3, labelKey: "matStandardized", color: "text-yellow-600 dark:text-yellow-400" };
  if (score >= 40) return { level: 2, labelKey: "matDeveloping", color: "text-orange-600 dark:text-orange-400" };
  return { level: 1, labelKey: "matInitial", color: "text-red-600 dark:text-red-400" };
}

function scoreToCardColor(avg: number): string {
  if (avg < 2) return "border-red-400 dark:border-red-600 bg-red-50 dark:bg-red-950/30";
  if (avg < 3) return "border-orange-400 dark:border-orange-600 bg-orange-50 dark:bg-orange-950/30";
  if (avg < 4) return "border-yellow-400 dark:border-yellow-600 bg-yellow-50 dark:bg-yellow-950/30";
  return "border-emerald-400 dark:border-emerald-600 bg-emerald-50 dark:bg-emerald-950/30";
}

function scoreToTextColor(avg: number): string {
  if (avg < 2) return "text-red-600 dark:text-red-400";
  if (avg < 3) return "text-orange-600 dark:text-orange-400";
  if (avg < 4) return "text-yellow-600 dark:text-yellow-400";
  return "text-emerald-600 dark:text-emerald-400";
}

// ─── SVG Radar Chart ───────────────────────────────────────────────────────────

interface RadarSeries {
  label: string;
  values: number[];
  stroke: string;
  fill: string;
  fillOpacity: number;
}

function RadarChart({
  categories,
  series,
  size = 320,
}: {
  categories: string[];
  series: RadarSeries[];
  size?: number;
}) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.34;
  const n = categories.length;
  const angles = categories.map((_, i) => (Math.PI * 2 * i) / n - Math.PI / 2);
  const gridLevels = [1, 2, 3, 4, 5];

  const pointAt = (angle: number, radius: number) => ({
    x: cx + Math.cos(angle) * radius,
    y: cy + Math.sin(angle) * radius,
  });

  const buildPath = (values: number[]) => {
    const pts = values.map((v, i) => pointAt(angles[i], (v / 5) * r));
    return pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ") + "Z";
  };

  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="w-full max-w-sm mx-auto" role="img" aria-label="6S Radar Chart">
      {/* Grid rings */}
      {gridLevels.map((level) => {
        const pts = angles.map((a) => pointAt(a, (level / 5) * r));
        const d = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ") + "Z";
        return (
          <g key={level}>
            <path d={d} fill="none" stroke="currentColor" className="text-th-border" strokeWidth="0.5" opacity={0.35} />
            <text
              x={cx + 4}
              y={cy - (level / 5) * r + 3}
              className="fill-th-text-3"
              style={{ fontSize: "7px" }}
            >
              {level}
            </text>
          </g>
        );
      })}

      {/* Axis lines */}
      {angles.map((a, i) => {
        const end = pointAt(a, r);
        return (
          <line
            key={i}
            x1={cx}
            y1={cy}
            x2={end.x}
            y2={end.y}
            stroke="currentColor"
            className="text-th-border"
            strokeWidth="0.5"
            opacity={0.25}
          />
        );
      })}

      {/* Gradient definitions */}
      <defs>
        <linearGradient id="radarGradCurrent" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#a855f7" stopOpacity="0.15" />
        </linearGradient>
        <linearGradient id="radarGradPrev" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#ef4444" stopOpacity="0.08" />
        </linearGradient>
      </defs>

      {/* Data polygons - previous first (behind) */}
      {[...series].reverse().map((s, idx) => (
        <path
          key={idx}
          d={buildPath(s.values)}
          fill={s.fill}
          fillOpacity={s.fillOpacity}
          stroke={s.stroke}
          strokeWidth={idx === series.length - 1 ? 2.5 : 1.5}
          strokeLinejoin="round"
        />
      ))}

      {/* Data points for primary series */}
      {series.length > 0 &&
        series[0].values.map((v, i) => {
          const pt = pointAt(angles[i], (v / 5) * r);
          return (
            <circle
              key={i}
              cx={pt.x}
              cy={pt.y}
              r="4"
              fill={series[0].stroke}
              stroke="white"
              strokeWidth="2"
            />
          );
        })}

      {/* Category labels */}
      {categories.map((label, i) => {
        const pt = pointAt(angles[i], r + 26);
        const anchor = pt.x < cx - 5 ? "end" : pt.x > cx + 5 ? "start" : "middle";
        return (
          <text
            key={i}
            x={pt.x}
            y={pt.y}
            textAnchor={anchor}
            dominantBaseline="middle"
            className="fill-th-text-2"
            style={{ fontSize: "9px", fontWeight: 600 }}
          >
            {label}
          </text>
        );
      })}

      {/* Score values on primary series */}
      {series.length > 0 &&
        series[0].values.map((v, i) => {
          const pt = pointAt(angles[i], Math.max((v / 5) * r + 16, 22));
          return (
            <text
              key={`v${i}`}
              x={pt.x}
              y={pt.y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="fill-indigo-600 dark:fill-indigo-400"
              style={{ fontSize: "10px", fontWeight: 700 }}
            >
              {v.toFixed(1)}
            </text>
          );
        })}

      {/* Legend */}
      {series.length > 1 && (
        <g>
          {series.map((s, i) => (
            <g key={i} transform={`translate(${size - 95}, ${size - 30 + i * 14})`}>
              <rect width="10" height="3" rx="1" fill={s.stroke} opacity={0.9} />
              <text x="14" y="3" className="fill-th-text-3" style={{ fontSize: "8px" }}>
                {s.label}
              </text>
            </g>
          ))}
        </g>
      )}
    </svg>
  );
}

// ─── Trend Mini-Chart ──────────────────────────────────────────────────────────

function TrendChart({ data }: { data: TrendPoint[] }) {
  if (data.length < 2) return null;

  const w = 400;
  const h = 120;
  const pad = { top: 12, right: 12, bottom: 22, left: 32 };
  const plotW = w - pad.left - pad.right;
  const plotH = h - pad.top - pad.bottom;

  const scores = data.map((d) => d.score);
  const minVal = Math.max(0, Math.min(...scores) - 10);
  const maxVal = Math.min(100, Math.max(...scores) + 10);

  const pts = data.map((d, i) => ({
    x: pad.left + (i / (data.length - 1)) * plotW,
    y: pad.top + plotH - ((d.score - minVal) / (maxVal - minVal)) * plotH,
  }));

  const linePath = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const areaPath = linePath + ` L${pts[pts.length - 1].x},${pad.top + plotH} L${pts[0].x},${pad.top + plotH} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label="6S Trend">
      <defs>
        <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#6366f1" stopOpacity="0.02" />
        </linearGradient>
      </defs>

      {/* Y-axis ticks */}
      {[minVal, Math.round((minVal + maxVal) / 2), maxVal].map((v) => {
        const y = pad.top + plotH - ((v - minVal) / (maxVal - minVal)) * plotH;
        return (
          <g key={v}>
            <line x1={pad.left} y1={y} x2={w - pad.right} y2={y} stroke="currentColor" className="text-th-border" strokeWidth="0.5" opacity={0.3} />
            <text x={pad.left - 4} y={y + 3} textAnchor="end" className="fill-th-text-3" style={{ fontSize: "8px" }}>
              {v}
            </text>
          </g>
        );
      })}

      {/* Area + Line */}
      <path d={areaPath} fill="url(#trendFill)" />
      <path d={linePath} fill="none" stroke="#6366f1" strokeWidth="2" strokeLinejoin="round" />

      {/* Points */}
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="3" fill="#6366f1" stroke="white" strokeWidth="1.5" />
      ))}

      {/* X-axis labels */}
      {data.map((d, i) => {
        if (data.length > 8 && i % 2 !== 0 && i !== data.length - 1) return null;
        return (
          <text
            key={i}
            x={pts[i].x}
            y={h - 4}
            textAnchor="middle"
            className="fill-th-text-3"
            style={{ fontSize: "7px" }}
          >
            {new Date(d.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          </text>
        );
      })}
    </svg>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────

export default function SixSAudit() {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();

  // Core audit state
  const [areaName, setAreaName] = useState("");
  const [activeCategory, setActiveCategory] = useState("sort");
  const [scores, setScores] = useState<Record<string, number>>({});
  const [findings, setFindings] = useState<Record<string, string>>({});
  const [viewMode, setViewMode] = useState<ViewMode>("audit");

  // API data
  const [auditHistory, setAuditHistory] = useState<AuditHistoryItem[]>([]);
  const [trendData, setTrendData] = useState<TrendPoint[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // ─── Score Getters ─────────────────────────────────────────────────────────

  const setScore = (cat: string, qIdx: number, score: number) => {
    setScores((prev) => ({ ...prev, [`${cat}-${qIdx}`]: score }));
  };

  const getScore = (cat: string, qIdx: number): number => {
    return scores[`${cat}-${qIdx}`] ?? 0;
  };

  const getCategoryAvg = useCallback(
    (cat: string): number => {
      const questions = QUESTION_KEYS[cat];
      let total = 0;
      let count = 0;
      questions.forEach((_, i) => {
        const s = scores[`${cat}-${i}`] ?? 0;
        if (s > 0) {
          total += s;
          count++;
        }
      });
      return count > 0 ? total / count : 0;
    },
    [scores]
  );

  const getCategoryPct = useCallback(
    (cat: string): number => {
      const avg = getCategoryAvg(cat);
      return avg > 0 ? Math.round((avg / 5) * 100) : 0;
    },
    [getCategoryAvg]
  );

  const overallScore = useMemo(() => {
    const avgs = CATEGORY_KEYS.map((c) => getCategoryAvg(c.id)).filter((a) => a > 0);
    return avgs.length > 0 ? Math.round((avgs.reduce((a, b) => a + b, 0) / avgs.length / 5) * 100) : 0;
  }, [getCategoryAvg]);

  const overallAvg = useMemo(() => {
    const avgs = CATEGORY_KEYS.map((c) => getCategoryAvg(c.id)).filter((a) => a > 0);
    return avgs.length > 0 ? avgs.reduce((a, b) => a + b, 0) / avgs.length : 0;
  }, [getCategoryAvg]);

  const grade = useMemo(() => computeGrade(overallScore), [overallScore]);
  const maturity = useMemo(() => getMaturityLevel(overallScore), [overallScore]);

  const categoryScoreMap = useMemo(() => {
    const map: Record<string, number> = {};
    CATEGORY_KEYS.forEach((c) => {
      map[c.id] = getCategoryPct(c.id);
    });
    return map;
  }, [getCategoryPct]);

  const categoryAvgMap = useMemo(() => {
    const map: Record<string, number> = {};
    CATEGORY_KEYS.forEach((c) => {
      map[c.id] = getCategoryAvg(c.id);
    });
    return map;
  }, [getCategoryAvg]);

  const completionCount = useMemo(() => {
    return Object.values(scores).filter((s) => s > 0).length;
  }, [scores]);

  const totalQuestions = 30;

  // ─── Action items: categories scoring below 3 ───────────────────────────────

  const actionItems = useMemo(() => {
    const items: { category: string; icon: string; avg: number; weakQuestions: { qKey: string; qIdx: number; score: number; finding: string }[] }[] = [];
    CATEGORY_KEYS.forEach((cat) => {
      const avg = categoryAvgMap[cat.id];
      if (avg > 0 && avg < 3) {
        const weakQuestions: { qKey: string; qIdx: number; score: number; finding: string }[] = [];
        QUESTION_KEYS[cat.id].forEach((qKey, qIdx) => {
          const s = scores[`${cat.id}-${qIdx}`] ?? 0;
          if (s > 0 && s < 3) {
            weakQuestions.push({
              qKey,
              qIdx,
              score: s,
              finding: findings[`${cat.id}-${qIdx}`] ?? "",
            });
          }
        });
        items.push({ category: cat.id, icon: cat.icon, avg, weakQuestions });
      }
    });
    return items;
  }, [categoryAvgMap, scores, findings]);

  // ─── Previous audit for radar overlay ──────────────────────────────────────

  const previousAuditScores = useMemo(() => {
    const matching = auditHistory.filter(
      (a) => !areaName || a.area.toLowerCase() === areaName.toLowerCase()
    );
    if (matching.length === 0) return null;
    const prev = matching[0];
    return CATEGORY_KEYS.map((c) => {
      const pctScore = prev.scores?.[c.id] ?? 0;
      // Convert percentage back to 1-5 scale for radar
      return (pctScore / 100) * 5;
    });
  }, [auditHistory, areaName]);

  // ─── API: Load history + trend ─────────────────────────────────────────────

  const loadHistory = useCallback(async () => {
    try {
      const res = await advancedLeanApi.listSixSAudits();
      const items: AuditHistoryItem[] = Array.isArray(res.data) ? res.data : [];
      setAuditHistory(items);
    } catch {
      setAuditHistory([]);
    }
  }, []);

  const loadTrend = useCallback(async () => {
    try {
      const res = await advancedLeanApi.getSixSTrend(areaName || undefined);
      const items: TrendPoint[] = Array.isArray(res.data) ? res.data : [];
      setTrendData(items);
    } catch {
      setTrendData([]);
    }
  }, [areaName]);

  useEffect(() => {
    setLoading(true);
    Promise.all([loadHistory(), loadTrend()]).finally(() => setLoading(false));
  }, [loadHistory, loadTrend]);

  // ─── API: Save audit ───────────────────────────────────────────────────────

  const saveAudit = async () => {
    if (completionCount === 0) return;
    setSaving(true);
    setApiError(null);

    const payload = {
      area: areaName || "General",
      date: new Date().toISOString(),
      overall_score: overallScore,
      grade: grade.letter,
      scores: categoryScoreMap,
      details: Object.entries(scores).map(([key, score]) => {
        const [cat, qIdxStr] = key.split("-");
        const qIdx = parseInt(qIdxStr, 10);
        return {
          category: cat,
          question_key: QUESTION_KEYS[cat]?.[qIdx] ?? key,
          score,
          finding: findings[key] ?? "",
        };
      }),
    };

    try {
      await advancedLeanApi.createSixSAudit(payload);
      await loadHistory();
      await loadTrend();
      setViewMode("results");
    } catch {
      setApiError(t("maintenance.saveError") || "Failed to save audit. Results shown locally.");
      setViewMode("results");
    } finally {
      setSaving(false);
    }
  };

  // ─── Radar data ────────────────────────────────────────────────────────────

  const radarCategories = CATEGORY_KEYS.map((c) => t(`maintenance.${c.shortKey}`));
  const radarCurrentValues = CATEGORY_KEYS.map((c) => categoryAvgMap[c.id]);

  const radarSeries: RadarSeries[] = [
    {
      label: t("maintenance.currentAudit") || "Current",
      values: radarCurrentValues,
      stroke: "#6366f1",
      fill: "url(#radarGradCurrent)",
      fillOpacity: 0.7,
    },
  ];

  if (previousAuditScores) {
    radarSeries.push({
      label: t("maintenance.previousAudit") || "Previous",
      values: previousAuditScores,
      stroke: "#f59e0b",
      fill: "url(#radarGradPrev)",
      fillOpacity: 0.5,
    });
  }

  // ─── Reset ─────────────────────────────────────────────────────────────────

  const resetAudit = () => {
    setScores({});
    setFindings({});
    setActiveCategory("sort");
    setViewMode("audit");
    setApiError(null);
  };

  // ─── RENDER: Loading ──────────────────────────────────────────────────────

  if (loading && viewMode === "history") {
    return (
      <div className="max-w-4xl mx-auto py-16 text-center">
        <div className="inline-block w-8 h-8 border-3 border-brand-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-th-text-3 animate-pulse">{t("maintenance.loading") || "Loading..."}</p>
      </div>
    );
  }

  // ─── RENDER: Results ───────────────────────────────────────────────────────

  if (viewMode === "results") {
    return (
      <div className="space-y-6 max-w-4xl mx-auto">
        {/* Error banner */}
        {apiError && (
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-700 rounded-xl p-3 text-sm text-amber-800 dark:text-amber-300">
            {apiError}
          </div>
        )}

        {/* Header with overall score + grade */}
        <div className="bg-gradient-brand rounded-2xl p-6 text-white shadow-glow">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <span className="text-4xl font-black">{overallScore}</span>
              </div>
              <div className="w-16 h-16 bg-white/15 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <span className="text-3xl font-black">{grade.letter}</span>
              </div>
            </div>
            <div className="text-center sm:text-left">
              <h2 className="text-2xl font-bold">
                {t("maintenance.auditResults", { area: areaName || "Area" })}
              </h2>
              <p className="text-white/80 mt-1">
                {t("maintenance.maturityLevel", { level: String(maturity.level) })}:{" "}
                <span className="font-semibold">{t(`maintenance.${maturity.labelKey}`)}</span>
              </p>
              <p className="text-white/70 text-sm mt-0.5">
                {t("maintenance.overallAvg") || "Overall Avg"}: {overallAvg.toFixed(1)}/5
              </p>
              <p className="text-white/60 text-sm mt-0.5">
                {completionCount}/{totalQuestions} {t("maintenance.questionsAnswered") || "questions answered"}
              </p>
            </div>
          </div>
        </div>

        {/* Radar Chart */}
        <div className="bg-th-bg-2 rounded-xl p-6 shadow-card border border-th-border">
          <h3 className="font-semibold text-th-text text-center mb-4">
            {t("maintenance.radarOverview")}
          </h3>
          <RadarChart categories={radarCategories} series={radarSeries} />
          {previousAuditScores && (
            <p className="text-xs text-th-text-3 text-center mt-2">
              {t("maintenance.radarCompareNote") || "Purple = current audit, Orange = previous audit"}
            </p>
          )}
        </div>

        {/* Category score cards with color coding */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {CATEGORY_KEYS.map((cat) => {
            const pct = categoryScoreMap[cat.id];
            const avg = categoryAvgMap[cat.id];
            return (
              <div
                key={cat.id}
                className={`rounded-xl p-4 shadow-card text-center border-2 ${scoreToCardColor(avg)}`}
              >
                <div className="text-2xl mb-1">{cat.icon}</div>
                <div className="text-xs text-th-text-2 mb-1 font-medium">
                  {t(`maintenance.${cat.shortKey}`)}
                </div>
                <div className={`text-2xl font-bold ${scoreToTextColor(avg)}`}>
                  {avg > 0 ? avg.toFixed(1) : "--"}
                </div>
                <div className="text-xs text-th-text-3">{pct}%</div>
                <div className="mt-2 h-2 bg-th-bg-3 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${cat.color}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Items for categories below 3 */}
        {actionItems.length > 0 && (
          <div className="bg-red-50 dark:bg-red-950/20 rounded-xl p-5 border border-red-200 dark:border-red-800">
            <h3 className="font-semibold text-red-700 dark:text-red-400 mb-3 flex items-center gap-2">
              <svg className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 6a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 6zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
              </svg>
              {t("maintenance.actionItemsTitle") || "Action Items Required"}
            </h3>
            <div className="space-y-3">
              {actionItems.map((item) => {
                const catDef = CATEGORY_KEYS.find((c) => c.id === item.category)!;
                return (
                  <div key={item.category} className="bg-white dark:bg-th-bg-2 rounded-lg p-3 border border-red-100 dark:border-red-900/30">
                    <div className="flex items-center gap-2 mb-2">
                      <span>{item.icon}</span>
                      <span className="font-semibold text-sm text-th-text">
                        {t(`maintenance.${catDef.labelKey}`)}
                      </span>
                      <span className="text-xs text-red-600 dark:text-red-400 font-medium ml-auto">
                        {t("maintenance.avgScore") || "Avg"}: {item.avg.toFixed(1)}/5
                      </span>
                    </div>
                    {item.weakQuestions.length > 0 && (
                      <ul className="space-y-1.5">
                        {item.weakQuestions.map((wq) => (
                          <li key={wq.qKey} className="flex items-start gap-2 text-xs">
                            <span className={`flex-shrink-0 w-5 h-5 rounded flex items-center justify-center font-bold text-white ${wq.score === 1 ? "bg-red-500" : "bg-orange-500"}`}>
                              {wq.score}
                            </span>
                            <span className="text-th-text-2">{t(`maintenance.${wq.qKey}`)}</span>
                            {wq.finding && (
                              <span className="text-th-text-3 italic ml-auto flex-shrink-0 max-w-[40%] truncate">
                                {wq.finding}
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Trend chart */}
        {trendData.length >= 2 && (
          <div className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border">
            <h3 className="font-semibold text-th-text text-sm mb-3">
              {t("maintenance.trendTitle") || "Score Trend"}
            </h3>
            <TrendChart data={trendData} />
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 flex-wrap">
          <button
            onClick={resetAudit}
            className="flex-1 min-w-[140px] bg-gradient-brand text-white py-3 rounded-xl font-semibold hover:opacity-90 transition shadow-glow"
          >
            {t("maintenance.newAudit") || "New Audit"}
          </button>
          <button
            onClick={() => setViewMode("history")}
            className="flex-1 min-w-[140px] bg-th-bg-2 border border-th-border text-th-text py-3 rounded-xl font-semibold hover:bg-th-bg-3 transition"
          >
            {t("maintenance.viewHistory") || "View History"}
          </button>
          <button
            onClick={() => setViewMode("audit")}
            className="text-brand-600 hover:text-brand-700 dark:text-brand-400 text-sm font-medium self-center"
          >
            {t("maintenance.backToAudit")}
          </button>
        </div>
      </div>
    );
  }

  // ─── RENDER: History ───────────────────────────────────────────────────────

  if (viewMode === "history") {
    return (
      <div className="space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-th-text">
            {t("maintenance.auditHistory") || "Audit History"}
          </h2>
          <button
            onClick={() => setViewMode("audit")}
            className="text-brand-600 hover:text-brand-700 dark:text-brand-400 text-sm font-medium"
          >
            {t("maintenance.backToAudit")}
          </button>
        </div>

        {/* Area filter for trend */}
        {auditHistory.length > 0 && (
          <div className="bg-th-bg-2 rounded-xl p-3 shadow-card border border-th-border">
            <label className="text-xs font-medium text-th-text-2 block mb-2">
              {t("maintenance.filterByArea") || "Filter trend by area"}
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setAreaName("")}
                className={`text-xs px-3 py-1.5 rounded-full border transition ${
                  !areaName
                    ? "bg-brand-100 dark:bg-brand-900/40 border-brand-300 dark:border-brand-700 text-brand-700 dark:text-brand-300 font-semibold"
                    : "border-th-border text-th-text-3 hover:border-brand-300 hover:text-brand-600"
                }`}
              >
                {t("maintenance.allAreas") || "All Areas"}
              </button>
              {Array.from(new Set(auditHistory.map((a) => a.area))).map((area) => (
                <button
                  key={area}
                  onClick={() => setAreaName(area)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition ${
                    areaName === area
                      ? "bg-brand-100 dark:bg-brand-900/40 border-brand-300 dark:border-brand-700 text-brand-700 dark:text-brand-300 font-semibold"
                      : "border-th-border text-th-text-3 hover:border-brand-300 hover:text-brand-600"
                  }`}
                >
                  {area}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Trend */}
        {trendData.length >= 2 && (
          <div className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border">
            <h3 className="font-semibold text-th-text text-sm mb-3">
              {t("maintenance.trendTitle") || "Score Trend"}
              {areaName && <span className="text-th-text-3 font-normal ml-2">({areaName})</span>}
            </h3>
            <TrendChart data={trendData} />
          </div>
        )}

        {/* History list */}
        {auditHistory.length === 0 ? (
          <div className="bg-th-bg-2 rounded-xl p-8 text-center border border-th-border">
            <p className="text-th-text-3">{t("maintenance.noHistory") || "No audits recorded yet."}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {auditHistory
              .filter((a) => !areaName || a.area.toLowerCase() === areaName.toLowerCase())
              .map((audit) => {
                const g = computeGrade(audit.overall_score);
                return (
                  <div
                    key={audit.id}
                    className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border flex items-center gap-4"
                  >
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center font-black text-xl ${g.color} bg-th-bg-3`}
                    >
                      {g.letter}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-th-text truncate">{audit.area}</div>
                      <div className="text-xs text-th-text-3">
                        {new Date(audit.date).toLocaleDateString(undefined, {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-th-text">{audit.overall_score}%</div>
                      <div className={`text-xs font-semibold ${g.color}`}>
                        {t("maintenance.grade") || "Grade"}: {g.letter}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        )}
      </div>
    );
  }

  // ─── RENDER: Audit Form ────────────────────────────────────────────────────

  return (
    <div className="space-y-6 max-w-4xl mx-auto" data-print-area="true">
      {/* Export Toolbar */}
      <ExportToolbar
        onPrint={() => printView(t("common.titleSixS"))}
        onExportExcel={() =>
          exportToExcel({
            title: t("common.titleSixS"),
            columns: [
              t("maintenance.category") || "Category",
              t("maintenance.score") || "Score",
              t("maintenance.maxScore") || "Max Score",
              t("maintenance.notes") || "Notes",
            ],
            rows: CATEGORY_KEYS.map((cat) => [
              t(`maintenance.${cat.labelKey}`),
              String(categoryAvgMap[cat.id]?.toFixed(1) ?? "0"),
              "5",
              findings[`${cat.id}-0`] || "",
            ]),
          })
        }
      />

      {/* Area/Zone Selector */}
      <div className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border">
        <label className="text-sm font-medium text-th-text block mb-2">
          {t("maintenance.auditArea")}
        </label>
        <input
          type="text"
          value={areaName}
          onChange={(e) => setAreaName(e.target.value)}
          placeholder={t("maintenance.auditAreaPlaceholder")}
          className="w-full px-4 py-2.5 border border-th-border rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none text-sm bg-th-input text-th-text mb-3"
        />
        <div className="flex flex-wrap gap-2">
          {AREA_PRESETS.map((area) => (
            <button
              key={area}
              onClick={() => setAreaName(area)}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${
                areaName === area
                  ? "bg-brand-100 dark:bg-brand-900/40 border-brand-300 dark:border-brand-700 text-brand-700 dark:text-brand-300 font-semibold"
                  : "border-th-border text-th-text-3 hover:border-brand-300 hover:text-brand-600"
              }`}
            >
              {area}
            </button>
          ))}
        </div>
      </div>

      {/* Progress bar */}
      <div className="bg-th-bg-2 rounded-xl p-3 shadow-card border border-th-border">
        <div className="flex items-center justify-between text-xs text-th-text-2 mb-1.5">
          <span>
            {t("maintenance.progress") || "Progress"}: {completionCount}/{totalQuestions}
          </span>
          <span className={`font-semibold ${grade.color}`}>
            {overallScore > 0 ? `${overallScore}% (${grade.letter})` : "---"}
          </span>
        </div>
        <div className="h-2 bg-th-bg-3 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 to-brand-600 transition-all duration-300"
            style={{ width: `${(completionCount / totalQuestions) * 100}%` }}
          />
        </div>
      </div>

      {/* Live Radar Preview (collapsed by default, shown when enough data) */}
      {completionCount >= 6 && (
        <div className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border">
          <h3 className="font-semibold text-th-text text-sm text-center mb-2">
            {t("maintenance.liveRadar") || "Live Radar Preview"}
          </h3>
          <RadarChart categories={radarCategories} series={radarSeries} size={260} />
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
        {CATEGORY_KEYS.map((cat) => {
          const answered = QUESTION_KEYS[cat.id].filter((_, i) => (scores[`${cat.id}-${i}`] ?? 0) > 0).length;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition whitespace-nowrap ${
                activeCategory === cat.id
                  ? "bg-brand-600 text-white shadow-glow"
                  : "bg-th-bg-2 border border-th-border text-th-text-2 hover:bg-brand-50 dark:hover:bg-brand-950/20"
              }`}
            >
              <span>{cat.icon}</span>
              <span className="hidden sm:inline">{t(`maintenance.${cat.shortKey}`)}</span>
              <span
                className={`text-xs px-1.5 py-0.5 rounded-full ${
                  activeCategory === cat.id
                    ? "bg-white/20"
                    : answered === 5
                    ? "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300"
                    : "bg-brand-100 dark:bg-brand-900/40 text-brand-700 dark:text-brand-300"
                }`}
              >
                {answered}/5
              </span>
            </button>
          );
        })}
      </div>

      {/* Category description */}
      <div className="bg-th-bg-2 rounded-lg px-4 py-2 border border-th-border">
        <p className="text-xs text-th-text-3">
          {t(`maintenance.${CATEGORY_KEYS.find((c) => c.id === activeCategory)?.descKey}`)}
        </p>
      </div>

      {/* Score legend */}
      <div className="flex items-center justify-center gap-3 text-xs text-th-text-3 flex-wrap">
        {[1, 2, 3, 4, 5].map((s) => (
          <span key={s} className="flex items-center gap-1">
            <span className={`inline-flex w-5 h-5 items-center justify-center rounded text-xs font-bold border ${SCORE_COLORS[s]}`}>
              {s}
            </span>
            <span>{t(`maintenance.${SCORE_LABELS[s].key}`) || SCORE_LABELS[s].fallback}</span>
          </span>
        ))}
      </div>

      {/* Questions */}
      <div className="space-y-3">
        {QUESTION_KEYS[activeCategory]?.map((qKey, qIdx) => {
          const currentScore = getScore(activeCategory, qIdx);
          return (
            <div
              key={qIdx}
              className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border"
            >
              <div className="flex items-start gap-3 mb-3">
                <span className="text-xs text-th-text-3 bg-th-bg-3 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5 font-medium">
                  {qIdx + 1}
                </span>
                <p className="text-sm text-th-text">{t(`maintenance.${qKey}`)}</p>
              </div>
              <div className="flex gap-2 ml-9 flex-wrap" role="radiogroup" aria-label={t(`maintenance.${qKey}`)}>
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    role="radio"
                    aria-checked={currentScore === s}
                    onClick={() => setScore(activeCategory, qIdx, s)}
                    title={t(`maintenance.${SCORE_LABELS[s].key}`) || SCORE_LABELS[s].fallback}
                    aria-label={`${s} - ${t(`maintenance.${SCORE_LABELS[s].key}`) || SCORE_LABELS[s].fallback}`}
                    className={`w-10 h-10 rounded-lg border-2 text-sm font-bold transition touch-score-btn ${
                      currentScore === s
                        ? SCORE_COLORS[s]
                        : "border-th-border text-th-text-3 hover:border-brand-300 hover:text-brand-600"
                    }`}
                  >
                    {s}
                  </button>
                ))}
                {currentScore > 0 && (
                  <span className={`text-xs self-center ml-2 font-medium ${scoreToTextColor(currentScore)}`}>
                    {t(`maintenance.${SCORE_LABELS[currentScore].key}`) || SCORE_LABELS[currentScore].fallback}
                  </span>
                )}
              </div>
              {/* Notes field for observations */}
              <div className="mt-3 ml-9">
                <input
                  type="text"
                  value={findings[`${activeCategory}-${qIdx}`] ?? ""}
                  onChange={(e) =>
                    setFindings((prev) => ({
                      ...prev,
                      [`${activeCategory}-${qIdx}`]: e.target.value,
                    }))
                  }
                  aria-label={`${t(`maintenance.${qKey}`)} - ${t("maintenance.findingPlaceholder") || "Note finding"}`}
                  placeholder={t("maintenance.findingPlaceholder") || "Note finding or observation..."}
                  className="w-full px-3 py-1.5 border border-th-border rounded-lg text-xs bg-th-input text-th-text focus:ring-1 focus:ring-brand-500 outline-none placeholder:text-th-text-3"
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Navigation + Submit */}
      <div className="flex gap-3 flex-wrap">
        {/* Previous category */}
        {CATEGORY_KEYS.findIndex((c) => c.id === activeCategory) > 0 && (
          <button
            onClick={() => {
              const idx = CATEGORY_KEYS.findIndex((c) => c.id === activeCategory);
              setActiveCategory(CATEGORY_KEYS[idx - 1].id);
            }}
            className="px-4 py-3 bg-th-bg-2 border border-th-border text-th-text rounded-xl text-sm font-medium hover:bg-th-bg-3 transition"
          >
            &larr; {t("maintenance.prevCategory") || "Previous"}
          </button>
        )}

        {/* Next category */}
        {CATEGORY_KEYS.findIndex((c) => c.id === activeCategory) <
        CATEGORY_KEYS.length - 1 ? (
          <button
            onClick={() => {
              const idx = CATEGORY_KEYS.findIndex((c) => c.id === activeCategory);
              setActiveCategory(CATEGORY_KEYS[idx + 1].id);
            }}
            className="flex-1 bg-brand-100 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 py-3 rounded-xl font-semibold hover:bg-brand-200 dark:hover:bg-brand-900/50 transition"
          >
            {t("maintenance.nextCategory") || "Next"} &rarr;
          </button>
        ) : (
          <button
            onClick={saveAudit}
            disabled={saving || completionCount === 0}
            className="flex-1 bg-gradient-brand text-white py-3 rounded-xl font-semibold hover:opacity-90 transition shadow-glow disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {saving && (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            )}
            {saving
              ? t("maintenance.saving") || "Saving..."
              : t("maintenance.submitAudit") || "Submit Audit"}
          </button>
        )}

        {/* Quick view results */}
        {completionCount > 0 && (
          <button
            onClick={() => setViewMode("results")}
            className="px-4 py-3 text-brand-600 hover:text-brand-700 dark:text-brand-400 text-sm font-medium"
          >
            {t("maintenance.viewResults")}
          </button>
        )}

        {/* History */}
        <button
          onClick={() => setViewMode("history")}
          className="px-4 py-3 text-th-text-3 hover:text-th-text text-sm font-medium"
        >
          {t("maintenance.viewHistory") || "History"}
        </button>
      </div>
    </div>
  );
}
