"use client";
import { useState, useEffect, useCallback, useMemo } from "react";
import { useI18n } from "@/stores/useI18n";
import { advancedLeanApi } from "@/lib/api";
import { useExport } from "@/hooks/useExport";
import ExportToolbar from "@/components/ui/ExportToolbar";

/* ───────── Types ───────── */

interface Equipment {
  id: number;
  name: string;
  type: string;
  location: string;
  criticality: "A" | "B" | "C";
  status: "running" | "maintenance" | "breakdown";
  oee: number;
  mtbf_hours: number;
  mttr_hours: number;
  next_pm: string;
  last_maintenance: string;
  maintenance_interval_days: number;
}

interface MaintenanceLog {
  id: number;
  equipment_id: number;
  date: string;
  type: "PM" | "CM" | "Autonomous";
  description: string;
  duration_hours: number;
  technician: string;
  parts_replaced: string;
}

/* ───────── Demo / fallback data ───────── */

const demoEquipment: Equipment[] = [
  { id: 1, name: "CNC Lathe #1", type: "CNC", location: "Machining Bay A", criticality: "A", status: "running", oee: 87, mtbf_hours: 720, mttr_hours: 2.5, next_pm: "2026-03-20", last_maintenance: "2026-03-01", maintenance_interval_days: 30 },
  { id: 2, name: "Hydraulic Press #2", type: "Press", location: "Forming Line B", criticality: "A", status: "running", oee: 82, mtbf_hours: 480, mttr_hours: 4, next_pm: "2026-03-15", last_maintenance: "2026-02-15", maintenance_interval_days: 28 },
  { id: 3, name: "Welding Robot #1", type: "Robot", location: "Assembly Cell 1", criticality: "B", status: "maintenance", oee: 74, mtbf_hours: 360, mttr_hours: 3, next_pm: "2026-03-13", last_maintenance: "2026-03-10", maintenance_interval_days: 14 },
  { id: 4, name: "Conveyor Belt #3", type: "Conveyor", location: "Packaging Area", criticality: "C", status: "running", oee: 95, mtbf_hours: 1200, mttr_hours: 1, next_pm: "2026-04-01", last_maintenance: "2026-03-01", maintenance_interval_days: 60 },
  { id: 5, name: "Paint Booth #1", type: "Booth", location: "Finishing Dept", criticality: "B", status: "breakdown", oee: 65, mtbf_hours: 200, mttr_hours: 6, next_pm: "2026-03-14", last_maintenance: "2026-03-12", maintenance_interval_days: 21 },
  { id: 6, name: "Injection Molder #4", type: "Molder", location: "Plastics Wing", criticality: "A", status: "running", oee: 91, mtbf_hours: 550, mttr_hours: 3.5, next_pm: "2026-03-25", last_maintenance: "2026-03-05", maintenance_interval_days: 30 },
];

const demoLogs: MaintenanceLog[] = [
  { id: 1, equipment_id: 1, date: "2026-03-10", type: "PM", description: "Spindle bearing replacement and lubrication", duration_hours: 2, technician: "M. Rossi", parts_replaced: "Bearing SKF 6205" },
  { id: 2, equipment_id: 2, date: "2026-03-08", type: "CM", description: "Hydraulic seal repair after pressure drop", duration_hours: 4, technician: "L. Bianchi", parts_replaced: "Hydraulic seal kit HS-220" },
  { id: 3, equipment_id: 3, date: "2026-03-13", type: "PM", description: "Welding tip calibration and wire feed check", duration_hours: 1.5, technician: "G. Verdi", parts_replaced: "" },
  { id: 4, equipment_id: 5, date: "2026-03-12", type: "CM", description: "Paint nozzle replacement due to clogging", duration_hours: 3, technician: "A. Neri", parts_replaced: "Nozzle assembly NZ-100" },
  { id: 5, equipment_id: 1, date: "2026-02-20", type: "Autonomous", description: "Operator daily cleaning and vibration check", duration_hours: 0.5, technician: "F. Conti", parts_replaced: "" },
  { id: 6, equipment_id: 4, date: "2026-03-01", type: "PM", description: "Belt tension adjustment and roller inspection", duration_hours: 1, technician: "M. Rossi", parts_replaced: "" },
  { id: 7, equipment_id: 6, date: "2026-03-05", type: "PM", description: "Mold cavity cleaning and injection pressure calibration", duration_hours: 2.5, technician: "L. Bianchi", parts_replaced: "O-ring set OR-440" },
  { id: 8, equipment_id: 2, date: "2026-02-15", type: "Autonomous", description: "Operator pre-shift hydraulic fluid level check", duration_hours: 0.3, technician: "P. Gialli", parts_replaced: "" },
];

/* ───────── Style maps ───────── */

const statusStyleMap: Record<string, { bg: string; text: string; dot: string }> = {
  running: { bg: "bg-emerald-50 dark:bg-emerald-950/30", text: "text-emerald-700 dark:text-emerald-400", dot: "bg-emerald-500" },
  maintenance: { bg: "bg-amber-50 dark:bg-amber-950/30", text: "text-amber-700 dark:text-amber-400", dot: "bg-amber-500" },
  breakdown: { bg: "bg-red-50 dark:bg-red-950/30", text: "text-red-700 dark:text-red-400", dot: "bg-red-500 animate-pulse-slow" },
};
const defaultStatusStyle = { bg: "bg-gray-50 dark:bg-gray-950/30", text: "text-gray-700 dark:text-gray-400", dot: "bg-gray-500" };
function getStatusStyle(status: string) {
  return statusStyleMap[status.toLowerCase()] || defaultStatusStyle;
}

const critColor: Record<string, string> = {
  A: "bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400",
  B: "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400",
  C: "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400",
};

const maintTypeStyle: Record<string, string> = {
  PM: "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400",
  CM: "bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-400",
  Autonomous: "bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-400",
};

/* ───────── Helpers ───────── */

type TabId = "equipment" | "calendar" | "history";

function getHealthColor(nextPm: string): "green" | "yellow" | "red" {
  const now = Date.now();
  const pmDate = new Date(nextPm).getTime();
  const daysUntilPm = (pmDate - now) / 86_400_000;
  if (daysUntilPm < 0) return "red";
  if (daysUntilPm <= 3) return "yellow";
  return "green";
}

const healthDot: Record<string, string> = {
  green: "bg-emerald-500",
  yellow: "bg-amber-500 animate-pulse",
  red: "bg-red-500 animate-pulse-slow",
};

function buildCalendarDays(equipment: Equipment[]): { date: string; items: Equipment[] }[] {
  const today = new Date();
  const days: { date: string; items: Equipment[] }[] = [];
  for (let d = 0; d < 28; d++) {
    const day = new Date(today);
    day.setDate(today.getDate() + d);
    const iso = day.toISOString().slice(0, 10);
    days.push({ date: iso, items: equipment.filter((eq) => eq.next_pm === iso) });
  }
  return days;
}

function formatDate(iso: string): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return iso;
  }
}

/* ───────── Component ───────── */

export default function TPMDashboard() {
  const { t } = useI18n();
  const { printView, exportToExcel } = useExport();

  /* ── state ── */
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>([]);
  const [selectedTab, setSelectedTab] = useState<TabId>("equipment");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usingDemo, setUsingDemo] = useState(false);

  // Add-equipment form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newEq, setNewEq] = useState({
    name: "",
    type: "",
    location: "",
    criticality: "B" as "A" | "B" | "C",
    maintenance_interval_days: 30,
  });
  const [addLoading, setAddLoading] = useState(false);
  const [addError, setAddError] = useState<string | null>(null);

  // Log-maintenance modal
  const [showLogForm, setShowLogForm] = useState(false);
  const [logEqId, setLogEqId] = useState<number | null>(null);
  const [newLog, setNewLog] = useState({
    type: "PM" as MaintenanceLog["type"],
    description: "",
    duration_hours: 1,
    technician: "",
    parts_replaced: "",
  });
  const [logLoading, setLogLoading] = useState(false);
  const [logError, setLogError] = useState<string | null>(null);

  // Equipment detail view
  const [detailEqId, setDetailEqId] = useState<number | null>(null);

  // History filter
  const [historyEqId, setHistoryEqId] = useState<number | null>(null);

  /* ── data fetching ── */
  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await advancedLeanApi.listEquipment();
      const items: Equipment[] = res.data?.data ?? res.data ?? [];
      if (items.length > 0) {
        setEquipment(items);
        setUsingDemo(false);
      } else {
        setEquipment(demoEquipment);
        setMaintenanceLogs(demoLogs);
        setUsingDemo(true);
      }
    } catch {
      setEquipment(demoEquipment);
      setMaintenanceLogs(demoLogs);
      setUsingDemo(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ── derived KPIs ── */
  const totalEquipment = equipment.length;
  const now = new Date();
  const todayIso = now.toISOString().slice(0, 10);

  const overduePMs = useMemo(
    () => equipment.filter((e) => getHealthColor(e.next_pm) === "red").length,
    [equipment],
  );

  const completedThisMonth = useMemo(() => {
    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
    return maintenanceLogs.filter((l) => l.date >= monthStart).length;
  }, [maintenanceLogs, now]);

  const avgMTBF = useMemo(() => {
    if (!equipment.length) return 0;
    return Math.round(equipment.reduce((s, e) => s + e.mtbf_hours, 0) / equipment.length);
  }, [equipment]);

  const avgMTTR = useMemo(() => {
    if (!equipment.length) return 0;
    return +(equipment.reduce((s, e) => s + e.mttr_hours, 0) / equipment.length).toFixed(1);
  }, [equipment]);

  const kpiCards = [
    {
      labelKey: "tpmTotalEquipment",
      value: totalEquipment,
      fallback: "Total Equipment",
      color: "bg-blue-500",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.573-1.066z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
    },
    {
      labelKey: "tpmOverduePMs",
      value: overduePMs,
      fallback: "Overdue PMs",
      color: overduePMs > 0 ? "bg-red-500" : "bg-emerald-500",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
    {
      labelKey: "tpmCompletedMonth",
      value: completedThisMonth,
      fallback: "Completed This Month",
      color: "bg-emerald-500",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
    {
      labelKey: "tpmAvgMTBF",
      value: `${avgMTBF}h`,
      fallback: "Avg MTBF",
      color: "bg-indigo-500",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>
      ),
    },
    {
      labelKey: "tpmAvgMTTR",
      value: `${avgMTTR}h`,
      fallback: "Avg MTTR",
      color: "bg-amber-500",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
  ];

  const calendarDays = useMemo(() => buildCalendarDays(equipment), [equipment]);

  const filteredLogs = useMemo(
    () =>
      (historyEqId
        ? maintenanceLogs.filter((l) => l.equipment_id === historyEqId)
        : maintenanceLogs
      ).sort((a, b) => b.date.localeCompare(a.date)),
    [maintenanceLogs, historyEqId],
  );

  const detailEquipment = useMemo(
    () => (detailEqId ? equipment.find((e) => e.id === detailEqId) ?? null : null),
    [equipment, detailEqId],
  );

  const detailLogs = useMemo(
    () =>
      detailEqId
        ? maintenanceLogs
            .filter((l) => l.equipment_id === detailEqId)
            .sort((a, b) => b.date.localeCompare(a.date))
        : [],
    [maintenanceLogs, detailEqId],
  );

  /* ── handlers ── */
  const handleAddEquipment = async () => {
    if (!newEq.name.trim()) return;
    setAddLoading(true);
    setAddError(null);
    try {
      const payload = {
        name: newEq.name,
        type: newEq.type || "General",
        location: newEq.location || "Unassigned",
        criticality: newEq.criticality,
        status: "running",
        oee: 0,
        mtbf_hours: 0,
        mttr_hours: 0,
        maintenance_interval_days: newEq.maintenance_interval_days,
        last_maintenance: todayIso,
        next_pm: new Date(Date.now() + newEq.maintenance_interval_days * 86_400_000)
          .toISOString()
          .slice(0, 10),
      };
      const res = await advancedLeanApi.createEquipment(payload);
      const created = res.data?.data ?? res.data;
      if (created?.id) {
        setEquipment((prev) => [...prev, created as Equipment]);
      } else {
        throw new Error("no_id");
      }
    } catch {
      // offline / error: add locally with generated id
      const localId = Math.max(0, ...equipment.map((e) => e.id)) + 1;
      setEquipment((prev) => [
        ...prev,
        {
          id: localId,
          name: newEq.name,
          type: newEq.type || "General",
          location: newEq.location || "Unassigned",
          criticality: newEq.criticality,
          status: "running",
          oee: 0,
          mtbf_hours: 0,
          mttr_hours: 0,
          maintenance_interval_days: newEq.maintenance_interval_days,
          last_maintenance: todayIso,
          next_pm: new Date(Date.now() + newEq.maintenance_interval_days * 86_400_000)
            .toISOString()
            .slice(0, 10),
        },
      ]);
    } finally {
      setNewEq({ name: "", type: "", location: "", criticality: "B", maintenance_interval_days: 30 });
      setShowAddForm(false);
      setAddLoading(false);
    }
  };

  const handleLogMaintenance = async () => {
    if (!logEqId || !newLog.description.trim()) return;
    setLogLoading(true);
    setLogError(null);
    try {
      await advancedLeanApi.logMaintenance({
        equipment_id: logEqId,
        date: todayIso,
        type: newLog.type,
        description: newLog.description,
        duration_hours: newLog.duration_hours,
        technician: newLog.technician,
        parts_replaced: newLog.parts_replaced,
      });
    } catch {
      // offline: proceed with local add
    }
    const localId = Math.max(0, ...maintenanceLogs.map((l) => l.id)) + 1;
    setMaintenanceLogs((prev) => [
      ...prev,
      {
        id: localId,
        equipment_id: logEqId,
        date: todayIso,
        type: newLog.type,
        description: newLog.description,
        duration_hours: newLog.duration_hours,
        technician: newLog.technician,
        parts_replaced: newLog.parts_replaced,
      },
    ]);
    // Update last_maintenance on the equipment
    setEquipment((prev) =>
      prev.map((eq) => {
        if (eq.id !== logEqId) return eq;
        const nextPm = new Date(Date.now() + eq.maintenance_interval_days * 86_400_000)
          .toISOString()
          .slice(0, 10);
        return { ...eq, last_maintenance: todayIso, next_pm: nextPm };
      }),
    );
    setNewLog({ type: "PM", description: "", duration_hours: 1, technician: "", parts_replaced: "" });
    setShowLogForm(false);
    setLogEqId(null);
    setLogLoading(false);
  };

  const openLogForEquipment = (eqId: number) => {
    setLogEqId(eqId);
    setLogError(null);
    setShowLogForm(true);
  };

  const closeLogForm = () => {
    setShowLogForm(false);
    setLogEqId(null);
    setLogError(null);
    setNewLog({ type: "PM", description: "", duration_hours: 1, technician: "", parts_replaced: "" });
  };

  /* ── tab definitions ── */
  const tabs: { id: TabId; labelKey: string; fallback: string }[] = [
    { id: "equipment", labelKey: "tpmEquipmentTab", fallback: "Equipment" },
    { id: "calendar", labelKey: "tpmCalendarTab", fallback: "PM Calendar" },
    { id: "history", labelKey: "tpmHistoryTab", fallback: "History" },
  ];

  /* ── shared input class ── */
  const inputCls =
    "px-3 py-2 rounded-lg border border-th-border bg-th-bg text-th-text text-sm focus:outline-none focus:ring-2 focus:ring-orange-400";

  /* ───────── Render ───────── */
  return (
    <div className="space-y-6 max-w-7xl mx-auto" data-print-area="true" role="region" aria-label="TPM Dashboard">
      {/* ── Header ── */}
      <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-6 text-white shadow-glow">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
            <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.573-1.066z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <div>
            <h2 className="text-xl font-bold">{t("maintenance.tpmTitle") || "TPM Dashboard"}</h2>
            <p className="text-sm text-white/80">{t("maintenance.tpmSubtitle") || "Total Productive Maintenance"}</p>
          </div>
          {usingDemo && (
            <span className="ml-auto text-xs bg-white/20 rounded-full px-3 py-1 backdrop-blur-sm">
              {t("maintenance.demoMode") || "Demo"}
            </span>
          )}
        </div>
      </div>

      {/* ── Export Toolbar ── */}
      <ExportToolbar
        onPrint={() => printView(t("common.titleTpm"))}
        onExportExcel={() =>
          exportToExcel({
            title: t("common.titleTpm"),
            columns: [
              t("maintenance.tpmEqName") || "Equipment",
              t("maintenance.tpmEqLocation") || "Location",
              t("maintenance.tpmLastMaintenance") || "Last Maintenance",
              t("maintenance.tpmStatus") || "Status",
              "MTBF (h)",
              "MTTR (h)",
            ],
            rows: equipment.map((eq) => [
              eq.name,
              eq.location,
              eq.last_maintenance,
              eq.status,
              String(eq.mtbf_hours),
              String(eq.mttr_hours),
            ]),
          })
        }
      />

      {/* ── Summary Cards ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {kpiCards.map((kpi) => (
          <div
            key={kpi.labelKey}
            className="bg-th-bg-2 rounded-xl p-4 shadow-card border border-th-border hover:shadow-card-hover transition"
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 ${kpi.color} text-white rounded-lg flex items-center justify-center flex-shrink-0`}>
                {kpi.icon}
              </div>
              <div className="min-w-0">
                <div className="text-2xl font-bold text-th-text leading-tight">{kpi.value}</div>
                <div className="text-xs text-th-text-2 truncate">{t(`maintenance.${kpi.labelKey}`) || kpi.fallback}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ── Tabs ── */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setSelectedTab(tab.id); setDetailEqId(null); }}
            className={`px-5 py-2 rounded-xl text-sm font-semibold transition ${
              selectedTab === tab.id
                ? "bg-orange-500 text-white shadow-lg"
                : "bg-th-bg-2 text-th-text-2 border border-th-border hover:bg-orange-50 dark:hover:bg-orange-950/20"
            }`}
          >
            {t(`maintenance.${tab.labelKey}`) || tab.fallback}
          </button>
        ))}
      </div>

      {/* ── Loading ── */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="w-8 h-8 border-3 border-orange-400 border-t-transparent rounded-full animate-spin" />
          <span className="ml-3 text-th-text-2 text-sm">{t("maintenance.loading") || "Loading..."}</span>
        </div>
      )}

      {/* ── Error banner ── */}
      {error && (
        <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl p-4 text-red-700 dark:text-red-400 text-sm flex items-center gap-2">
          <svg className="w-5 h-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          {error}
          <button onClick={() => setError(null)} className="ml-auto text-red-500 hover:text-red-700 dark:hover:text-red-300">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
      )}

      {/* ═══════════ TAB: Equipment Registry ═══════════ */}
      {!loading && selectedTab === "equipment" && !detailEqId && (
        <div className="space-y-3">
          {/* Add equipment button */}
          <div className="flex justify-end">
            <button
              onClick={() => { setShowAddForm(!showAddForm); setAddError(null); }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-orange-500 text-white hover:bg-orange-600 transition shadow"
            >
              <span className="text-lg leading-none">+</span>
              {t("maintenance.tpmAddEquipment") || "Add Equipment"}
            </button>
          </div>

          {/* Add equipment form */}
          {showAddForm && (
            <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border space-y-4">
              <h3 className="font-semibold text-th-text">{t("maintenance.tpmAddEquipment") || "Add Equipment"}</h3>
              {addError && (
                <p className="text-sm text-red-600 dark:text-red-400">{addError}</p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder={t("maintenance.tpmEqName") || "Equipment Name"}
                  value={newEq.name}
                  onChange={(e) => setNewEq({ ...newEq, name: e.target.value })}
                  className={inputCls}
                />
                <input
                  type="text"
                  placeholder={t("maintenance.tpmEqType") || "Type (CNC, Press, Robot...)"}
                  value={newEq.type}
                  onChange={(e) => setNewEq({ ...newEq, type: e.target.value })}
                  className={inputCls}
                />
                <input
                  type="text"
                  placeholder={t("maintenance.tpmEqLocation") || "Location"}
                  value={newEq.location}
                  onChange={(e) => setNewEq({ ...newEq, location: e.target.value })}
                  className={inputCls}
                />
                <select
                  value={newEq.criticality}
                  onChange={(e) => setNewEq({ ...newEq, criticality: e.target.value as "A" | "B" | "C" })}
                  className={inputCls}
                >
                  <option value="A">{t("maintenance.critA") || "A - Critical"}</option>
                  <option value="B">{t("maintenance.critB") || "B - Important"}</option>
                  <option value="C">{t("maintenance.critC") || "C - Standard"}</option>
                </select>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={365}
                    placeholder={t("maintenance.tpmIntervalDays") || "PM Interval (days)"}
                    value={newEq.maintenance_interval_days}
                    onChange={(e) => setNewEq({ ...newEq, maintenance_interval_days: Number(e.target.value) || 30 })}
                    className={inputCls + " flex-1"}
                  />
                  <span className="text-xs text-th-text-3 whitespace-nowrap">{t("maintenance.days") || "days"}</span>
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => { setShowAddForm(false); setAddError(null); }}
                  className="px-4 py-2 rounded-lg text-sm text-th-text-2 hover:bg-th-bg-3 transition"
                >
                  {t("common.cancel") || "Cancel"}
                </button>
                <button
                  onClick={handleAddEquipment}
                  disabled={addLoading || !newEq.name.trim()}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-orange-500 text-white hover:bg-orange-600 disabled:opacity-50 transition"
                >
                  {addLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      {t("maintenance.saving") || "Saving..."}
                    </span>
                  ) : (
                    t("common.save") || "Save"
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Equipment table */}
          <div className="bg-th-bg-2 rounded-xl shadow-card border border-th-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-th-bg-3 text-th-text-2 text-xs uppercase tracking-wider">
                    <th className="text-left px-4 py-3 font-semibold">{t("maintenance.tpmStatus") || "Status"}</th>
                    <th className="text-left px-4 py-3 font-semibold">{t("maintenance.tpmEqName") || "Name"}</th>
                    <th className="text-left px-4 py-3 font-semibold hidden sm:table-cell">{t("maintenance.tpmEqType") || "Type"}</th>
                    <th className="text-left px-4 py-3 font-semibold hidden md:table-cell">{t("maintenance.tpmEqLocation") || "Location"}</th>
                    <th className="text-center px-4 py-3 font-semibold">{t("maintenance.tpmCriticality") || "Crit."}</th>
                    <th className="text-center px-4 py-3 font-semibold hidden lg:table-cell">{t("maintenance.tpmLastMaintenance") || "Last PM"}</th>
                    <th className="text-center px-4 py-3 font-semibold">{t("maintenance.nextPm") || "Next PM"}</th>
                    <th className="text-center px-4 py-3 font-semibold hidden lg:table-cell">MTBF</th>
                    <th className="text-center px-4 py-3 font-semibold hidden lg:table-cell">MTTR</th>
                    <th className="text-right px-4 py-3 font-semibold">{t("maintenance.tpmActions") || "Actions"}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-th-border">
                  {equipment.map((eq) => {
                    const health = getHealthColor(eq.next_pm);
                    const st = getStatusStyle(eq.status);
                    return (
                      <tr
                        key={eq.id}
                        className="hover:bg-th-bg-3/50 transition cursor-pointer"
                        onClick={() => setDetailEqId(eq.id)}
                      >
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${st.dot}`} />
                            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${st.bg} ${st.text}`}>
                              {t(`maintenance.status${eq.status.charAt(0).toUpperCase() + eq.status.slice(1)}`) || eq.status}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3 font-semibold text-th-text">{eq.name}</td>
                        <td className="px-4 py-3 text-th-text-2 hidden sm:table-cell">{eq.type}</td>
                        <td className="px-4 py-3 text-th-text-2 hidden md:table-cell">{eq.location}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${critColor[eq.criticality]}`}>
                            {eq.criticality}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center text-th-text-2 hidden lg:table-cell">{formatDate(eq.last_maintenance)}</td>
                        <td className="px-4 py-3 text-center">
                          <span className="flex items-center justify-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${healthDot[health]}`} />
                            <span className={`text-xs ${health === "red" ? "text-red-600 dark:text-red-400 font-semibold" : health === "yellow" ? "text-amber-600 dark:text-amber-400" : "text-th-text-2"}`}>
                              {formatDate(eq.next_pm)}
                            </span>
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center text-th-text-2 hidden lg:table-cell">{eq.mtbf_hours}h</td>
                        <td className="px-4 py-3 text-center text-th-text-2 hidden lg:table-cell">{eq.mttr_hours}h</td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={(e) => { e.stopPropagation(); openLogForEquipment(eq.id); }}
                            className="px-3 py-1 rounded-lg text-xs font-semibold bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400 hover:bg-blue-200 dark:hover:bg-blue-900/60 transition"
                            title={t("maintenance.tpmLogMaintenance") || "Log Maintenance"}
                          >
                            {t("maintenance.tpmLogMaintenance") || "Log PM"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {equipment.length === 0 && (
              <div className="text-center py-12 text-th-text-3 text-sm">
                {t("maintenance.tpmNoEquipment") || "No equipment registered. Add your first machine above."}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════ Equipment Detail View ═══════════ */}
      {!loading && selectedTab === "equipment" && detailEqId && detailEquipment && (
        <div className="space-y-4">
          {/* Back button */}
          <button
            onClick={() => setDetailEqId(null)}
            className="flex items-center gap-1 text-sm text-th-text-2 hover:text-th-text transition"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
            {t("maintenance.tpmBackToList") || "Back to equipment list"}
          </button>

          {/* Equipment info card */}
          <div className="bg-th-bg-2 rounded-xl p-6 shadow-card border border-th-border">
            <div className="flex flex-col md:flex-row md:items-start gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <h3 className="text-xl font-bold text-th-text">{detailEquipment.name}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${critColor[detailEquipment.criticality]}`}>
                    {t(`maintenance.crit${detailEquipment.criticality}`) || `Criticality ${detailEquipment.criticality}`}
                  </span>
                  {(() => {
                    const st = getStatusStyle(detailEquipment.status);
                    return (
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${st.bg} ${st.text}`}>
                        {t(`maintenance.status${detailEquipment.status.charAt(0).toUpperCase() + detailEquipment.status.slice(1)}`) || detailEquipment.status}
                      </span>
                    );
                  })()}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-th-text-3 text-xs">{t("maintenance.tpmEqType") || "Type"}</div>
                    <div className="text-th-text font-medium">{detailEquipment.type}</div>
                  </div>
                  <div>
                    <div className="text-th-text-3 text-xs">{t("maintenance.tpmEqLocation") || "Location"}</div>
                    <div className="text-th-text font-medium">{detailEquipment.location}</div>
                  </div>
                  <div>
                    <div className="text-th-text-3 text-xs">{t("maintenance.tpmLastMaintenance") || "Last Maintenance"}</div>
                    <div className="text-th-text font-medium">{formatDate(detailEquipment.last_maintenance)}</div>
                  </div>
                  <div>
                    <div className="text-th-text-3 text-xs">{t("maintenance.tpmIntervalDays") || "PM Interval"}</div>
                    <div className="text-th-text font-medium">{detailEquipment.maintenance_interval_days} {t("maintenance.days") || "days"}</div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 text-center">
                <div className="bg-th-bg-3 rounded-lg px-4 py-3 min-w-[80px]">
                  <div className={`text-xl font-bold ${detailEquipment.oee >= 85 ? "text-emerald-600 dark:text-emerald-400" : detailEquipment.oee >= 70 ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400"}`}>
                    {detailEquipment.oee}%
                  </div>
                  <div className="text-[10px] text-th-text-3">OEE</div>
                </div>
                <div className="bg-th-bg-3 rounded-lg px-4 py-3 min-w-[80px]">
                  <div className="text-xl font-bold text-th-text">{detailEquipment.mtbf_hours}h</div>
                  <div className="text-[10px] text-th-text-3">MTBF</div>
                </div>
                <div className="bg-th-bg-3 rounded-lg px-4 py-3 min-w-[80px]">
                  <div className="text-xl font-bold text-th-text">{detailEquipment.mttr_hours}h</div>
                  <div className="text-[10px] text-th-text-3">MTTR</div>
                </div>
                <div className="bg-th-bg-3 rounded-lg px-4 py-3 min-w-[80px]">
                  {(() => {
                    const h = getHealthColor(detailEquipment.next_pm);
                    return (
                      <>
                        <div className="flex items-center justify-center gap-1">
                          <span className={`w-2.5 h-2.5 rounded-full ${healthDot[h]}`} />
                          <span className={`text-sm font-bold ${h === "red" ? "text-red-600 dark:text-red-400" : h === "yellow" ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                            {formatDate(detailEquipment.next_pm)}
                          </span>
                        </div>
                        <div className="text-[10px] text-th-text-3">{t("maintenance.nextPm") || "Next PM"}</div>
                      </>
                    );
                  })()}
                </div>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => openLogForEquipment(detailEquipment.id)}
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-orange-500 text-white hover:bg-orange-600 transition shadow"
              >
                {t("maintenance.tpmLogMaintenance") || "Log Maintenance"}
              </button>
            </div>
          </div>

          {/* Upcoming PM schedule */}
          <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border">
            <h4 className="font-semibold text-th-text mb-3">{t("maintenance.tpmUpcomingPM") || "Upcoming PM Schedule"}</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[0, 1, 2].map((mult) => {
                const nextDate = new Date(detailEquipment.next_pm);
                nextDate.setDate(nextDate.getDate() + mult * detailEquipment.maintenance_interval_days);
                const iso = nextDate.toISOString().slice(0, 10);
                const isPast = iso < todayIso;
                return (
                  <div
                    key={mult}
                    className={`rounded-lg p-3 border text-center text-sm ${
                      isPast
                        ? "border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400"
                        : mult === 0
                          ? "border-orange-300 dark:border-orange-700 bg-orange-50 dark:bg-orange-950/20 text-orange-700 dark:text-orange-400"
                          : "border-th-border bg-th-bg-3 text-th-text-2"
                    }`}
                  >
                    <div className="font-bold">{formatDate(iso)}</div>
                    <div className="text-xs mt-1">
                      {isPast
                        ? t("maintenance.tpmOverdue") || "OVERDUE"
                        : mult === 0
                          ? t("maintenance.tpmNextScheduled") || "Next Scheduled"
                          : `+${mult * detailEquipment.maintenance_interval_days} ${t("maintenance.days") || "days"}`}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Maintenance history for this equipment */}
          <div className="bg-th-bg-2 rounded-xl p-5 shadow-card border border-th-border">
            <h4 className="font-semibold text-th-text mb-3">{t("maintenance.tpmMaintenanceHistory") || "Maintenance History"}</h4>
            {detailLogs.length === 0 ? (
              <p className="text-sm text-th-text-3">{t("maintenance.tpmNoLogs") || "No maintenance logs recorded for this equipment."}</p>
            ) : (
              <div className="space-y-2">
                {detailLogs.map((log) => (
                  <div key={log.id} className="flex flex-col sm:flex-row sm:items-center gap-2 p-3 rounded-lg border border-th-border bg-th-bg hover:bg-th-bg-3/50 transition">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-th-text font-medium">{log.description}</div>
                      {log.parts_replaced && (
                        <div className="text-xs text-th-text-3 mt-0.5">
                          {t("maintenance.tpmPartsReplaced") || "Parts"}: {log.parts_replaced}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs items-center">
                      <span className={`px-2 py-0.5 rounded-full font-semibold ${maintTypeStyle[log.type]}`}>{log.type}</span>
                      <span className="text-th-text-2">{formatDate(log.date)}</span>
                      <span className="text-th-text-2">{log.duration_hours}h</span>
                      <span className="text-th-text-3">{log.technician}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════ TAB: PM Calendar ═══════════ */}
      {!loading && selectedTab === "calendar" && (
        <div className="space-y-4">
          <h3 className="font-semibold text-th-text text-lg">{t("maintenance.tpmPmCalendar") || "Preventive Maintenance Calendar"}</h3>
          <div className="bg-th-bg-2 rounded-xl shadow-card border border-th-border p-4 overflow-x-auto">
            <div className="grid grid-cols-7 gap-1 min-w-[500px]">
              {/* Day-of-week header */}
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
                <div key={d} className="text-center text-[10px] font-semibold text-th-text-3 py-1 uppercase">
                  {t(`maintenance.day${d}`) || d}
                </div>
              ))}
              {/* Pad first row to correct weekday */}
              {(() => {
                const firstDay = new Date(calendarDays[0]?.date);
                const dayOfWeek = (firstDay.getDay() + 6) % 7; // Mon=0
                return Array.from({ length: dayOfWeek }).map((_, i) => <div key={`pad-${i}`} />);
              })()}
              {calendarDays.map(({ date, items }) => {
                const isToday = date === todayIso;
                const hasPm = items.length > 0;
                const hasOverdue = items.some((eq) => getHealthColor(eq.next_pm) === "red");
                return (
                  <div
                    key={date}
                    className={`rounded-lg p-1.5 min-h-[64px] text-center border transition text-xs ${
                      isToday
                        ? "border-orange-400 bg-orange-50 dark:bg-orange-950/20 ring-1 ring-orange-300 dark:ring-orange-700"
                        : "border-th-border bg-th-bg"
                    } ${hasPm && !isToday ? "ring-1 ring-blue-300 dark:ring-blue-700" : ""}`}
                  >
                    <div className={`font-semibold mb-1 ${isToday ? "text-orange-600 dark:text-orange-400" : "text-th-text"}`}>
                      {new Date(date).getDate()}
                    </div>
                    {items.map((eq) => (
                      <div
                        key={eq.id}
                        className={`text-[9px] leading-tight truncate rounded px-1 py-0.5 mb-0.5 cursor-pointer hover:opacity-80 ${
                          hasOverdue
                            ? "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
                            : "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
                        }`}
                        title={eq.name}
                        onClick={() => { setSelectedTab("equipment"); setDetailEqId(eq.id); }}
                      >
                        {eq.name}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
          <p className="text-xs text-th-text-3">
            {t("maintenance.tpmCalendarHint") || "Blue = scheduled PM. Red = overdue. Click equipment name to view details."}
          </p>
        </div>
      )}

      {/* ═══════════ TAB: Maintenance History ═══════════ */}
      {!loading && selectedTab === "history" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
            <h3 className="font-semibold text-th-text text-lg">{t("maintenance.tpmHistoryTitle") || "Maintenance History"}</h3>
            <div className="flex items-center gap-2">
              <select
                value={historyEqId ?? ""}
                onChange={(e) => setHistoryEqId(e.target.value ? Number(e.target.value) : null)}
                className={inputCls}
              >
                <option value="">{t("maintenance.tpmAllEquipment") || "All Equipment"}</option>
                {equipment.map((eq) => (
                  <option key={eq.id} value={eq.id}>{eq.name}</option>
                ))}
              </select>
              <button
                onClick={() => openLogForEquipment(equipment[0]?.id ?? 0)}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-orange-500 text-white hover:bg-orange-600 transition shadow whitespace-nowrap"
              >
                + {t("maintenance.tpmLogMaintenance") || "Log PM"}
              </button>
            </div>
          </div>

          {filteredLogs.length === 0 ? (
            <div className="bg-th-bg-2 rounded-xl p-12 shadow-card border border-th-border text-center">
              <svg className="w-12 h-12 mx-auto mb-3 text-th-text-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-th-text-3 text-sm">{t("maintenance.tpmNoLogs") || "No maintenance logs yet."}</p>
            </div>
          ) : (
            <div className="bg-th-bg-2 rounded-xl shadow-card border border-th-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-th-bg-3 text-th-text-2 text-xs uppercase tracking-wider">
                      <th className="text-left px-4 py-3 font-semibold">{t("maintenance.tpmDate") || "Date"}</th>
                      <th className="text-left px-4 py-3 font-semibold">{t("maintenance.tpmEqName") || "Equipment"}</th>
                      <th className="text-center px-4 py-3 font-semibold">{t("maintenance.tpmType") || "Type"}</th>
                      <th className="text-left px-4 py-3 font-semibold hidden sm:table-cell">{t("maintenance.tpmDescription") || "Description"}</th>
                      <th className="text-center px-4 py-3 font-semibold hidden md:table-cell">{t("maintenance.tpmDuration") || "Duration"}</th>
                      <th className="text-left px-4 py-3 font-semibold hidden lg:table-cell">{t("maintenance.tpmPartsReplaced") || "Parts Replaced"}</th>
                      <th className="text-left px-4 py-3 font-semibold hidden md:table-cell">{t("maintenance.tpmTechnician") || "Technician"}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-th-border">
                    {filteredLogs.map((log) => {
                      const eq = equipment.find((e) => e.id === log.equipment_id);
                      return (
                        <tr key={log.id} className="hover:bg-th-bg-3/50 transition">
                          <td className="px-4 py-3 text-th-text-2 whitespace-nowrap">{formatDate(log.date)}</td>
                          <td className="px-4 py-3 font-medium text-th-text">
                            <button
                              onClick={() => { setSelectedTab("equipment"); setDetailEqId(log.equipment_id); }}
                              className="hover:text-orange-500 transition text-left"
                            >
                              {eq?.name ?? `#${log.equipment_id}`}
                            </button>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${maintTypeStyle[log.type]}`}>
                              {log.type}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-th-text-2 hidden sm:table-cell max-w-[240px] truncate">{log.description}</td>
                          <td className="px-4 py-3 text-center text-th-text-2 hidden md:table-cell">{log.duration_hours}h</td>
                          <td className="px-4 py-3 text-th-text-3 hidden lg:table-cell">{log.parts_replaced || "—"}</td>
                          <td className="px-4 py-3 text-th-text-3 hidden md:table-cell">{log.technician}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ═══════════ Modal: Log Maintenance ═══════════ */}
      {showLogForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div
            className="bg-th-bg rounded-2xl shadow-2xl border border-th-border w-full max-w-lg p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-th-text text-lg">{t("maintenance.tpmLogMaintenance") || "Log Maintenance"}</h3>
              <button onClick={closeLogForm} className="text-th-text-3 hover:text-th-text transition p-1">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {logError && (
              <p className="text-sm text-red-600 dark:text-red-400">{logError}</p>
            )}

            <div className="space-y-3">
              {/* Equipment selector */}
              <div>
                <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmSelectEquipment") || "Equipment"}</label>
                <select
                  value={logEqId ?? ""}
                  onChange={(e) => setLogEqId(Number(e.target.value))}
                  className={inputCls + " w-full"}
                >
                  <option value="" disabled>{t("maintenance.tpmSelectEquipment") || "Select equipment..."}</option>
                  {equipment.map((eq) => (
                    <option key={eq.id} value={eq.id}>{eq.name}</option>
                  ))}
                </select>
              </div>

              {/* Maintenance type */}
              <div>
                <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmMaintenanceType") || "Maintenance Type"}</label>
                <select
                  value={newLog.type}
                  onChange={(e) => setNewLog({ ...newLog, type: e.target.value as MaintenanceLog["type"] })}
                  className={inputCls + " w-full"}
                >
                  <option value="PM">{t("maintenance.maintPM") || "PM - Preventive Maintenance"}</option>
                  <option value="CM">{t("maintenance.maintCM") || "CM - Corrective Maintenance"}</option>
                  <option value="Autonomous">{t("maintenance.maintAutonomous") || "Autonomous Maintenance"}</option>
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmLogDescription") || "Description"}</label>
                <textarea
                  placeholder={t("maintenance.tpmLogDescriptionPlaceholder") || "Describe the maintenance performed..."}
                  value={newLog.description}
                  onChange={(e) => setNewLog({ ...newLog, description: e.target.value })}
                  rows={3}
                  className={inputCls + " w-full resize-none"}
                />
              </div>

              {/* Duration + Technician */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmLogDuration") || "Duration (hours)"}</label>
                  <input
                    type="number"
                    min={0.1}
                    step={0.5}
                    value={newLog.duration_hours}
                    onChange={(e) => setNewLog({ ...newLog, duration_hours: Number(e.target.value) || 0.5 })}
                    className={inputCls + " w-full"}
                  />
                </div>
                <div>
                  <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmLogTechnician") || "Technician"}</label>
                  <input
                    type="text"
                    placeholder={t("maintenance.tpmLogTechnicianPlaceholder") || "Name"}
                    value={newLog.technician}
                    onChange={(e) => setNewLog({ ...newLog, technician: e.target.value })}
                    className={inputCls + " w-full"}
                  />
                </div>
              </div>

              {/* Parts replaced */}
              <div>
                <label className="block text-xs text-th-text-2 mb-1 font-medium">{t("maintenance.tpmPartsReplaced") || "Parts Replaced"}</label>
                <input
                  type="text"
                  placeholder={t("maintenance.tpmPartsReplacedPlaceholder") || "e.g., Bearing SKF 6205, O-ring set"}
                  value={newLog.parts_replaced}
                  onChange={(e) => setNewLog({ ...newLog, parts_replaced: e.target.value })}
                  className={inputCls + " w-full"}
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-th-border">
              <button
                onClick={closeLogForm}
                className="px-4 py-2 rounded-lg text-sm text-th-text-2 hover:bg-th-bg-3 transition"
              >
                {t("common.cancel") || "Cancel"}
              </button>
              <button
                onClick={handleLogMaintenance}
                disabled={logLoading || !newLog.description.trim() || !logEqId}
                className="px-5 py-2 rounded-lg text-sm font-semibold bg-orange-500 text-white hover:bg-orange-600 disabled:opacity-50 transition"
              >
                {logLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    {t("maintenance.saving") || "Saving..."}
                  </span>
                ) : (
                  t("maintenance.tpmSaveLog") || "Save Log"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
