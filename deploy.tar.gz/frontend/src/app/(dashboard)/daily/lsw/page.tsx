import { redirect } from "next/navigation";
export default function LegacyLSW() { redirect("/improvement/kaizen"); }
