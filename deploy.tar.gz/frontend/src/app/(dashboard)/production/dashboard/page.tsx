import { redirect } from "next/navigation";
export default function LegacyDashboard() { redirect("/operations/oee"); }
